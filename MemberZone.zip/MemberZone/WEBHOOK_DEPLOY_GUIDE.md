# Guia de Deploy - Webhook X1-Broker

## Problema Atual
O webhook está configurado para o domínio temporário do Replit de desenvolvimento. Quando você fizer o deploy, precisará atualizar a URL na X1-Broker.

## URLs do Webhook

### Desenvolvimento (Atual)
```
https://c1ca00ad-ea25-42e0-8f0d-df5fc2ce5010-00-2usqk4czkkafx.picard.replit.dev/api/webhook/broker-registration
```

### Produção (Após Deploy)
```
https://SEU-DOMINIO.replit.app/api/webhook/broker-registration
```

## Passos para Atualizar o Webhook

### 1. Fazer o Deploy
- Clique em "Deploy" no Replit
- Aguarde o deploy ser concluído
- Anote a nova URL que será gerada

### 2. Atualizar na X1-Broker
- Acesse o painel administrativo da X1-Broker
- Vá para a seção de Webhooks/Integrações
- Altere a URL do webhook de cadastro para a nova URL de produção
- Salve as alterações

### 3. Testar o Webhook
- Faça um cadastro de teste na X1-Broker
- Verifique se o webhook está sendo recebido na nova URL
- Confirme que o usuário está sendo liberado automaticamente

## Formato da URL Final
Após o deploy, sua URL será algo como:
```
https://investidor-academy-pro.replit.app/api/webhook/broker-registration
```

## Verificação
Para verificar se o webhook está funcionando na nova URL:
1. Acesse: `https://SEU-DOMINIO.replit.app/api/webhook/status`
2. Deve retornar informações do sistema
3. Faça um teste de cadastro para confirmar funcionamento

## Importante
- O webhook funciona apenas no domínio configurado na X1-Broker
- Certifique-se de atualizar a URL exata após o deploy
- Teste sempre após mudanças de domínio

## Logs
Os logs do webhook continuarão funcionando normalmente e podem ser monitorados no console da aplicação.