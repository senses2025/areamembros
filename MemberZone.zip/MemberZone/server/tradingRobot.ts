import { storage } from "./storage";

interface TradingStrategy {
  name: string;
  analyze: (asset: string) => Promise<SignalResult>;
}

interface SignalResult {
  signal: 'CALL' | 'PUT' | null;
  strength: number;
  reason: string;
}

interface RobotConfig {
  isActive: boolean;
  activeAssets: string[];
  strategies: string[];
  minStrength: number;
  maxSignalsPerHour: number;
  useScheduledSignals: boolean;
  repeatList: boolean;
}

class TradingRobotEngine {
  private isRunning = false;
  private signalInterval: NodeJS.Timeout | null = null;
  private signalCount = 0;
  private lastSignalTime = 0;

  private readonly ASSETS = [
    'EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CHF',
    'NZD/USD', 'USD/CAD', 'EUR/GBP', 'EUR/JPY', 'GBP/JPY'
  ];

  private readonly strategies: TradingStrategy[] = [
    {
      name: 'RSI + Médias Móveis',
      analyze: this.rsiMaStrategy.bind(this)
    },
    {
      name: 'Suporte e Resistência',
      analyze: this.supportResistanceStrategy.bind(this)
    },
    {
      name: 'Padrões Candlestick',
      analyze: this.candlestickStrategy.bind(this)
    },
    {
      name: 'Fibonacci',
      analyze: this.fibonacciStrategy.bind(this)
    },
    {
      name: 'Momentum',
      analyze: this.momentumStrategy.bind(this)
    },
    {
      name: 'Breakout',
      analyze: this.breakoutStrategy.bind(this)
    }
  ];

  async start(): Promise<void> {
    if (this.isRunning) {
      console.log('🤖 Trading Robot: Already running');
      return;
    }

    console.log('🚀 Trading Robot: Starting signal generation...');
    this.isRunning = true;
    this.signalCount = 0;
    this.lastSignalTime = Date.now();

    // Generate first signal immediately, then every 30-60 seconds
    this.generateSignal();
    this.scheduleNextSignal();
  }

  async stop(): Promise<void> {
    if (!this.isRunning) {
      console.log('🤖 Trading Robot: Already stopped');
      return;
    }

    console.log('🛑 Trading Robot: Stopping signal generation...');
    this.isRunning = false;
    
    if (this.signalInterval) {
      clearTimeout(this.signalInterval);
      this.signalInterval = null;
    }
  }

  private scheduleNextSignal(): void {
    if (!this.isRunning) return;

    // Check if using scheduled signals mode
    this.getRobotConfig().then(config => {
      if (config.useScheduledSignals) {
        // For scheduled signals, check every minute
        const nextSignalDelay = 60 * 1000; // 1 minute
        
        this.signalInterval = setTimeout(async () => {
          await this.generateSignal();
          this.scheduleNextSignal();
        }, nextSignalDelay);

        console.log(`📅 Trading Robot: Checking scheduled signals in 1 minute`);
      } else {
        // Random interval between 1-2 minutes for automatic generation
        const nextSignalDelay = Math.random() * (2 - 1) * 60 * 1000 + 1 * 60 * 1000;
        
        this.signalInterval = setTimeout(async () => {
          await this.generateSignal();
          this.scheduleNextSignal();
        }, nextSignalDelay);

        console.log(`🕐 Trading Robot: Next signal in ${Math.round(nextSignalDelay / 60000)} minutes`);
      }
    });
  }

  private async generateSignal(): Promise<void> {
    try {
      const config = await this.getRobotConfig();
      
      if (!config.isActive) {
        console.log('🤖 Trading Robot: Config is inactive, skipping signal generation');
        return;
      }

      // Check if should use scheduled signals
      if (config.useScheduledSignals) {
        console.log('📅 Trading Robot: Using scheduled signals mode');
        await this.processScheduledSignals();
        return;
      }

      console.log('🎯 Trading Robot: Using automatic signal generation mode');

      // Check signal rate limits for automatic generation
      const hourAgo = Date.now() - (60 * 60 * 1000);
      if (this.signalCount >= config.maxSignalsPerHour && this.lastSignalTime > hourAgo) {
        console.log('🤖 Trading Robot: Signal rate limit reached, skipping');
        return;
      }

      // Reset counter if hour has passed
      if (this.lastSignalTime <= hourAgo) {
        this.signalCount = 0;
      }

      const asset = this.selectRandomAsset(config.activeAssets);
      const strategy = this.selectRandomStrategy(config.strategies);
      
      console.log(`🔍 Trading Robot: Analyzing ${asset} with ${strategy.name}`);
      
      const result = await strategy.analyze(asset);
      
      if (result.signal && result.strength >= Math.min(config.minStrength, 50)) {
        await this.createSignal(asset, result, strategy.name);
        this.signalCount++;
        this.lastSignalTime = Date.now();
        
        console.log(`✅ Trading Robot: Generated ${result.signal} signal for ${asset} (${result.strength}% strength)`);
        console.log(`📊 Signal Details: Asset=${asset}, Direction=${result.signal}, Strategy=${strategy.name}, Strength=${result.strength}%`);
      } else {
        console.log(`❌ Trading Robot: Signal rejected - ${asset} ${result.signal} ${result.strength}% (min: ${config.minStrength}%)`);
        console.log(`🕐 Trading Robot: Waiting for next analysis cycle...`);
      }
    } catch (error) {
      console.error('❌ Trading Robot: Error generating signal:', error);
    }
  }

  private async processScheduledSignals(): Promise<void> {
    try {
      const scheduledSignals = await storage.getScheduledSignals();
      
      if (scheduledSignals.length === 0) {
        console.log('📅 Trading Robot: No scheduled signals found');
        return;
      }

      const now = new Date();
      const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
      
      // Calculate time 3 minutes ahead (when signal should appear)
      const signalTime = new Date(now.getTime() + 3 * 60 * 1000);
      const targetTime = `${signalTime.getHours().toString().padStart(2, '0')}:${signalTime.getMinutes().toString().padStart(2, '0')}`;
      
      console.log(`📅 Trading Robot: Current time: ${currentTime}, Looking for signals at: ${targetTime}`);
      console.log(`📅 Trading Robot: Available signals:`, scheduledSignals.map(s => `${s.asset} ${s.direction} at ${s.time} (active: ${s.isActive})`));
      
      // Find signals that should appear now (3 minutes before execution)
      const matchingSignals = scheduledSignals.filter(signal => 
        signal.isActive && signal.time === targetTime
      );

      if (matchingSignals.length === 0) {
        console.log(`📅 Trading Robot: No signals to show for ${targetTime} (${scheduledSignals.length} total signals in list)`);
        return;
      }

      console.log(`🎯 Trading Robot: Found ${matchingSignals.length} signal(s) to show for ${targetTime}`);

      // Process each matching signal
      for (const signal of matchingSignals) {
        await this.createScheduledSignal(signal);
        console.log(`📅 Trading Robot: Showed scheduled signal - ${signal.asset} ${signal.direction} for ${signal.time}`);
        
        // Optional: deactivate signal after showing (if not repeating)
        const config = await this.getRobotConfig();
        if (!config.repeatList) {
          await storage.updateScheduledSignal(signal.id, { isActive: false });
        }
      }
    } catch (error) {
      console.error('❌ Trading Robot: Error processing scheduled signals:', error);
    }
  }

  private async createScheduledSignal(scheduledSignal: any): Promise<void> {
    try {
      const expirationMinutes = parseInt(scheduledSignal.expiration);
      const signalData = {
        asset: scheduledSignal.asset,
        signal: scheduledSignal.direction as 'CALL' | 'PUT',
        strategy: `Sinal Programado para ${scheduledSignal.time}`,
        strength: 100, // Scheduled signals are always 100% strength
        timeframe: `${expirationMinutes}min`,
        expirationTime: expirationMinutes,
        isActive: true,
        result: null,
        createdAt: new Date(),
      };

      await storage.createTradingSignal(signalData);
      
      // Auto-resolve signal after 3 minutes (when actual trade time arrives)
      setTimeout(async () => {
        await this.resolveSignalResult(scheduledSignal.asset, scheduledSignal.direction);
      }, 3 * 60 * 1000);
    } catch (error) {
      console.error('❌ Trading Robot: Error creating scheduled signal:', error);
    }
  }

  private selectRandomAsset(activeAssets: string[]): string {
    const assets = activeAssets.length > 0 ? activeAssets : this.ASSETS;
    return assets[Math.floor(Math.random() * assets.length)];
  }

  private selectRandomStrategy(activeStrategies: string[]): TradingStrategy {
    let strategies = this.strategies;
    
    if (activeStrategies.length > 0) {
      strategies = this.strategies.filter(s => activeStrategies.includes(s.name));
    }
    
    if (strategies.length === 0) {
      strategies = this.strategies;
    }
    
    return strategies[Math.floor(Math.random() * strategies.length)];
  }

  private async createSignal(asset: string, result: SignalResult, strategyName: string): Promise<void> {
    const expirationTime = this.getRandomExpirationTime();
    
    await storage.createTradingSignal({
      asset,
      signal: result.signal!,
      strategy: strategyName,
      strength: result.strength,
      timeframe: this.getRandomTimeframe(),
      expirationTime,
      isActive: true
    });

    // Schedule automatic result resolution
    setTimeout(async () => {
      await this.resolveSignalResult(asset, result.signal!);
    }, expirationTime * 60 * 1000);
  }

  private async resolveSignalResult(asset: string, signal: 'CALL' | 'PUT'): Promise<void> {
    try {
      // Get the most recent unresolved signal for this asset and signal type
      const activeSignals = await storage.getActiveSignals();
      const targetSignal = activeSignals.find(s => 
        s.asset === asset && 
        s.signal === signal && 
        !s.result
      );

      if (targetSignal) {
        // Generate realistic result (75% win rate for demonstration)
        const isWin = Math.random() < 0.75;
        const result = isWin ? 'WIN' : 'LOSS';
        
        await storage.updateSignalResult(targetSignal.id, result);
        console.log(`📊 Trading Robot: Signal resolved - ${asset} ${signal} = ${result}`);
      }
    } catch (error) {
      console.error('❌ Trading Robot: Error resolving signal result:', error);
    }
  }

  private getRandomExpirationTime(): number {
    // Always use 1 minute expiration as requested
    return 1;
  }

  private getRandomTimeframe(): string {
    const timeframes = ['1min', '5min', '15min', '1h'];
    return timeframes[Math.floor(Math.random() * timeframes.length)];
  }

  private async getRobotConfig(): Promise<RobotConfig> {
    try {
      const config = await storage.getRobotConfig();
      return {
        isActive: config?.isActive ?? true,
        activeAssets: (config?.activeAssets as string[]) ?? this.ASSETS,
        strategies: (config?.strategies as string[]) ?? this.strategies.map(s => s.name),
        minStrength: config?.minStrength ?? 60,
        maxSignalsPerHour: config?.maxSignalsPerHour ?? 20,
        useScheduledSignals: config?.useScheduledSignals ?? false,
        repeatList: config?.repeatList ?? false
      };
    } catch {
      return {
        isActive: true,
        activeAssets: this.ASSETS,
        strategies: this.strategies.map(s => s.name),
        minStrength: 60,
        maxSignalsPerHour: 20,
        useScheduledSignals: false,
        repeatList: false
      };
    }
  }

  // Trading Strategy Implementations
  private async rsiMaStrategy(asset: string): Promise<SignalResult> {
    // Simulate RSI + Moving Average analysis with higher probability of strong signals
    const rsi = Math.random() * 100;
    const maSignal = Math.random() > 0.4 ? 'bullish' : 'bearish'; // More bullish bias
    
    let signal: 'CALL' | 'PUT' | null = null;
    let strength = 0;
    let reason = '';

    // Higher chance of generating strong signals
    if (rsi < 35 && maSignal === 'bullish') {
      signal = 'CALL';
      strength = Math.floor(80 + Math.random() * 15);
      reason = `RSI oversold (${rsi.toFixed(1)}) + MA bullish convergence`;
    } else if (rsi > 65 && maSignal === 'bearish') {
      signal = 'PUT';
      strength = Math.floor(80 + Math.random() * 15);
      reason = `RSI overbought (${rsi.toFixed(1)}) + MA bearish divergence`;
    } else if (rsi < 50 && maSignal === 'bullish') {
      signal = 'CALL';
      strength = Math.floor(70 + Math.random() * 15);
      reason = `RSI bullish zone + MA uptrend confirmation`;
    } else if (rsi > 50 && maSignal === 'bearish') {
      signal = 'PUT';
      strength = Math.floor(70 + Math.random() * 15);
      reason = `RSI bearish zone + MA downtrend confirmation`;
    } else {
      // Force a signal even with mixed signals
      signal = Math.random() > 0.5 ? 'CALL' : 'PUT';
      strength = Math.floor(65 + Math.random() * 15);
      reason = `Moderate ${signal === 'CALL' ? 'bullish' : 'bearish'} setup - RSI: ${rsi.toFixed(1)}`;
    }

    return { signal, strength, reason };
  }

  private async supportResistanceStrategy(asset: string): Promise<SignalResult> {
    // Simulate support/resistance analysis
    const pricePosition = Math.random(); // 0 = support, 1 = resistance
    const bounceStrength = Math.random() * 100;
    
    let signal: 'CALL' | 'PUT' | null = null;
    let strength = 0;
    let reason = '';

    if (pricePosition < 0.2 && bounceStrength > 70) {
      signal = 'CALL';
      strength = Math.floor(70 + Math.random() * 25);
      reason = 'Strong bounce from support level';
    } else if (pricePosition > 0.8 && bounceStrength > 70) {
      signal = 'PUT';
      strength = Math.floor(70 + Math.random() * 25);
      reason = 'Strong rejection at resistance level';
    } else {
      strength = Math.floor(40 + Math.random() * 30);
      reason = 'Price between support and resistance';
    }

    return { signal, strength, reason };
  }

  private async candlestickStrategy(asset: string): Promise<SignalResult> {
    // Simulate candlestick pattern analysis
    const patterns = [
      { name: 'Doji', bullish: false, bearish: false },
      { name: 'Hammer', bullish: true, bearish: false },
      { name: 'Shooting Star', bullish: false, bearish: true },
      { name: 'Engulfing Bull', bullish: true, bearish: false },
      { name: 'Engulfing Bear', bullish: false, bearish: true },
      { name: 'Morning Star', bullish: true, bearish: false },
      { name: 'Evening Star', bullish: false, bearish: true }
    ];

    const pattern = patterns[Math.floor(Math.random() * patterns.length)];
    const confirmation = Math.random() > 0.3;
    
    let signal: 'CALL' | 'PUT' | null = null;
    let strength = 0;
    let reason = '';

    if (pattern.bullish && confirmation) {
      signal = 'CALL';
      strength = Math.floor(65 + Math.random() * 30);
      reason = `Bullish ${pattern.name} pattern confirmed`;
    } else if (pattern.bearish && confirmation) {
      signal = 'PUT';
      strength = Math.floor(65 + Math.random() * 30);
      reason = `Bearish ${pattern.name} pattern confirmed`;
    } else {
      strength = Math.floor(35 + Math.random() * 35);
      reason = `${pattern.name} pattern without confirmation`;
    }

    return { signal, strength, reason };
  }

  private async fibonacciStrategy(asset: string): Promise<SignalResult> {
    // Simulate Fibonacci retracement analysis
    const fibLevel = Math.random();
    const trendDirection = Math.random() > 0.5 ? 'up' : 'down';
    
    let signal: 'CALL' | 'PUT' | null = null;
    let strength = 0;
    let reason = '';

    // Key Fibonacci levels: 38.2%, 50%, 61.8%
    if (Math.abs(fibLevel - 0.382) < 0.05 || Math.abs(fibLevel - 0.618) < 0.05) {
      if (trendDirection === 'up') {
        signal = 'CALL';
        strength = Math.floor(70 + Math.random() * 25);
        reason = `Bounce from ${(fibLevel * 100).toFixed(1)}% Fibonacci level in uptrend`;
      } else {
        signal = 'PUT';
        strength = Math.floor(70 + Math.random() * 25);
        reason = `Rejection at ${(fibLevel * 100).toFixed(1)}% Fibonacci level in downtrend`;
      }
    } else {
      strength = Math.floor(40 + Math.random() * 30);
      reason = 'Price not at significant Fibonacci level';
    }

    return { signal, strength, reason };
  }

  private async momentumStrategy(asset: string): Promise<SignalResult> {
    // Simulate momentum analysis
    const momentum = (Math.random() - 0.5) * 200; // -100 to +100
    const volume = Math.random() * 100;
    
    let signal: 'CALL' | 'PUT' | null = null;
    let strength = 0;
    let reason = '';

    if (momentum > 60 && volume > 70) {
      signal = 'CALL';
      strength = Math.floor(75 + Math.random() * 20);
      reason = `Strong bullish momentum (${momentum.toFixed(1)}) with high volume`;
    } else if (momentum < -60 && volume > 70) {
      signal = 'PUT';
      strength = Math.floor(75 + Math.random() * 20);
      reason = `Strong bearish momentum (${momentum.toFixed(1)}) with high volume`;
    } else {
      strength = Math.floor(30 + Math.random() * 40);
      reason = `Weak momentum (${momentum.toFixed(1)}) or low volume (${volume.toFixed(1)})`;
    }

    return { signal, strength, reason };
  }

  private async breakoutStrategy(asset: string): Promise<SignalResult> {
    // Simulate breakout analysis
    const volatility = Math.random() * 100;
    const breakoutDirection = Math.random() > 0.5 ? 'up' : 'down';
    const volume = Math.random() * 100;
    
    let signal: 'CALL' | 'PUT' | null = null;
    let strength = 0;
    let reason = '';

    if (volatility > 70 && volume > 60) {
      if (breakoutDirection === 'up') {
        signal = 'CALL';
        strength = Math.floor(80 + Math.random() * 15);
        reason = `Bullish breakout with high volatility (${volatility.toFixed(1)}) and volume`;
      } else {
        signal = 'PUT';
        strength = Math.floor(80 + Math.random() * 15);
        reason = `Bearish breakout with high volatility (${volatility.toFixed(1)}) and volume`;
      }
    } else {
      strength = Math.floor(25 + Math.random() * 45);
      reason = 'No significant breakout detected';
    }

    return { signal, strength, reason };
  }

  isActive(): boolean {
    return this.isRunning;
  }

  getStatus() {
    return {
      isRunning: this.isRunning,
      signalsGenerated: this.signalCount,
      lastSignalTime: this.lastSignalTime,
      nextSignalEta: this.signalInterval ? 'Calculating...' : 'Stopped'
    };
  }
}

// Singleton instance
export const tradingRobot = new TradingRobotEngine();