import { Request, Response } from 'express';
import { storage } from './storage';
import { Logger } from './logger';
import bcrypt from 'bcrypt';

// Interface para dados recebidos da corretora
interface BrokerUserData {
  nome: string;
  email: string;
  telefone: string;
  id_corretora: string;
  data_cadastro?: string;
  status?: string;
}

// Classe para gerenciar o webhook da corretora
export class BrokerWebhook {
  
  /**
   * Processa o webhook de cadastro de usuário da corretora
   */
  static async processUserRegistration(req: Request, res: Response): Promise<void> {
    try {
      // Log da requisição recebida
      console.log('📥 WEBHOOK RECEBIDO DA CORRETORA');
      console.log('Headers:', req.headers);
      console.log('Body:', JSON.stringify(req.body, null, 2));
      console.log('IP:', req.ip || req.headers['x-forwarded-for']);
      
      // Extrair dados do body
      const userData = BrokerWebhook.extractUserData(req.body);
      
      // Validar dados obrigatórios
      const validation = BrokerWebhook.validateUserData(userData);
      if (!validation.isValid) {
        console.log('❌ DADOS INVÁLIDOS:', validation.errors);
        res.status(400).json({
          success: false,
          message: 'Dados inválidos',
          errors: validation.errors
        });
        return;
      }
      
      // Verificar se usuário já existe
      const existingUser = await storage.getUserByEmail(userData.email);
      
      if (existingUser) {
        console.log('⚠️ USUÁRIO JÁ EXISTE:', userData.email);
        res.status(409).json({
          success: false,
          message: 'Usuário já está cadastrado',
          email: userData.email,
          existing_user_id: existingUser.id
        });
        return;
      }
      
      // Criar novo usuário
      const newUser = await BrokerWebhook.createBrokerUser(userData);
      
      console.log('✅ USUÁRIO CRIADO COM SUCESSO:', {
        id: newUser.id,
        email: newUser.email,
        name: newUser.name
      });
      
      // Resposta de sucesso
      res.status(200).json({
        success: true,
        message: 'Usuário cadastrado com sucesso',
        user: {
          id: newUser.id,
          email: newUser.email,
          name: newUser.name,
          isPremium: newUser.isPremium,
          created_at: newUser.createdAt
        }
      });
      
    } catch (error: any) {
      console.error('❌ ERRO NO WEBHOOK:', error);
      
      res.status(500).json({
        success: false,
        message: 'Erro interno do servidor',
        error: error.message
      });
    }
  }
  
  /**
   * Extrai dados do usuário do body da requisição
   */
  private static extractUserData(body: any): BrokerUserData {
    return {
      nome: body.nome || body.name || body.full_name || body.usuario || '',
      email: body.email || body.e_mail || body.user_email || body.login || '',
      telefone: body.telefone || body.phone || body.celular || body.whatsapp || '',
      id_corretora: body.id_corretora || body.broker_id || body.user_id || body.id || '',
      data_cadastro: body.data_cadastro || body.created_at || body.registration_date,
      status: body.status || body.evento || 'cadastrado'
    };
  }
  
  /**
   * Valida os dados obrigatórios do usuário
   */
  private static validateUserData(userData: BrokerUserData): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];
    
    if (!userData.nome || userData.nome.trim().length < 2) {
      errors.push('Nome é obrigatório e deve ter pelo menos 2 caracteres');
    }
    
    if (!userData.email || !BrokerWebhook.isValidEmail(userData.email)) {
      errors.push('Email válido é obrigatório');
    }
    
    if (!userData.telefone || userData.telefone.trim().length < 8) {
      errors.push('Telefone é obrigatório e deve ter pelo menos 8 caracteres');
    }
    
    if (!userData.id_corretora || userData.id_corretora.trim().length === 0) {
      errors.push('ID da corretora é obrigatório');
    }
    
    return {
      isValid: errors.length === 0,
      errors
    };
  }
  
  /**
   * Valida formato de email
   */
  private static isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }
  
  /**
   * Cria um usuário premium vindo da corretora
   */
  private static async createBrokerUser(userData: BrokerUserData) {
    // Gerar senha temporária
    const tempPassword = Math.random().toString(36).slice(-8);
    const hashedPassword = await bcrypt.hash(tempPassword, 10);
    
    // Criar usuário como premium (vem da corretora)
    const user = await storage.createUser({
      name: userData.nome,
      email: userData.email,
      password: hashedPassword,
      role: 'user',
      isPremium: true, // Usuários da corretora são premium
      brokerRegistered: true
    });
    
    // Log para administração
    Logger.info(`Novo usuário criado via webhook da corretora: ${userData.email}`, {
      user_id: user.id,
      broker_id: userData.id_corretora,
      phone: userData.telefone,
      temp_password: tempPassword // Para logs administrativos
    });
    
    return user;
  }
  
  /**
   * Endpoint para testar conectividade do webhook
   */
  static async testWebhook(req: Request, res: Response): Promise<void> {
    console.log('🧪 TESTE DE WEBHOOK');
    console.log('Method:', req.method);
    console.log('Headers:', req.headers);
    console.log('Body:', req.body);
    
    res.status(200).json({
      success: true,
      message: 'Webhook está funcionando',
      timestamp: new Date().toISOString(),
      received_data: req.body
    });
  }
  
  /**
   * Endpoint para verificar status do webhook
   */
  static async getWebhookStatus(req: Request, res: Response): Promise<void> {
    const totalUsers = await storage.getAllUsers();
    const premiumUsers = totalUsers.filter(user => user.isPremium);
    
    res.status(200).json({
      success: true,
      message: 'Webhook da corretora está ativo',
      status: 'active',
      statistics: {
        total_users: totalUsers.length,
        premium_users: premiumUsers.length,
        broker_users: totalUsers.filter(user => user.brokerRegistered).length
      },
      endpoints: {
        registration: '/webhook/broker/user-registration',
        test: '/webhook/broker/test',
        status: '/webhook/broker/status'
      },
      timestamp: new Date().toISOString()
    });
  }
}