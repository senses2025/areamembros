import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { loginSchema, registerSchema, insertTradingLogSchema, insertVideoSchema, insertLiveStreamSchema, tradingLogs } from "@shared/schema";
import { z } from "zod";
import { tradingRobot } from "./tradingRobot";
import { Logger } from "./logger";
import { db } from "./db";
import { eq } from "drizzle-orm";
// import { BrokerWebhook } from "./webhook"; // Removido - webhook movido para index.ts

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// Middleware to verify JWT token
const authenticateToken = async (req: Request, res: Response, next: Function) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    const user = await storage.getUser(decoded.userId);
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }
    (req as any).user = user;
    next();
  } catch (error) {
    return res.status(403).json({ message: 'Invalid token' });
  }
};

// Middleware to check if user is admin
const requireAdmin = (req: Request, res: Response, next: Function) => {
  const user = (req as any).user;
  if (user.role !== 'admin') {
    return res.status(403).json({ message: 'Admin access required' });
  }
  next();
};

// Middleware to check if user is premium
const requirePremium = (req: Request, res: Response, next: Function) => {
  const user = (req as any).user;
  if (!user.isPremium && user.role !== 'admin') {
    return res.status(403).json({ message: 'Premium access required' });
  }
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {

  // ========================================================================================
  // WEBHOOK ROUTES - MOVIDAS PARA server/index.ts
  // ========================================================================================
  
  // Nota: Os webhooks foram movidos para server/index.ts para evitar interceptação do Vite
  // Endpoints disponíveis:
  // - POST /api/webhook/broker-registration
  // - GET /api/webhook/status

  // ========================================================================================
  // ACCOUNT MANAGEMENT ROUTES
  // ========================================================================================
  
  // Endpoint para admin aprovar usuários pendentes
  app.post("/api/admin/approve-user/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "ID de usuário inválido" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }
      
      const updatedUser = await storage.updateUser(userId, {
        isPremium: true,
        accountStatus: 'premium_released'
      });
      
      Logger.info(`Admin approved user: ${user.email} (ID: ${userId})`);
      
      res.json({
        success: true,
        message: "Usuário aprovado com sucesso",
        user: {
          id: updatedUser.id,
          email: updatedUser.email,
          name: updatedUser.name,
          isPremium: updatedUser.isPremium,
          accountStatus: updatedUser.accountStatus
        }
      });
    } catch (error) {
      Logger.error("Error approving user:", error);
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });
  
  // Endpoint para admin rejeitar usuários pendentes
  app.post("/api/admin/reject-user/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "ID de usuário inválido" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }
      
      const updatedUser = await storage.updateUser(userId, {
        isPremium: false,
        accountStatus: 'not_released'
      });
      
      Logger.info(`Admin rejected user: ${user.email} (ID: ${userId})`);
      
      res.json({
        success: true,
        message: "Usuário rejeitado",
        user: {
          id: updatedUser.id,
          email: updatedUser.email,
          name: updatedUser.name,
          isPremium: updatedUser.isPremium,
          accountStatus: updatedUser.accountStatus
        }
      });
    } catch (error) {
      Logger.error("Error rejecting user:", error);
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });
  
  // Endpoint para listar usuários pendentes de aprovação
  app.get("/api/admin/pending-users", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const allUsers = await storage.getAllUsers();
      const pendingUsers = allUsers.filter(user => user.accountStatus === 'pending_review');
      
      res.json({
        success: true,
        count: pendingUsers.length,
        users: pendingUsers.map(user => ({
          id: user.id,
          name: user.name,
          email: user.email,
          brokerUserId: user.brokerUserId,
          accountStatus: user.accountStatus,
          createdAt: user.createdAt
        }))
      });
    } catch (error) {
      Logger.error("Error fetching pending users:", error);
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });
  
  // Endpoint para redirecionar usuário para corretora
  app.get("/api/broker-redirect", authenticateToken, async (req, res) => {
    const user = (req as any).user;
    
    // URL da corretora (pode ser configurável)
    const brokerUrl = "https://x1-broker.com/account/signup";
    
    Logger.info(`User redirected to broker: ${user.email}`);
    
    res.json({
      success: true,
      message: "Redirecionando para corretora",
      redirect_url: brokerUrl,
      user: {
        id: user.id,
        email: user.email,
        accountStatus: user.accountStatus
      }
    });
  });
  
  // Endpoint para verificar status da conta
  app.get("/api/account-status", authenticateToken, async (req, res) => {
    const user = (req as any).user;
    
    res.json({
      success: true,
      account: {
        id: user.id,
        email: user.email,
        name: user.name,
        isPremium: user.isPremium,
        accountStatus: user.accountStatus,
        brokerRegistered: user.brokerRegistered,
        brokerUserId: user.brokerUserId,
        canAccessPremium: user.accountStatus === 'premium_released' && user.isPremium
      }
    });
  });

  // ========================================================================================
  // AUTHENTICATION ROUTES
  // ========================================================================================
  
  app.post("/api/auth/register", async (req, res) => {
    try {
      const result = registerSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid input", errors: result.error.issues });
      }

      const { name, email, password } = result.data;
      
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const user = await storage.createUser({
        name,
        email,
        password: hashedPassword,
        role: "user",
        isPremium: false,
        brokerRegistered: false
      });

      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });
      
      res.json({ 
        token, 
        user: { 
          id: user.id, 
          name: user.name, 
          email: user.email, 
          role: user.role,
          isPremium: user.isPremium 
        } 
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const result = loginSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid input" });
      }

      const { email, password } = result.data;
      const user = await storage.getUserByEmail(email);
      
      if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });
      
      res.json({ 
        token, 
        user: { 
          id: user.id, 
          name: user.name, 
          email: user.email, 
          role: user.role,
          isPremium: user.isPremium 
        } 
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Webhook login for premium users created via webhook
  app.post("/api/auth/webhook-login", async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email é obrigatório" });
      }

      // Find user by email
      const user = await storage.getUserByEmail(email);
      
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }

      // Check if user is premium and was created via webhook
      if (!user.isPremium || !user.brokerRegistered) {
        return res.status(403).json({ 
          message: "Acesso negado. Usuário deve ser premium e registrado via corretora." 
        });
      }

      // Generate JWT token
      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });
      
      console.log(`🔐 WEBHOOK LOGIN realizado para: ${email}`);
      console.log(`✅ Usuário premium autenticado: ID ${user.id}`);
      
      res.json({ 
        token, 
        user: { 
          id: user.id, 
          name: user.name, 
          email: user.email, 
          role: user.role,
          isPremium: user.isPremium,
          brokerRegistered: user.brokerRegistered
        } 
      });
    } catch (error) {
      console.error('Erro no webhook login:', error);
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Live Streams Routes
  app.get("/api/live-streams", async (req, res) => {
    try {
      const streams = await storage.getAllLiveStreams();
      res.json(streams);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/live-streams/current", async (req, res) => {
    try {
      const currentStream = await storage.getCurrentLiveStream();
      res.json(currentStream);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/live-streams", authenticateToken, requireAdmin, async (req, res) => {
    try {
      // Preparar dados da live stream
      const streamData = {
        title: req.body.title,
        description: req.body.description,
        streamUrl: req.body.streamUrl,
        platform: req.body.platform || 'youtube',
        scheduledAt: req.body.scheduledAt ? new Date(req.body.scheduledAt) : new Date(),
        isPremium: req.body.isPremium || false,
        isLive: req.body.isLive || false,
        embedCode: req.body.embedCode || null,
        meetingLink: req.body.meetingLink || null,
        viewerCount: req.body.viewerCount || 0,
      };

      const stream = await storage.createLiveStream(streamData);
      Logger.info(`Live stream created: ${stream.title}`);
      res.json(stream);
    } catch (error) {
      Logger.error("Error creating live stream:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/live-streams/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const streamId = parseInt(req.params.id);
      
      if (isNaN(streamId) || streamId <= 0) {
        return res.status(400).json({ message: "Invalid stream ID" });
      }

      await storage.deleteLiveStream(streamId);
      Logger.info(`Live stream deleted: ${streamId}`);
      res.json({ message: "Live stream deleted successfully" });
    } catch (error) {
      Logger.error("Error deleting live stream:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/live-streams/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const streamId = parseInt(req.params.id);
      
      if (isNaN(streamId) || streamId <= 0) {
        return res.status(400).json({ message: "Invalid stream ID" });
      }

      const updates = req.body;
      const stream = await storage.updateLiveStream(streamId, updates);
      
      if (!stream) {
        return res.status(404).json({ message: "Live stream not found" });
      }

      Logger.info(`Live stream updated: ${streamId} - ${JSON.stringify(updates)}`);
      res.json(stream);
    } catch (error) {
      Logger.error("Error updating live stream:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req, res) => {
    const user = (req as any).user;
    res.json({ 
      id: user.id, 
      name: user.name, 
      email: user.email, 
      role: user.role,
      isPremium: user.isPremium 
    });
  });

  // ========================================================================================
  // VIDEO/CONTENT MANAGEMENT ROUTES
  // ========================================================================================
  
  app.get("/api/videos", async (req, res) => {
    try {
      const videos = await storage.getAllVideos();
      res.json(videos);
    } catch (error) {
      Logger.error("Error fetching videos:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/videos", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const videoData = {
        title: req.body.title,
        description: req.body.description,
        videoUrl: req.body.videoUrl,
        thumbnailUrl: req.body.thumbnailUrl,
        category: req.body.category,
        level: req.body.level || 'básico',
        instructor: req.body.instructor || 'Investidor Academy',
        tags: req.body.tags,
        language: req.body.language || 'pt-BR',
        isPremium: req.body.isPremium || false,
        isFeatured: req.body.isFeatured || false,
        order: req.body.order || 0,
      };

      const video = await storage.createVideo(videoData);
      Logger.info(`Video created: ${video.title} (ID: ${video.id})`);
      res.json(video);
    } catch (error) {
      Logger.error("Error creating video:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/videos/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      
      if (isNaN(videoId) || videoId <= 0) {
        return res.status(400).json({ message: "Invalid video ID" });
      }

      const updates = req.body;
      const video = await storage.updateVideo(videoId, updates);
      
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }

      Logger.info(`Video updated: ${videoId} - ${JSON.stringify(updates)}`);
      res.json(video);
    } catch (error) {
      Logger.error("Error updating video:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/videos/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      
      if (isNaN(videoId) || videoId <= 0) {
        return res.status(400).json({ message: "Invalid video ID" });
      }

      await storage.deleteVideo(videoId);
      Logger.info(`Video deleted: ${videoId}`);
      res.json({ message: "Video deleted successfully" });
    } catch (error) {
      Logger.error("Error deleting video:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // ========================================================================================
  // USER MANAGEMENT ROUTES
  // ========================================================================================
  
  app.get("/api/users", authenticateToken, requireAdmin, async (req, res) => {
    try {
      console.log('[DEBUG] Iniciando busca de usuários...');
      const users = await storage.getAllUsers();
      console.log(`[DEBUG] Encontrados ${users.length} usuários`);
      
      const mappedUsers = users.map(user => ({
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        isPremium: user.isPremium,
        brokerRegistered: user.brokerRegistered,
        createdAt: user.createdAt
      }));
      
      console.log('[DEBUG] Primeiros 2 usuários:', mappedUsers.slice(0, 2));
      res.json(mappedUsers);
    } catch (error) {
      console.error('[DEBUG] Erro ao buscar usuários:', error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/users/:id/premium", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { isPremium } = req.body;
      
      // Validate userId
      if (isNaN(userId) || userId <= 0) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Validate isPremium
      if (typeof isPremium !== 'boolean') {
        return res.status(400).json({ message: "isPremium must be a boolean" });
      }
      
      Logger.info(`Admin updating user ${userId} premium status to ${isPremium}`);
      
      await storage.updateUserPremiumStatus(userId, isPremium);
      res.json({ message: "User premium status updated successfully" });
    } catch (error) {
      Logger.error("Error updating user premium status:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // ========================================================================================
  // TRADING ROBOT ROUTES
  // ========================================================================================
  
  app.post("/api/robot/start", authenticateToken, requirePremium, async (req, res) => {
    try {
      await tradingRobot.start();
      res.json({ success: true, message: "Trading robot started" });
    } catch (error) {
      res.status(500).json({ message: "Failed to start robot" });
    }
  });

  app.post("/api/robot/stop", authenticateToken, requirePremium, async (req, res) => {
    try {
      await tradingRobot.stop();
      res.json({ success: true, message: "Trading robot stopped" });
    } catch (error) {
      res.status(500).json({ message: "Failed to stop robot" });
    }
  });

  app.get("/api/robot/status", authenticateToken, requirePremium, async (req, res) => {
    try {
      const status = tradingRobot.getStatus();
      res.json({ robot: status });
    } catch (error) {
      res.status(500).json({ message: "Failed to get robot status" });
    }
  });

  app.get("/api/robot/config", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const config = await storage.getRobotConfig();
      res.json(config || {
        isActive: true,
        activeAssets: [],
        strategies: [],
        minStrength: 70,
        maxSignalsPerHour: 10,
        useScheduledSignals: false,
        repeatList: false
      });
    } catch (error) {
      Logger.error("Error fetching robot config:", error);
      res.status(500).json({ message: "Failed to get robot config" });
    }
  });

  app.patch("/api/robot/config", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const updates = req.body;
      await storage.updateRobotConfig(updates);
      
      Logger.info(`Robot config updated: ${JSON.stringify(updates)}`);
      res.json({ message: "Robot configuration updated successfully" });
    } catch (error) {
      Logger.error("Error updating robot config:", error);
      res.status(500).json({ message: "Failed to update robot config" });
    }
  });

  // ========================================================================================
  // TRADING SIGNALS ROUTES
  // ========================================================================================
  
  app.get("/api/trading-signals", authenticateToken, requirePremium, async (req, res) => {
    try {
      const signals = await storage.getActiveSignals();
      res.json(signals);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // ========================================================================================
  // SCHEDULED SIGNALS ROUTES (ADMIN ONLY)
  // ========================================================================================
  
  app.get("/api/scheduled-signals", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const signals = await storage.getScheduledSignals();
      res.json(signals);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/scheduled-signals", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const signal = await storage.createScheduledSignal(req.body);
      res.status(201).json(signal);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/scheduled-signals/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const signal = await storage.updateScheduledSignal(id, req.body);
      if (!signal) {
        return res.status(404).json({ message: "Signal not found" });
      }
      res.json(signal);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/scheduled-signals/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteScheduledSignal(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/scheduled-signals", authenticateToken, requireAdmin, async (req, res) => {
    try {
      await storage.clearScheduledSignals();
      res.json({ success: true, message: "All scheduled signals cleared" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // ========================================================================================
  // DASHBOARD CONFIGURATION ROUTES
  // ========================================================================================
  
  app.get("/api/dashboard-config", authenticateToken, async (req, res) => {
    try {
      const settings = await storage.getPlatformSettings();
      const configMap = settings.reduce((acc, setting) => {
        acc[setting.key] = setting.value;
        return acc;
      }, {} as any);

      // Default configuration if not set
      const defaultConfig = {
        "dashboard_card1_title": "Operações Hoje",
        "dashboard_card1_value": "0",
        "dashboard_card1_subtitle": "0 WINs / 0 LOSSes",
        "dashboard_card2_title": "Taxa de Acerto",
        "dashboard_card2_value": "0%",
        "dashboard_card2_subtitle": "Hoje",
        "dashboard_card3_title": "Resultado Hoje",
        "dashboard_card3_value": "R$ 0,00",
        "dashboard_card3_subtitle": "Lucro/Prejuízo",
        "dashboard_card4_title": "Próxima Live",
        "dashboard_card4_value": "19:30",
        "dashboard_card4_subtitle": "Estratégias Avançadas"
      };

      const config = {
        card1: {
          title: configMap["dashboard_card1_title"] || defaultConfig["dashboard_card1_title"],
          value: configMap["dashboard_card1_value"] || defaultConfig["dashboard_card1_value"],
          subtitle: configMap["dashboard_card1_subtitle"] || defaultConfig["dashboard_card1_subtitle"]
        },
        card2: {
          title: configMap["dashboard_card2_title"] || defaultConfig["dashboard_card2_title"],
          value: configMap["dashboard_card2_value"] || defaultConfig["dashboard_card2_value"],
          subtitle: configMap["dashboard_card2_subtitle"] || defaultConfig["dashboard_card2_subtitle"]
        },
        card3: {
          title: configMap["dashboard_card3_title"] || defaultConfig["dashboard_card3_title"],
          value: configMap["dashboard_card3_value"] || defaultConfig["dashboard_card3_value"],
          subtitle: configMap["dashboard_card3_subtitle"] || defaultConfig["dashboard_card3_subtitle"]
        },
        card4: {
          title: configMap["dashboard_card4_title"] || defaultConfig["dashboard_card4_title"],
          value: configMap["dashboard_card4_value"] || defaultConfig["dashboard_card4_value"],
          subtitle: configMap["dashboard_card4_subtitle"] || defaultConfig["dashboard_card4_subtitle"]
        }
      };

      res.json(config);
    } catch (error: any) {
      Logger.error("GET /api/dashboard-config", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/dashboard-config", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { card1, card2, card3, card4 } = req.body;

      // Save each card configuration
      const updates = [
        ["dashboard_card1_title", card1.title],
        ["dashboard_card1_value", card1.value],
        ["dashboard_card1_subtitle", card1.subtitle],
        ["dashboard_card2_title", card2.title],
        ["dashboard_card2_value", card2.value],
        ["dashboard_card2_subtitle", card2.subtitle],
        ["dashboard_card3_title", card3.title],
        ["dashboard_card3_value", card3.value],
        ["dashboard_card3_subtitle", card3.subtitle],
        ["dashboard_card4_title", card4.title],
        ["dashboard_card4_value", card4.value],
        ["dashboard_card4_subtitle", card4.subtitle]
      ];

      for (const [key, value] of updates) {
        await storage.updatePlatformSetting(key, value);
      }

      Logger.info("Dashboard configuration updated successfully");
      res.json({ success: true, message: "Dashboard configuration updated" });
    } catch (error: any) {
      Logger.error("POST /api/dashboard-config", error);
      res.status(500).json({ error: error.message });
    }
  });

  // ========================================================================================
  // TRADING STATISTICS ROUTES
  // ========================================================================================
  
  app.get("/api/trading-stats", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      // Buscar todos os logs de trading de hoje de todos os usuários
      const allUsers = await storage.getAllUsers();
      let totalOperations = 0;
      let totalWins = 0;
      let totalLosses = 0;
      let totalAmount = 0;

      for (const user of allUsers) {
        try {
          const logs = await storage.getTradingLogsByDateRange(user.id, today, tomorrow);
          
          for (const log of logs) {
            totalOperations++;
            if (log.type === 'WIN') {
              totalWins++;
              totalAmount += parseFloat(log.amount.toString());
            } else if (log.type === 'LOSS') {
              totalLosses++;
              totalAmount -= parseFloat(log.amount.toString());
            }
          }
        } catch (error) {
          // Continue if user has no trading data
          continue;
        }
      }

      const winRate = totalOperations > 0 ? Math.round((totalWins / totalOperations) * 100) : 0;

      // Garantir que sempre retornamos dados válidos
      const stats = {
        totalOperations: totalOperations || 0,
        totalWins: totalWins || 0,
        totalLosses: totalLosses || 0,
        winRate: winRate || 0,
        totalAmount: totalAmount ? Math.round(totalAmount * 100) / 100 : 0,
        date: today.toISOString()
      };

      Logger.info(`Trading stats calculated: ${JSON.stringify(stats)}`);
      res.json(stats);
    } catch (error) {
      Logger.error("Error fetching trading stats:", error);
      // Retornar dados padrão em caso de erro
      res.json({
        totalOperations: 0,
        totalWins: 0,
        totalLosses: 0,
        winRate: 0,
        totalAmount: 0,
        date: new Date().toISOString()
      });
    }
  });

  app.get("/api/trading-logs", authenticateToken, requireAdmin, async (req, res) => {
    try {
      // Buscar todos os trading logs com informações do usuário
      const allUsers = await storage.getAllUsers();
      const allLogs = [];

      for (const user of allUsers) {
        try {
          const userLogs = await storage.getUserTradingLogs(user.id);
          for (const log of userLogs) {
            allLogs.push({
              ...log,
              userName: user.name,
              userEmail: user.email
            });
          }
        } catch (error) {
          continue;
        }
      }

      // Ordenar por data mais recente primeiro
      allLogs.sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateB - dateA;
      });

      res.json(allLogs);
    } catch (error) {
      Logger.error("Error fetching trading logs:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });



  // ========================================================================================
  // VERIFICATION ENDPOINT FOR BROKER REGISTRATION
  // ========================================================================================
  
  app.get("/api/registration-status", authenticateToken, async (req, res) => {
    try {
      const user = (req as any).user;
      const currentUser = await storage.getUser(user.id);
      
      res.json({
        isPremium: currentUser?.isPremium || false,
        brokerRegistered: currentUser?.brokerRegistered || false
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Sistema webhook já implementado acima - removendo duplicações
  
  // REMOVIDO - catch-all estava bloqueando os webhooks

  const httpServer = createServer(app);
  
  return httpServer;
}