import { Request, Response } from 'express';

export class Logger {
  private static getTimestamp(): string {
    return new Date().toISOString().replace('T', ' ').replace('Z', '');
  }

  private static formatDuration(ms: number): string {
    if (ms < 1000) return `${ms}ms`;
    return `${(ms / 1000).toFixed(2)}s`;
  }

  static info(message: string, context?: any): void {
    const timestamp = this.getTimestamp();
    console.log(`[${timestamp}] [INFO] ${message}`);
    if (context) {
      console.log(`[${timestamp}] [INFO] Context:`, JSON.stringify(context, null, 2));
    }
  }

  static error(message: string, error?: any): void {
    const timestamp = this.getTimestamp();
    console.error(`[${timestamp}] [ERROR] ${message}`);
    if (error) {
      console.error(`[${timestamp}] [ERROR] Details:`, error);
    }
  }

  static warning(message: string, context?: any): void {
    const timestamp = this.getTimestamp();
    console.warn(`[${timestamp}] [WARN] ${message}`);
    if (context) {
      console.warn(`[${timestamp}] [WARN] Context:`, JSON.stringify(context, null, 2));
    }
  }

  static webhook(req: Request, type: string = 'WEBHOOK'): void {
    const timestamp = this.getTimestamp();
    const isExternal = req.ip && req.ip !== '127.0.0.1' && req.ip !== '::1' && !req.ip.includes('172.');
    
    console.log(`\n${'='.repeat(80)}`);
    console.log(`[${timestamp}] [${type}] ${isExternal ? 'EXTERNAL' : 'INTERNAL'} REQUEST`);
    console.log(`${'='.repeat(80)}`);
    console.log(`Method: ${req.method}`);
    console.log(`Path: ${req.path}`);
    console.log(`IP: ${req.ip}`);
    console.log(`User-Agent: ${req.get('User-Agent') || 'N/A'}`);
    console.log(`Content-Type: ${req.get('Content-Type') || 'N/A'}`);
    
    if (isExternal) {
      console.log(`[${timestamp}] [ALERT] EXTERNAL WEBHOOK DETECTED!`);
      console.log(`Source: ${req.get('User-Agent') || 'Unknown'}`);
      console.log(`Origin: ${req.get('Origin') || 'N/A'}`);
      console.log(`Referer: ${req.get('Referer') || 'N/A'}`);
    }

    // Log body data
    if (req.body && Object.keys(req.body).length > 0) {
      console.log(`\nPayload:`);
      console.log(JSON.stringify(req.body, null, 2));
    }

    // Extract important data
    const body = req.body || {};
    const email = body.email || body.user_email || body.customer_email || body.e_mail || 
                 (body.cliente && body.cliente.email) || (body.user && body.user.email);
    const name = body.nome || body.name || body.full_name || 
                (body.cliente && body.cliente.nome) || (body.user && body.user.name);
    const amount = body.valor || body.amount || body.value || body.depositAmount;
    const status = body.status || body.evento || body.action;

    if (email || name || amount || status) {
      console.log(`\nExtracted Data:`);
      if (email) console.log(`  Email: ${email}`);
      if (name) console.log(`  Name: ${name}`);
      if (amount) console.log(`  Amount: ${amount}`);
      if (status) console.log(`  Status: ${status}`);
    }

    console.log(`${'='.repeat(80)}\n`);
  }

  static api(req: Request, res: Response, duration: number, responseData?: any): void {
    const timestamp = this.getTimestamp();
    const statusColor = res.statusCode >= 400 ? 'ERROR' : res.statusCode >= 300 ? 'WARN' : 'INFO';
    
    let logMessage = `[${timestamp}] [${statusColor}] ${req.method} ${req.path} - ${res.statusCode} (${this.formatDuration(duration)})`;
    
    if (responseData && Object.keys(responseData).length > 0) {
      const summary = this.summarizeResponse(responseData);
      logMessage += ` - ${summary}`;
    }
    
    console.log(logMessage);
  }

  private static summarizeResponse(data: any): string {
    if (typeof data === 'string') return data.substring(0, 50);
    if (data.message) return data.message;
    if (data.status) return `Status: ${data.status}`;
    if (data.error) return `Error: ${data.error}`;
    return 'Response received';
  }



  static startup(port: number): void {
    const timestamp = this.getTimestamp();
    console.log(`\n${'='.repeat(60)}`);
    console.log(`[${timestamp}] [STARTUP] Investidor Academy Server Starting`);
    console.log(`${'='.repeat(60)}`);
    console.log(`Port: ${port}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`Database: ${process.env.DATABASE_URL ? 'Connected' : 'Not configured'}`);
    console.log(`${'='.repeat(60)}\n`);
  }


}