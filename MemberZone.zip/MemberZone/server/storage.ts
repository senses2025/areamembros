import {
  users,
  videos,
  liveStreams,
  tradingLogs,
  dailyGoals,
  tradingSignals,
  videoProgress,
  platformSettings,
  robotConfig,
  scheduledSignals,
  type User,
  type InsertUser,
  type Video,
  type InsertVideo,
  type LiveStream,
  type InsertLiveStream,
  type TradingLog,
  type InsertTradingLog,
  type DailyGoal,
  type InsertDailyGoal,
  type TradingSignal,
  type InsertTradingSignal,
  type VideoProgress,
  type InsertVideoProgress,
  type PlatformSettings,
  type RobotConfig,
  type ScheduledSignal,
  type InsertScheduledSignal,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  updateUserPremiumStatus(id: number, isPremium: boolean): Promise<void>;

  // Video operations
  getAllVideos(): Promise<Video[]>;
  getVideoById(id: number): Promise<Video | undefined>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideo(id: number, updates: Partial<Video>): Promise<Video | undefined>;
  deleteVideo(id: number): Promise<void>;
  getVideosByCategory(category: string): Promise<Video[]>;

  // Video progress operations
  getUserVideoProgress(userId: number, videoId: number): Promise<VideoProgress | undefined>;
  updateVideoProgress(userId: number, videoId: number, progress: number): Promise<void>;
  getUserProgress(userId: number): Promise<VideoProgress[]>;

  // Live stream operations
  getAllLiveStreams(): Promise<LiveStream[]>;
  getCurrentLiveStream(): Promise<LiveStream | undefined>;
  createLiveStream(stream: InsertLiveStream): Promise<LiveStream>;
  updateLiveStream(id: number, updates: Partial<LiveStream>): Promise<LiveStream | undefined>;
  deleteLiveStream(id: number): Promise<void>;

  // Trading log operations
  getUserTradingLogs(userId: number): Promise<TradingLog[]>;
  createTradingLog(log: InsertTradingLog): Promise<TradingLog>;
  getTradingLogsByDateRange(userId: number, startDate: Date, endDate: Date): Promise<TradingLog[]>;
  getUserDailyStats(userId: number, date: Date): Promise<{ wins: number; losses: number; totalAmount: number }>;

  // Daily goals operations
  getUserDailyGoal(userId: number, date: Date): Promise<DailyGoal | undefined>;
  createOrUpdateDailyGoal(goal: InsertDailyGoal): Promise<DailyGoal>;

  // Trading signals operations
  getActiveSignals(): Promise<TradingSignal[]>;
  createTradingSignal(signal: InsertTradingSignal): Promise<TradingSignal>;
  updateSignalResult(id: number, result: 'WIN' | 'LOSS'): Promise<void>;

  // Platform settings operations
  getPlatformSettings(): Promise<PlatformSettings[]>;
  updatePlatformSetting(key: string, value: string): Promise<void>;

  // Robot config operations
  getRobotConfig(): Promise<RobotConfig | undefined>;
  updateRobotConfig(config: Partial<RobotConfig>): Promise<void>;

  // Scheduled signals operations
  getScheduledSignals(): Promise<ScheduledSignal[]>;
  createScheduledSignal(signal: InsertScheduledSignal): Promise<ScheduledSignal>;
  updateScheduledSignal(id: number, updates: Partial<ScheduledSignal>): Promise<ScheduledSignal | undefined>;
  deleteScheduledSignal(id: number): Promise<void>;
  clearScheduledSignals(): Promise<void>;

  // Analytics operations
  getPlatformStats(): Promise<{
    totalUsers: number;
    premiumUsers: number;
    totalVideos: number;
    totalLiveStreams: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  async updateUserPremiumStatus(id: number, isPremium: boolean): Promise<void> {
    await db
      .update(users)
      .set({ isPremium, updatedAt: new Date() })
      .where(eq(users.id, id));
  }

  // Video operations
  async getAllVideos(): Promise<Video[]> {
    return await db.select().from(videos).orderBy(videos.order, videos.createdAt);
  }

  async getVideoById(id: number): Promise<Video | undefined> {
    const [video] = await db.select().from(videos).where(eq(videos.id, id));
    return video;
  }

  async createVideo(videoData: InsertVideo): Promise<Video> {
    const [video] = await db.insert(videos).values(videoData).returning();
    return video;
  }

  async updateVideo(id: number, updates: Partial<Video>): Promise<Video | undefined> {
    const [video] = await db
      .update(videos)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(videos.id, id))
      .returning();
    return video;
  }

  async deleteVideo(id: number): Promise<void> {
    await db.delete(videos).where(eq(videos.id, id));
  }

  async getVideosByCategory(category: string): Promise<Video[]> {
    return await db
      .select()
      .from(videos)
      .where(eq(videos.category, category))
      .orderBy(videos.order, videos.createdAt);
  }

  // Video progress operations
  async getUserVideoProgress(userId: number, videoId: number): Promise<VideoProgress | undefined> {
    const [progress] = await db
      .select()
      .from(videoProgress)
      .where(and(eq(videoProgress.userId, userId), eq(videoProgress.videoId, videoId)));
    return progress;
  }

  async updateVideoProgress(userId: number, videoId: number, progress: number): Promise<void> {
    const existing = await this.getUserVideoProgress(userId, videoId);
    
    if (existing) {
      await db
        .update(videoProgress)
        .set({
          progress,
          completed: progress >= 100,
          lastWatched: new Date(),
        })
        .where(and(eq(videoProgress.userId, userId), eq(videoProgress.videoId, videoId)));
    } else {
      await db.insert(videoProgress).values({
        userId,
        videoId,
        progress,
        completed: progress >= 100,
        lastWatched: new Date(),
      });
    }
  }

  async getUserProgress(userId: number): Promise<VideoProgress[]> {
    return await db
      .select()
      .from(videoProgress)
      .where(eq(videoProgress.userId, userId))
      .orderBy(desc(videoProgress.lastWatched));
  }

  // Live stream operations
  async getAllLiveStreams(): Promise<LiveStream[]> {
    return await db.select().from(liveStreams).orderBy(desc(liveStreams.scheduledAt));
  }

  async getCurrentLiveStream(): Promise<LiveStream | undefined> {
    const [stream] = await db
      .select()
      .from(liveStreams)
      .where(eq(liveStreams.isLive, true))
      .limit(1);
    return stream;
  }

  async createLiveStream(streamData: InsertLiveStream): Promise<LiveStream> {
    const [stream] = await db.insert(liveStreams).values(streamData).returning();
    return stream;
  }

  async updateLiveStream(id: number, updates: Partial<LiveStream>): Promise<LiveStream | undefined> {
    const [stream] = await db
      .update(liveStreams)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(liveStreams.id, id))
      .returning();
    return stream;
  }

  async deleteLiveStream(id: number): Promise<void> {
    await db.delete(liveStreams).where(eq(liveStreams.id, id));
  }

  // Trading log operations
  async getUserTradingLogs(userId: number): Promise<TradingLog[]> {
    return await db
      .select()
      .from(tradingLogs)
      .where(eq(tradingLogs.userId, userId))
      .orderBy(desc(tradingLogs.time));
  }

  async createTradingLog(logData: InsertTradingLog): Promise<TradingLog> {
    const [log] = await db.insert(tradingLogs).values(logData).returning();
    return log;
  }

  async getTradingLogsByDateRange(userId: number, startDate: Date, endDate: Date): Promise<TradingLog[]> {
    return await db
      .select()
      .from(tradingLogs)
      .where(
        and(
          eq(tradingLogs.userId, userId),
          gte(tradingLogs.time, startDate),
          lte(tradingLogs.time, endDate)
        )
      )
      .orderBy(desc(tradingLogs.time));
  }

  async getUserDailyStats(userId: number, date: Date): Promise<{ wins: number; losses: number; totalAmount: number }> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const logs = await this.getTradingLogsByDateRange(userId, startOfDay, endOfDay);
    
    const wins = logs.filter(log => log.type === 'WIN').length;
    const losses = logs.filter(log => log.type === 'LOSS').length;
    const totalAmount = logs.reduce((sum, log) => {
      const amount = parseFloat(log.amount.toString());
      return sum + (log.type === 'WIN' ? amount : -amount);
    }, 0);

    return { wins, losses, totalAmount };
  }

  // Daily goals operations
  async getUserDailyGoal(userId: number, date: Date): Promise<DailyGoal | undefined> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    
    const [goal] = await db
      .select()
      .from(dailyGoals)
      .where(
        and(
          eq(dailyGoals.userId, userId),
          gte(dailyGoals.date, startOfDay)
        )
      )
      .limit(1);
    return goal;
  }

  async createOrUpdateDailyGoal(goalData: InsertDailyGoal): Promise<DailyGoal> {
    const existing = await this.getUserDailyGoal(goalData.userId, goalData.date);
    
    if (existing) {
      const [goal] = await db
        .update(dailyGoals)
        .set(goalData)
        .where(eq(dailyGoals.id, existing.id))
        .returning();
      return goal;
    } else {
      const [goal] = await db.insert(dailyGoals).values(goalData).returning();
      return goal;
    }
  }

  // Trading signals operations
  async getActiveSignals(): Promise<TradingSignal[]> {
    return await db
      .select()
      .from(tradingSignals)
      .where(eq(tradingSignals.isActive, true))
      .orderBy(desc(tradingSignals.createdAt))
      .limit(20);
  }

  async createTradingSignal(signalData: InsertTradingSignal): Promise<TradingSignal> {
    const [signal] = await db.insert(tradingSignals).values(signalData).returning();
    return signal;
  }

  async updateSignalResult(id: number, result: 'WIN' | 'LOSS'): Promise<void> {
    await db
      .update(tradingSignals)
      .set({ result, isActive: false })
      .where(eq(tradingSignals.id, id));
  }

  // Platform settings operations
  async getPlatformSettings(): Promise<PlatformSettings[]> {
    return await db.select().from(platformSettings);
  }

  async updatePlatformSetting(key: string, value: string): Promise<void> {
    await db
      .insert(platformSettings)
      .values({ key, value, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: platformSettings.key,
        set: { value, updatedAt: new Date() }
      });
  }

  // Robot config operations
  async getRobotConfig(): Promise<RobotConfig | undefined> {
    const [config] = await db.select().from(robotConfig).limit(1);
    return config;
  }

  async updateRobotConfig(configData: Partial<RobotConfig>): Promise<void> {
    const existing = await this.getRobotConfig();
    
    if (existing) {
      await db
        .update(robotConfig)
        .set({ ...configData, updatedAt: new Date() })
        .where(eq(robotConfig.id, existing.id));
    } else {
      await db.insert(robotConfig).values({
        ...configData,
        updatedAt: new Date(),
      });
    }
  }

  async getScheduledSignals(): Promise<ScheduledSignal[]> {
    return await db.select().from(scheduledSignals).orderBy(scheduledSignals.time);
  }

  async createScheduledSignal(signalData: InsertScheduledSignal): Promise<ScheduledSignal> {
    const [signal] = await db.insert(scheduledSignals).values(signalData).returning();
    return signal;
  }

  async updateScheduledSignal(id: number, updates: Partial<ScheduledSignal>): Promise<ScheduledSignal | undefined> {
    const [signal] = await db
      .update(scheduledSignals)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(scheduledSignals.id, id))
      .returning();
    return signal;
  }

  async deleteScheduledSignal(id: number): Promise<void> {
    await db.delete(scheduledSignals).where(eq(scheduledSignals.id, id));
  }

  async clearScheduledSignals(): Promise<void> {
    await db.delete(scheduledSignals);
  }

  // Analytics operations
  async getPlatformStats(): Promise<{
    totalUsers: number;
    premiumUsers: number;
    totalVideos: number;
    totalLiveStreams: number;
  }> {
    const [userStats] = await db
      .select({
        totalUsers: sql<number>`count(*)::int`,
        premiumUsers: sql<number>`sum(case when is_premium then 1 else 0 end)::int`,
      })
      .from(users);

    const [videoStats] = await db
      .select({
        totalVideos: sql<number>`count(*)::int`,
      })
      .from(videos);

    const [streamStats] = await db
      .select({
        totalLiveStreams: sql<number>`count(*)::int`,
      })
      .from(liveStreams);

    return {
      totalUsers: userStats?.totalUsers || 0,
      premiumUsers: userStats?.premiumUsers || 0,
      totalVideos: videoStats?.totalVideos || 0,
      totalLiveStreams: streamStats?.totalLiveStreams || 0,
    };
  }
}

export const storage = new DatabaseStorage();
