import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { Logger } from "./logger";

const app = express();

// Enable CORS
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// WEBHOOK ENDPOINT - SISTEMA COMPLETO DE GERENCIAMENTO DE CONTAS
app.post('/api/webhook/broker-registration', async (req, res) => {
  try {
    console.log('📥 WEBHOOK RECEIVED - BROKER REGISTRATION');
    console.log('Headers:', req.headers);
    console.log('Body:', JSON.stringify(req.body, null, 2));
    console.log('IP:', req.ip);
    
    const { storage } = await import("./storage");
    const bcrypt = await import("bcrypt");
    
    // Extrair dados do body (formato X1-Broker)
    const extractUserData = (body) => {
      // Formato X1-Broker: {type: "signup", user: {...}}
      const user = body.user || body;
      
      return {
        nome: user.name || user.nome || user.full_name || user.usuario || '',
        email: user.email || user.e_mail || user.user_email || user.login || '',
        telefone: user.phone || user.telefone || user.celular || user.whatsapp || '',
        id_corretora: String(user.id) || user.id_corretora || user.broker_id || user.user_id || '',
        data_cadastro: user.signup_date || user.data_cadastro || user.created_at || user.registration_date,
        status: body.type || body.status || body.evento || 'cadastrado'
      };
    };
    
    const userData = extractUserData(req.body);
    
    console.log('📊 DADOS EXTRAÍDOS DO WEBHOOK:', {
      nome: userData.nome,
      email: userData.email,
      telefone: userData.telefone,
      id_corretora: userData.id_corretora,
      status: userData.status
    });
    
    console.log('🔍 DEBUG - USER OBJECT:', req.body.user);
    console.log('🔍 DEBUG - EMAIL EXTRAÍDO:', userData.email);
    console.log('🔍 DEBUG - ID CORRETORA EXTRAÍDO:', userData.id_corretora);
    
    // Validar dados obrigatórios básicos
    const errors = [];
    if (!userData.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(userData.email)) errors.push('Email válido é obrigatório');
    if (!userData.id_corretora) errors.push('ID da corretora é obrigatório');
    
    if (errors.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors
      });
    }
    
    // Verificar se usuário já existe
    const existingUser = await storage.getUserByEmail(userData.email);
    
    if (existingUser) {
      console.log('⚠️ USUÁRIO JÁ EXISTE - ATUALIZANDO STATUS:', userData.email);
      
      // Atualizar usuário existente para liberado premium
      const updatedUser = await storage.updateUser(existingUser.id, {
        isPremium: true,
        brokerRegistered: true,
        brokerUserId: userData.id_corretora,
        accountStatus: 'premium_released'
      });
      
      console.log('✅ USUÁRIO ATUALIZADO PARA PREMIUM:', {
        id: updatedUser.id,
        email: updatedUser.email,
        name: updatedUser.name,
        isPremium: updatedUser.isPremium,
        accountStatus: updatedUser.accountStatus
      });
      
      return res.status(200).json({
        success: true,
        message: 'Usuário atualizado para premium com sucesso',
        action: 'updated',
        user: {
          id: updatedUser.id,
          email: updatedUser.email,
          name: updatedUser.name,
          isPremium: updatedUser.isPremium,
          accountStatus: updatedUser.accountStatus,
          brokerUserId: updatedUser.brokerUserId,
          updated_at: updatedUser.updatedAt
        }
      });
    }
    
    // Usuário não existe - criar novo com status não liberado para análise manual
    const tempPassword = Math.random().toString(36).slice(-8);
    const hashedPassword = await bcrypt.hash(tempPassword, 10);
    
    const newUser = await storage.createUser({
      name: userData.nome || 'Usuário Corretora',
      email: userData.email,
      password: hashedPassword,
      role: 'user',
      isPremium: false,
      brokerRegistered: true,
      brokerUserId: userData.id_corretora,
      accountStatus: 'pending_review'
    });
    
    console.log('⚠️ USUÁRIO NOVO CRIADO - PENDENTE DE ANÁLISE:', {
      id: newUser.id,
      email: newUser.email,
      name: newUser.name,
      accountStatus: newUser.accountStatus
    });
    
    res.status(200).json({
      success: true,
      message: 'Usuário criado - pendente de análise manual',
      action: 'created_pending',
      user: {
        id: newUser.id,
        email: newUser.email,
        name: newUser.name,
        isPremium: newUser.isPremium,
        accountStatus: newUser.accountStatus,
        brokerUserId: newUser.brokerUserId,
        created_at: newUser.createdAt
      }
    });
    
  } catch (error) {
    console.error('❌ ERRO NO WEBHOOK:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor',
      error: error.message
    });
  }
});

// WEBHOOK STATUS ENDPOINT
app.get('/api/webhook/status', async (req, res) => {
  try {
    const { storage } = await import("./storage");
    const totalUsers = await storage.getAllUsers();
    const premiumUsers = totalUsers.filter(user => user.isPremium);
    
    res.status(200).json({
      success: true,
      message: 'Sistema de webhook está ativo',
      status: 'active',
      statistics: {
        total_users: totalUsers.length,
        premium_users: premiumUsers.length,
        broker_users: totalUsers.filter(user => user.brokerRegistered).length
      },
      endpoints: {
        registration: '/api/webhook/broker-registration',
        status: '/api/webhook/status'
      },
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ ERRO NO STATUS:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao obter status',
      error: error.message
    });
  }
});

// Request Logging System
app.use((req, res, next) => {
  if (req.method === 'POST') {
    Logger.webhook(req, 'POST');
  }
  next();
});

// Professional API Response Logging
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api") || path.startsWith("/webhook")) {
      Logger.api(req, res, duration, capturedJsonResponse);
    }
  });

  next();
});

(async () => {
  // Register routes PRIMEIRO
  const server = await registerRoutes(app);

  // Error handler
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // Setup Vite
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    Logger.startup(port);
  });
})();
