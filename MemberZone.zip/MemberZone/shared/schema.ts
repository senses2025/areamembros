import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  boolean,
  integer,
  decimal,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { z } from "zod";

// Session storage table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  password: text("password").notNull(),
  role: varchar("role", { length: 50 }).notNull().default("user"), // user, admin
  isPremium: boolean("is_premium").notNull().default(false),
  brokerRegistered: boolean("broker_registered").notNull().default(false),
  brokerUserId: varchar("broker_user_id", { length: 255 }), // ID do usuário na corretora
  accountStatus: varchar("account_status", { length: 50 }).notNull().default("not_released"), // not_released, premium_released, pending_review
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Videos/Classes table
export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  videoUrl: text("video_url").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  duration: integer("duration"), // in seconds
  category: varchar("category", { length: 100 }).notNull(), // Educação, Trading, Análise, etc.
  level: varchar("level", { length: 50 }).notNull().default("básico"), // básico, intermediário, avançado
  instructor: varchar("instructor", { length: 255 }).default("Investidor Academy"),
  tags: text("tags"), // comma-separated tags
  language: varchar("language", { length: 10 }).notNull().default("pt-BR"),
  isPremium: boolean("is_premium").notNull().default(false),
  isFeatured: boolean("is_featured").notNull().default(false),
  order: integer("order").notNull().default(0),
  rating: decimal("rating", { precision: 3, scale: 2 }).default("0.00"),
  viewCount: integer("view_count").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User video progress tracking
export const videoProgress = pgTable("video_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  videoId: integer("video_id").references(() => videos.id).notNull(),
  progress: integer("progress").notNull().default(0), // percentage 0-100
  completed: boolean("completed").notNull().default(false),
  lastWatched: timestamp("last_watched").defaultNow(),
});

// Live streams table
export const liveStreams = pgTable("live_streams", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  streamUrl: text("stream_url"),
  platform: varchar("platform", { length: 20 }).notNull().default("youtube"), // youtube, meet, twitch
  embedCode: text("embed_code"), // For YouTube embeds
  meetingLink: text("meeting_link"), // For Google Meet links
  scheduledAt: timestamp("scheduled_at"),
  isLive: boolean("is_live").notNull().default(false),
  isPremium: boolean("is_premium").notNull().default(false),
  viewerCount: integer("viewer_count").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Trading operations/logs
export const tradingLogs = pgTable("trading_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  type: varchar("type", { length: 10 }).notNull(), // WIN, LOSS
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  asset: varchar("asset", { length: 50 }).notNull(),
  time: timestamp("time").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Daily trading goals
export const dailyGoals = pgTable("daily_goals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  date: timestamp("date").notNull(),
  goalAmount: decimal("goal_amount", { precision: 10, scale: 2 }).notNull(),
  currentAmount: decimal("current_amount", { precision: 10, scale: 2 }).notNull().default("0.00"),
  wins: integer("wins").notNull().default(0),
  losses: integer("losses").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Trading signals
export const tradingSignals = pgTable("trading_signals", {
  id: serial("id").primaryKey(),
  asset: varchar("asset", { length: 50 }).notNull(),
  signal: varchar("signal", { length: 10 }).notNull(), // CALL, PUT
  strategy: varchar("strategy", { length: 100 }).notNull(),
  strength: integer("strength").notNull(), // 1-100
  timeframe: varchar("timeframe", { length: 20 }).notNull(),
  expirationTime: integer("expiration_time").notNull(), // in minutes
  isActive: boolean("is_active").notNull().default(true),
  result: varchar("result", { length: 10 }), // WIN, LOSS, null for pending
  createdAt: timestamp("created_at").defaultNow(),
});

// Platform settings
export const platformSettings = pgTable("platform_settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Trading robot configuration
export const robotConfig = pgTable("robot_config", {
  id: serial("id").primaryKey(),
  isActive: boolean("is_active").notNull().default(true),
  activeAssets: jsonb("active_assets").notNull().default('[]'),
  strategies: jsonb("strategies").notNull().default('[]'),
  minStrength: integer("min_strength").notNull().default(70),
  maxSignalsPerHour: integer("max_signals_per_hour").notNull().default(10),
  useScheduledSignals: boolean("use_scheduled_signals").notNull().default(false),
  repeatList: boolean("repeat_list").notNull().default(false),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Scheduled signals for admin-controlled robot signals
export const scheduledSignals = pgTable("scheduled_signals", {
  id: serial("id").primaryKey(),
  asset: varchar("asset", { length: 50 }).notNull(),
  direction: varchar("direction", { length: 10 }).notNull(), // 'CALL' or 'PUT'
  time: varchar("time", { length: 5 }).notNull(), // Format: "14:30"
  expiration: integer("expiration").default(1).notNull(), // Minutes
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  videoProgress: many(videoProgress),
  tradingLogs: many(tradingLogs),
  dailyGoals: many(dailyGoals),
}));

export const videosRelations = relations(videos, ({ many }) => ({
  progress: many(videoProgress),
}));

export const videoProgressRelations = relations(videoProgress, ({ one }) => ({
  user: one(users, {
    fields: [videoProgress.userId],
    references: [users.id],
  }),
  video: one(videos, {
    fields: [videoProgress.videoId],
    references: [videos.id],
  }),
}));

export const tradingLogsRelations = relations(tradingLogs, ({ one }) => ({
  user: one(users, {
    fields: [tradingLogs.userId],
    references: [users.id],
  }),
}));

export const dailyGoalsRelations = relations(dailyGoals, ({ one }) => ({
  user: one(users, {
    fields: [dailyGoals.userId],
    references: [users.id],
  }),
}));

// Zod schemas - Simple types for now
export const insertUserSchema = z.object({
  name: z.string(),
  email: z.string().email(),
  password: z.string(),
  role: z.string().optional(),
  isPremium: z.boolean().optional(),
  brokerRegistered: z.boolean().optional(),
  brokerUserId: z.string().optional(),
  accountStatus: z.string().optional(),
  profileImageUrl: z.string().optional(),
});

export const selectUserSchema = z.object({
  id: z.number(),
  name: z.string(),
  email: z.string(),
  password: z.string(),
  role: z.string(),
  isPremium: z.boolean(),
  brokerRegistered: z.boolean(),
  brokerUserId: z.string().nullable(),
  accountStatus: z.string(),
  profileImageUrl: z.string().nullable(),
  createdAt: z.date().nullable(),
  updatedAt: z.date().nullable(),
});

export const insertVideoSchema = z.object({
  title: z.string(),
  description: z.string().optional(),
  videoUrl: z.string(),
  thumbnailUrl: z.string().optional(),
  duration: z.number().optional(),
  category: z.string(),
  level: z.string().optional(),
  instructor: z.string().optional(),
  tags: z.string().optional(),
  language: z.string().optional(),
  isPremium: z.boolean().optional(),
  isFeatured: z.boolean().optional(),
});

export const selectVideoSchema = z.object({
  id: z.number(),
  title: z.string(),
  description: z.string().nullable(),
  videoUrl: z.string(),
  thumbnailUrl: z.string().nullable(),
  duration: z.number().nullable(),
  category: z.string(),
  level: z.string(),
  instructor: z.string().nullable(),
  tags: z.string().nullable(),
  language: z.string().nullable(),
  isPremium: z.boolean(),
  isFeatured: z.boolean(),
  rating: z.number().nullable(),
  viewCount: z.number(),
  createdAt: z.date().nullable(),
  updatedAt: z.date().nullable(),
});

export const insertTradingLogSchema = z.object({
  userId: z.number(),
  asset: z.string(),
  direction: z.string(),
  amount: z.string(),
  result: z.string(),
  entryTime: z.date(),
  exitTime: z.date().optional(),
  profit: z.string().optional(),
  notes: z.string().optional(),
});

export const selectTradingLogSchema = z.object({
  id: z.number(),
  userId: z.number(),
  asset: z.string(),
  direction: z.string(),
  amount: z.string(),
  result: z.string(),
  entryTime: z.date(),
  exitTime: z.date().nullable(),
  profit: z.string().nullable(),
  notes: z.string().nullable(),
  createdAt: z.date().nullable(),
});

export const insertLiveStreamSchema = z.object({
  title: z.string(),
  description: z.string().optional(),
  streamUrl: z.string(),
  thumbnailUrl: z.string().optional(),
  scheduledAt: z.union([z.string(), z.date()]).optional().transform((val) => {
    if (typeof val === 'string') return new Date(val);
    return val;
  }),
  isLive: z.boolean().optional(),
  platform: z.string().optional(),
});

export const selectLiveStreamSchema = z.object({
  id: z.number(),
  title: z.string(),
  description: z.string().nullable(),
  streamUrl: z.string(),
  thumbnailUrl: z.string().nullable(),
  scheduledAt: z.date().nullable(),
  isLive: z.boolean(),
  platform: z.string().nullable(),
  createdAt: z.date().nullable(),
  updatedAt: z.date().nullable(),
});

export const insertDailyGoalSchema = z.object({
  userId: z.number(),
  date: z.date(),
  targetAmount: z.string(),
  currentAmount: z.string().optional(),
  isCompleted: z.boolean().optional(),
});

export const selectDailyGoalSchema = z.object({
  id: z.number(),
  userId: z.number(),
  date: z.date(),
  targetAmount: z.string(),
  currentAmount: z.string().nullable(),
  isCompleted: z.boolean(),
  createdAt: z.date().nullable(),
});

export const insertTradingSignalSchema = z.object({
  asset: z.string(),
  direction: z.string(),
  entryPrice: z.string(),
  exitPrice: z.string().optional(),
  timeframe: z.string(),
  expirationTime: z.date(),
  result: z.string().optional(),
  strength: z.number().optional(),
  strategy: z.string().optional(),
  isActive: z.boolean().optional(),
});

export const selectTradingSignalSchema = z.object({
  id: z.number(),
  asset: z.string(),
  direction: z.string(),
  entryPrice: z.string(),
  exitPrice: z.string().nullable(),
  timeframe: z.string(),
  expirationTime: z.date(),
  result: z.string().nullable(),
  strength: z.number().nullable(),
  strategy: z.string().nullable(),
  isActive: z.boolean(),
  createdAt: z.date().nullable(),
});

export const insertScheduledSignalSchema = z.object({
  asset: z.string(),
  direction: z.string(),
  time: z.string(),
  expiration: z.number(),
  isActive: z.boolean().optional(),
});

export const selectScheduledSignalSchema = z.object({
  id: z.number(),
  asset: z.string(),
  direction: z.string(),
  time: z.string(),
  expiration: z.number(),
  isActive: z.boolean(),
  createdAt: z.date().nullable(),
  updatedAt: z.date().nullable(),
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

export const registerSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(6),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Video = typeof videos.$inferSelect;
export type InsertVideo = typeof videos.$inferInsert;
export type TradingLog = typeof tradingLogs.$inferSelect;
export type InsertTradingLog = typeof tradingLogs.$inferInsert;
export type LiveStream = typeof liveStreams.$inferSelect;
export type InsertLiveStream = typeof liveStreams.$inferInsert;
export type DailyGoal = typeof dailyGoals.$inferSelect;
export type InsertDailyGoal = typeof dailyGoals.$inferInsert;
export type TradingSignal = typeof tradingSignals.$inferSelect;
export type InsertTradingSignal = typeof tradingSignals.$inferInsert;
export type VideoProgress = typeof videoProgress.$inferSelect;
export type InsertVideoProgress = typeof videoProgress.$inferInsert;
export type PlatformSettings = typeof platformSettings.$inferSelect;
export type RobotConfig = typeof robotConfig.$inferSelect;
export type ScheduledSignal = typeof scheduledSignals.$inferSelect;
export type InsertScheduledSignal = typeof scheduledSignals.$inferInsert;
