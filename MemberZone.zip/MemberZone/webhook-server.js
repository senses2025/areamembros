const express = require('express');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');

const app = express();
const port = 3001;

// Configurar banco de dados
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// Função para criar usuário
async function createUser(userData) {
  const { name, email, password, role = 'user', isPremium = true, brokerRegistered = true } = userData;
  
  const query = `
    INSERT INTO users (name, email, password, role, "isPremium", "brokerRegistered", "createdAt")
    VALUES ($1, $2, $3, $4, $5, $6, NOW())
    RETURNING *
  `;
  
  const result = await pool.query(query, [name, email, password, role, isPremium, brokerRegistered]);
  return result.rows[0];
}

// Função para buscar usuário por email
async function getUserByEmail(email) {
  const query = 'SELECT * FROM users WHERE email = $1';
  const result = await pool.query(query, [email]);
  return result.rows[0];
}

// Validar email
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Extrair dados do usuário
function extractUserData(body) {
  return {
    nome: body.nome || body.name || body.full_name || body.usuario || '',
    email: body.email || body.e_mail || body.user_email || body.login || '',
    telefone: body.telefone || body.phone || body.celular || body.whatsapp || '',
    id_corretora: body.id_corretora || body.broker_id || body.user_id || body.id || '',
    data_cadastro: body.data_cadastro || body.created_at || body.registration_date,
    status: body.status || body.evento || 'cadastrado'
  };
}

// Validar dados
function validateUserData(userData) {
  const errors = [];
  
  if (!userData.nome || userData.nome.trim().length < 2) {
    errors.push('Nome é obrigatório e deve ter pelo menos 2 caracteres');
  }
  
  if (!userData.email || !isValidEmail(userData.email)) {
    errors.push('Email válido é obrigatório');
  }
  
  if (!userData.telefone || userData.telefone.trim().length < 8) {
    errors.push('Telefone é obrigatório e deve ter pelo menos 8 caracteres');
  }
  
  if (!userData.id_corretora || userData.id_corretora.trim().length === 0) {
    errors.push('ID da corretora é obrigatório');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// ===== ROTAS DO WEBHOOK =====

// Endpoint principal para cadastro
app.post('/webhook/broker/user-registration', async (req, res) => {
  try {
    console.log('📥 WEBHOOK RECEBIDO DA CORRETORA');
    console.log('Headers:', req.headers);
    console.log('Body:', JSON.stringify(req.body, null, 2));
    console.log('IP:', req.ip);
    
    // Extrair dados
    const userData = extractUserData(req.body);
    
    // Validar dados
    const validation = validateUserData(userData);
    if (!validation.isValid) {
      console.log('❌ DADOS INVÁLIDOS:', validation.errors);
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: validation.errors
      });
    }
    
    // Verificar se usuário já existe
    const existingUser = await getUserByEmail(userData.email);
    
    if (existingUser) {
      console.log('⚠️ USUÁRIO JÁ EXISTE:', userData.email);
      return res.status(409).json({
        success: false,
        message: 'Usuário já está cadastrado',
        email: userData.email,
        existing_user_id: existingUser.id
      });
    }
    
    // Criar usuário
    const tempPassword = Math.random().toString(36).slice(-8);
    const hashedPassword = await bcrypt.hash(tempPassword, 10);
    
    const newUser = await createUser({
      name: userData.nome,
      email: userData.email,
      password: hashedPassword,
      role: 'user',
      isPremium: true,
      brokerRegistered: true
    });
    
    console.log('✅ USUÁRIO CRIADO COM SUCESSO:', {
      id: newUser.id,
      email: newUser.email,
      name: newUser.name
    });
    
    // Resposta de sucesso
    res.status(200).json({
      success: true,
      message: 'Usuário cadastrado com sucesso',
      user: {
        id: newUser.id,
        email: newUser.email,
        name: newUser.name,
        isPremium: newUser.isPremium,
        created_at: newUser.createdAt
      }
    });
    
  } catch (error) {
    console.error('❌ ERRO NO WEBHOOK:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor',
      error: error.message
    });
  }
});

// Endpoint de teste
app.all('/webhook/broker/test', (req, res) => {
  console.log('🧪 TESTE DE WEBHOOK');
  console.log('Method:', req.method);
  console.log('Headers:', req.headers);
  console.log('Body:', req.body);
  
  res.status(200).json({
    success: true,
    message: 'Webhook está funcionando',
    timestamp: new Date().toISOString(),
    received_data: req.body
  });
});

// Endpoint de status
app.get('/webhook/broker/status', async (req, res) => {
  try {
    const result = await pool.query('SELECT COUNT(*) as total FROM users');
    const totalUsers = parseInt(result.rows[0].total);
    
    const premiumResult = await pool.query('SELECT COUNT(*) as premium FROM users WHERE "isPremium" = true');
    const premiumUsers = parseInt(premiumResult.rows[0].premium);
    
    const brokerResult = await pool.query('SELECT COUNT(*) as broker FROM users WHERE "brokerRegistered" = true');
    const brokerUsers = parseInt(brokerResult.rows[0].broker);
    
    res.status(200).json({
      success: true,
      message: 'Webhook da corretora está ativo',
      status: 'active',
      statistics: {
        total_users: totalUsers,
        premium_users: premiumUsers,
        broker_users: brokerUsers
      },
      endpoints: {
        registration: '/webhook/broker/user-registration',
        test: '/webhook/broker/test',
        status: '/webhook/broker/status'
      },
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ ERRO NO STATUS:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao obter status',
      error: error.message
    });
  }
});

// Endpoints alternativos
app.post('/webhook/corretora/cadastro', (req, res) => {
  req.url = '/webhook/broker/user-registration';
  app.handle(req, res);
});

app.post('/api/webhook/user-registration', (req, res) => {
  req.url = '/webhook/broker/user-registration';
  app.handle(req, res);
});

// Iniciar servidor
app.listen(port, '0.0.0.0', () => {
  console.log(`
===================================
🚀 WEBHOOK SERVER STARTED
===================================
Port: ${port}
Environment: ${process.env.NODE_ENV || 'development'}
Database: ${process.env.DATABASE_URL ? 'Connected' : 'Not configured'}

Endpoints disponíveis:
• POST /webhook/broker/user-registration
• GET  /webhook/broker/status
• GET  /webhook/broker/test

Teste o webhook:
curl -X GET http://localhost:${port}/webhook/broker/status
===================================
  `);
});

module.exports = app;