# Webhook Documentation - Investidor Academy

## Overview
Sistema de webhook para recebimento automático de cadastros de usuários da X1-Broker e ativação automática de contas premium.

## Endpoints Disponíveis

### 1. Cadastro de Usuário
- **URL**: `/api/webhook/broker-registration`
- **Method**: POST
- **Content-Type**: application/json

### 2. Status do Webhook
- **URL**: `/api/webhook/status`
- **Method**: GET
- **Response**: JSON com estatísticas e informações do sistema

## Formato dos Dados

### Requisição para Cadastro
```json
{
  "nome": "João Silva",
  "email": "joao@email.com",
  "telefone": "11999999999",
  "id_corretora": "12345",
  "evento": "cadastro_efetuado"
}
```

### Campos Aceitos (Flexibilidade)
- **Nome**: `nome`, `name`, `full_name`, `usuario`
- **Email**: `email`, `e_mail`, `user_email`, `login`
- **Telefone**: `telefone`, `phone`, `celular`, `whatsapp`
- **ID Corretora**: `id_corretora`, `broker_id`, `user_id`, `id`
- **Status**: `status`, `evento`

### Validações
- Nome: mínimo 2 caracteres
- Email: formato válido
- Telefone: mínimo 8 caracteres
- ID da corretora: obrigatório

## Respostas do Sistema

### Sucesso (200)
```json
{
  "success": true,
  "message": "Usuário cadastrado com sucesso",
  "user": {
    "id": 76,
    "email": "joao@email.com",
    "name": "João Silva",
    "isPremium": true,
    "brokerRegistered": true,
    "created_at": "2025-07-12T17:26:53.149Z"
  }
}
```

### Usuário já existe (409)
```json
{
  "success": false,
  "message": "Usuário já está cadastrado",
  "email": "joao@email.com",
  "existing_user_id": 76
}
```

### Dados inválidos (400)
```json
{
  "success": false,
  "message": "Dados inválidos",
  "errors": [
    "Nome é obrigatório",
    "Email válido é obrigatório",
    "Telefone é obrigatório",
    "ID da corretora é obrigatório"
  ]
}
```

### Erro interno (500)
```json
{
  "success": false,
  "message": "Erro interno do servidor",
  "error": "Detalhes do erro"
}
```

## Características do Sistema

### Funcionalidades
- ✅ Auto-criação de usuários premium
- ✅ Detecção de usuários duplicados
- ✅ Validação completa de dados
- ✅ Logs detalhados para monitoramento
- ✅ Flexibilidade nos campos de entrada
- ✅ Respostas padronizadas

### Segurança
- Validação de todos os campos obrigatórios
- Hash seguro de senhas temporárias
- Logs detalhados sem exposição de dados sensíveis
- Tratamento robusto de erros

## Integração com Corretora

### URL de Produção
```
https://seu-dominio.replit.app/api/webhook/broker-registration
```

### Exemplo de Teste
```bash
curl -X POST "https://seu-dominio.replit.app/api/webhook/broker-registration" \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "João Silva",
    "email": "joao@email.com",
    "telefone": "11999999999",
    "id_corretora": "12345",
    "evento": "cadastro_efetuado"
  }'
```

## Monitoramento

### Verificar Status
```bash
curl -X GET "https://seu-dominio.replit.app/api/webhook/status"
```

### Logs do Sistema
Todos os webhooks são registrados no console com:
- Headers da requisição
- Dados recebidos
- IP de origem
- Status do processamento
- Tempo de resposta

## Configuração Recomendada

### Na Corretora
1. Configurar webhook para ser enviado após cadastro do usuário
2. Incluir todos os campos obrigatórios
3. Configurar retry em caso de falha
4. Monitorar respostas HTTP

### No Sistema
1. Monitorar logs regularmente
2. Verificar estatísticas via endpoint de status
3. Configurar alertas para erros 500
4. Backup regular do banco de dados

## Changelog

- **2025-07-12**: Sistema de webhook totalmente funcional
  - Endpoint principal implementado
  - Validações e tratamento de erros
  - Logs detalhados
  - Documentação completa
  - Testes realizados com sucesso