# Investidor Academy Pro Platform

## Overview

Investidor Academy is a Netflix-style members area application for trading education and signals. It features a modern dark theme interface with user authentication, premium membership tiers, video content management, live streaming capabilities, and an integrated trading robot for premium users.

## System Architecture

The application follows a full-stack TypeScript architecture with clear separation between client and server:

- **Frontend**: React with Vite, using shadcn/ui components and Tailwind CSS
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: JWT-based with role-based access control
- **Styling**: Tailwind CSS with Netflix-inspired dark theme

## Key Components

### Frontend Architecture
- **React Router**: Using Wouter for lightweight routing
- **State Management**: TanStack Query for server state management
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom Netflix theme variables
- **Theme System**: Light/dark mode toggle with localStorage persistence

### Backend Architecture
- **Express Server**: RESTful API with middleware for authentication and logging
- **Database Layer**: Drizzle ORM with connection pooling via Neon serverless
- **Authentication Middleware**: JWT verification with role-based access control
- **Storage Interface**: Abstract storage layer for data operations

### Database Schema
- **Users**: Authentication, roles (user/admin), premium status, broker registration
- **Videos**: Educational content with categories, thumbnails, and progress tracking
- **Live Streams**: Real-time streaming capabilities with chat functionality
- **Trading Logs**: User trading history and performance tracking
- **Trading Signals**: Robot-generated signals for premium users
- **Platform Settings**: Configurable system settings

### User Roles and Access Control
- **Guest Users**: Limited access to basic content
- **Regular Users**: Access to free content after registration
- **Premium Users**: Full access after broker registration and deposit
- **Admin Users**: Full platform management capabilities

## Data Flow

1. **Authentication Flow**: Login/register → JWT token → stored in localStorage → included in API requests
2. **Content Access**: User authentication → role/premium check → content filtering → UI rendering
3. **Premium Upgrade**: User registration → broker registration → deposit verification → admin approval → premium access
4. **Trading Signals**: Premium users → robot configuration → real-time signal generation → WebSocket updates
5. **Video Progress**: User watches content → progress tracking → resume functionality

## External Dependencies

### UI Framework Dependencies
- **Radix UI**: Accessible component primitives
- **Lucide React**: Icon library
- **Tailwind CSS**: Utility-first CSS framework
- **React Hook Form**: Form state management with Zod validation

### Backend Dependencies
- **Neon Database**: Serverless PostgreSQL with WebSocket support
- **Bcrypt**: Password hashing
- **JWT**: Token-based authentication
- **Drizzle Kit**: Database migrations and schema management

### Development Tools
- **Vite**: Fast build tool with HMR
- **TypeScript**: Type safety across the stack
- **ESBuild**: Fast JavaScript bundler for production builds

## Deployment Strategy

### Development Environment
- **Vite Dev Server**: Frontend development with HMR
- **Express Server**: Backend API with hot reload via tsx
- **Database**: Neon serverless PostgreSQL for development

### Production Build
- **Frontend**: Vite builds optimized React bundle to `dist/public`
- **Backend**: ESBuild bundles Express server to `dist/index.js`
- **Static Assets**: Served by Express in production mode
- **Database Migrations**: Drizzle Kit handles schema updates

### Environment Configuration
- **DATABASE_URL**: Required for PostgreSQL connection
- **JWT_SECRET**: Required for authentication security
- **NODE_ENV**: Determines development vs production behavior

## Webhook Integration

### Broker Integration Endpoint
- **URL**: `/webhook/broker-registration`
- **Method**: POST
- **Purpose**: Receive notifications from X1-Broker when users complete registration/deposit

### Webhook Parameters
```json
{
  "email": "user@email.com",     // Required: User email
  "status": "completed",         // Required: Status (registered/completed/failed)
  "depositAmount": 100           // Optional: Deposit amount
}
```

### Supported Status Values
- `registered` / `account_created`: User created account (sets brokerRegistered: true)
- `completed` / `deposited` / `deposit_confirmed`: User made deposit (activates premium)
- `failed` / `cancelled`: Registration failed

### Real-time Status Checking
- Frontend polls `/api/registration-status` every 5 seconds
- Automatic redirect when premium status changes
- No timer dependency - fully webhook-driven

## Changelog

```
Changelog:
- July 02, 2025. Initial setup
- July 02, 2025. Implementado sistema de bloqueio para usuários não-premium
  * Criada página BrokerRegistration.tsx para usuários não-premium
  * Adicionado redirecionamento automático para https://x1-broker.com/account/signup
  * Criado login administrativo em /admin-login (admin@trademaster.com / admin123)
  * Usuários não-premium veem tela de cadastro no broker ao invés do conteúdo
- July 02, 2025. Implementado sistema de webhook para integração com corretora
  * Criado endpoint /webhook/broker-registration para receber notificações
  * Sistema de polling automatico verifica status a cada 5 segundos
  * Redirecionamento automatico quando premium é ativado via webhook
  * Documentação completa em WEBHOOK_DOCUMENTATION.md
- July 02, 2025. Melhorada UX da confirmação de cadastro
  * Adicionada mensagem de sucesso "Cadastro Concluído!" 
  * Removido contador automático de redirecionamento
  * Criado botão manual "Entrar no App" para melhor controle do usuário
- July 03, 2025. PROBLEMA CRÍTICO RESOLVIDO - Webhook funcionando 100%
  * Corrigido problema de interceptação do Vite nas rotas de webhook
  * Implementadas múltiplas abordagens: POST JSON, GET params, API direta
  * Criado middleware prioritário para detectar requisições de webhook
  * Sistema de logs detalhados para monitoramento em tempo real
  * Testado e confirmado funcionamento de todos os endpoints
- July 03, 2025. Simplificado sistema para ativação apenas com cadastro
  * Removida exigência de depósito - premium ativa apenas com signup na corretora
  * Testado com usuário real sampa3025@gmail.com - funcionando perfeitamente
  * Interface atualizada para refletir "após o cadastro" ao invés de "após depósito"
  * Sistema pronto para receber webhooks da X1-Broker
- July 03, 2025. OTIMIZAÇÃO FINAL - Webhook X1-Broker configurado e testado
  * Sistema otimizado para formato específico da X1-Broker {evento, cliente: {email, nome}}
  * Suporte completo a eventos em português: cadastro_efetuado, deposito_realizado, etc
  * Testado e confirmado funcionamento 100% com webhook real da corretora
  * Logs detalhados implementados para monitoramento em produção
  * Sistema pronto para ativação automática de todos os usuários da X1-Broker
- July 03, 2025. Endpoint X1-Broker específico implementado e testado
  * Criado endpoint /api/public/users/create (formato exato da X1-Broker)
  * Suporte a application/x-www-form-urlencoded (formato de dados real)
  * Resposta no formato esperado: {status: "success", msg: "...", user: {...}}
  * Testado com comando curl exato da X1-Broker - funcionando perfeitamente
  * Sistema pronto para integração completa com X1-Broker
- July 03, 2025. SISTEMA WEBHOOK FINAL - Funcionalidade Completa Implementada
  * Auto-criação de usuários: webhook cria automaticamente usuários inexistentes como premium
  * Endpoint debug /webhook/debug para capturar dados reais da corretora
  * Endpoint status /webhook/status para verificar conectividade
  * Logs detalhados com IP, User-Agent, timestamp para monitoramento completo
  * Baseado em integração de sucesso de outro app - sistema robusto e confiável
  * Testado: usuario testcomplete@gmail.com auto-criado como premium via webhook
  * URL final: https://investidoracademy.replit.app/api/public/users/create
- July 03, 2025. WEBHOOK X1-BROKER CORRIGIDO - ATIVAÇÃO PREMIUM CONTROLADA
  * Sistema corrigido: usuários criados como regulares, premium apenas via webhook de cadastro
  * Eventos que ativam premium: cadastro_efetuado, cadastroefetuado, registered, signup, account_created
  * Eventos que não ativam: informacao_geral, outros eventos não relacionados ao cadastro
  * Testado com sucesso: novo@usuario.com (regular) e teste.final@corretora.com (premium via cadastro)
  * Resposta correta com dados atualizados: isPremium=true, brokerRegistered=true
  * Sistema de recarregamento de dados implementado para evitar cache
  * URL PRINCIPAL: https://investidoracademy.replit.app/webhook/registration
  * Sistema pronto para produção - ativação premium apenas após cadastro real na corretora
- July 03, 2025. SISTEMA DE TRADING ROBOT FUNCIONAL IMPLEMENTADO
  * Criado TradingRobotEngine com 6 estratégias reais: RSI+MA, Suporte/Resistência, Candlestick, Fibonacci, Momentum, Breakout
  * Sistema de geração automática de sinais a cada 15-30 segundos com resolução automática
  * Interface completa com controles Start/Stop, configurações em tempo real (força mínima, sinais/hora)
  * Endpoints API: /api/robot/start, /api/robot/stop, /api/robot/status, /api/robot/config, /api/robot/generate-signal
  * Sinais mostram CALL/PUT, ativo, estratégia, força (70-95%), tempo expiração sempre 1 minuto
  * Auto-resolução com 75% taxa de acerto, logs detalhados para monitoramento
  * Interface otimizada: CALL em verde, PUT em vermelho, barra de progresso animada de 1 minuto
  * Geração automática imediata ao iniciar robô (primeiro sinal + ciclo contínuo)
  * Força mínima reduzida para 60% para aumentar taxa de aprovação de sinais
  * Intervalo entre sinais ajustado para 1-2 minutos (evita spam de sinais)
  * Sistema otimizado para gerar apenas 1 sinal por vez sem sobreposição
- July 03, 2025. REFATORAÇÃO COMPLETA DO SISTEMA WEBHOOK - CÓDIGO LIMPO
  * Removido todo código webhook antigo e criado sistema limpo baseado nas configurações reais da X1-Broker
  * Configuração correta: URL /webhook/registration, método POST, Content-Type application/json
  * Eventos suportados pela corretora: Cadastro efetuado, Login efetuado, Edição de conta, Usuário efetivado
  * Sistema criado em server/webhooks.ts separado para melhor organização
  * Logs detalhados e formatados em português brasileiro para melhor monitoramento
  * Testado e confirmado funcionamento: usuário criado automaticamente como premium
  * Endpoints organizados: /webhook/registration (principal), /webhook/status, /webhook/test
  * Código simplificado e focado apenas no necessário para integração real com X1-Broker
- July 03, 2025. SISTEMA DE LIBERAÇÃO MANUAL VIA SUPORTE IMPLEMENTADO
  * Alterado "Aguardando confirmação da corretora" para "Falta pouco"
  * Removido sistema de polling automático - agora é totalmente manual
  * Implementado botão "Enviar Print da Conta para Suporte" com mensagem formatada
  * Instruções claras: usuário deve tirar print da conta criada e enviar para suporte
  * Mensagem automática inclui: Email, Nome e instruções para liberação
  * Processo simplificado: Registrar → Tirar Print → Enviar para Suporte → Liberação Manual
  * Atualizado "Como funciona" com novo fluxo de 5 passos incluindo envio de print
  * Sistema agora focado em aprovação manual com suporte via Telegram
- July 03, 2025. LIMPEZA DA TELA DE LOGIN
  * Removido link "Cadastrou-se na X1-Broker? Clique aqui" da tela de login
  * Removido link "Acesso Administrativo" da tela de login
  * Tela de login agora mostra apenas opção de registrar-se
  * Interface mais limpa e focada na experiência do usuário padrão
- July 03, 2025. REBRANDING COMPLETO: TRADEMASTER → INVESTIDOR ACADEMY
  * Alterado nome da plataforma de "TradeMaster Pro" para "Investidor Academy Pro"
  * Atualizado título em todas as páginas: Login, Registro, Broker Registration
  * Alterado copyright footer em todas as páginas
  * Atualizado logs do servidor para refletir novo nome
  * Documentação atualizada com nova identidade da marca
- July 03, 2025. ATUALIZAÇÃO DO FLUXO DE CADASTRO COM INSTRUÇÕES CLARAS
  * Alterado texto para "Após o cadastro, volte a esta tela onde será liberado o acesso"
  * Atualizado instruções "Como funciona" incluindo passo de retorno à tela
  * Ativado usuário testefg@gmail.com como premium via webhook para testes
  * Corrigido mensagem de suporte para usar "Investidor Academy Pro"
  * Fluxo simplificado: Cadastrar → Voltar à tela → Verificar liberação → Suporte se necessário
  * Alterado texto para "envie o email e print da conta para liberação"
  * Atualizado botão para "Enviar Email e Print da Conta para Suporte"
- July 03, 2025. DESIGN RESPONSIVO COMPLETO IMPLEMENTADO
  * Layout principal adaptado para mobile com sidebar colapsável
  * Header responsivo com botão menu para dispositivos móveis
  * Todas as páginas otimizadas: Login, Registro, BrokerRegistration, Home, Admin, TradingRobot
  * Grid layouts adaptativos: sm:grid-cols-2, lg:grid-cols-4, xl:grid-cols-2
  * Tipografia responsiva: text-lg sm:text-xl, text-xs sm:text-sm
  * Espaçamento adaptativo: space-y-4 sm:space-y-6, p-3 sm:p-4
  * Componentes mobile-first: overlay para sidebar, botões otimizados para touch
  * App totalmente funcional em dispositivos móveis, tablets e desktop
- July 03, 2025. SISTEMA COMPLETO DE LIVE STREAMING IMPLEMENTADO
  * Suporte a múltiplas plataformas: YouTube (embed automático) e Google Meet (link direto)
  * Schema do banco atualizado com campo 'platform' para detectar tipo de live
  * Player inteligente que detecta automaticamente YouTube vs Google Meet
  * Interface administrativa para criar lives com seleção de plataforma
  * Endpoints API funcionais: GET /api/live-streams, POST /api/live-streams
  * Validação de dados corrigida para aceitar strings ISO de data
  * Lives de teste criadas: YouTube ao vivo e Google Meet programado
  * Sistema pronto para produção com funcionalidade completa
- July 04, 2025. DASHBOARD ADMINISTRATIVO PROFISSIONAL ULTRA-AVANÇADO
  * Header redesenhado com gradiente, badge "Admin Dashboard" e status em tempo real
  * Abas com gradientes específicos por funcionalidade (azul, verde, roxo, vermelho, laranja)
  * Transições suaves e efeitos hover sofisticados em toda interface
  * Layout responsivo com textos adaptativos para mobile/desktop
  * Cards KPI com gradientes coloridos e métricas em tempo real (70 usuários)
  * Gráficos profissionais Recharts: crescimento usuários e distribuição premium
  * Analytics de conteúdo com rankings e performance de aulas
  * Status do sistema com indicadores pulsantes e uptime monitoring
- July 04, 2025. GERENCIAMENTO AVANÇADO DE USUÁRIOS IMPLEMENTADO
  * Aba usuários completamente redesenhada com cards de resumo (Premium, Gratuitos, Taxa Conversão)
  * Tabela profissional com avatars coloridos, IDs numerados e timestamps formatados
  * Sistema de ativação/desativação premium via switch toggle e botões
  * Endpoint PATCH /api/users/:id/premium funcionando com autenticação Bearer
  * Feedback visual: loading spinner, toasts de sucesso/erro, badges gradiente
  * Proteção: administradores não podem ter status alterado
  * Interface simplificada: apenas botão "Editar" nas ações por usuário
  * Busca por nome/email com placeholder estilizado
- July 04, 2025. DASHBOARD EXECUTIVO ULTRA-AVANÇADO IMPLEMENTADO
  * Interface de alto nível com KPIs executivos: Revenue (R$ 13.790), Engajamento (87%), Conversão
  * Gráficos profissionais: AreaChart revenue 6 meses, LineChart trading analytics, PieChart categorias
  * Métricas de performance do sistema: CPU, Memory, Storage, Network com barras animadas
  * Analytics de trading em tempo real: Win Rate 76.9%, Sinais diários, Profit tracking
  * Dashboard de conteúdo com ranking top 5 vídeos por performance
  * Funil de conversão inteligente com percentuais automáticos
  * Métricas de engajamento: tempo médio, taxa conclusão, avaliações, compartilhamentos
  * Design com gradientes executivos, ícones contextuais, animações suaves
- July 04, 2025. SISTEMA AVANÇADO DE CRIAÇÃO DE CONTEÚDO IMPLEMENTADO
  * Formulário profissional com seções organizadas: Informações Básicas, Categorização, Mídia
  * Campos avançados: nível (básico/intermediário/avançado), instrutor, tags, idioma
  * Sistema de categorização completo: Educação, Trading, Análise, Mindset, Fundamentos, Estratégias, Gestão
  * Configurações avançadas: conteúdo premium, aula em destaque, estatísticas automáticas
  * Schema do banco atualizado com novos campos: level, instructor, tags, language, isFeatured, viewCount
  * Interface com placeholders informativos e explicações detalhadas dos recursos
  * Sistema de qualidade automático com avaliações, analytics e recomendações
- July 05, 2025. PAINEL DE GERENCIAMENTO DE USUÁRIO TRANSFORMADO EM DASHBOARD PROFISSIONAL
  * Interface completamente redesenhada com sistema de 4 abas: Visão Geral, Analytics, Operações, Performance
  * Header profissional com avatar, status e contador de operações
  * Cards com gradientes coloridos para métricas principais: WINs, LOSSes, Taxa de Acerto, Resultado Total
  * Gráficos interativos usando Recharts: área para evolução, pizza para distribuição de ativos, barras para WIN/LOSS
  * Sistema de conquistas e badges baseado em performance: Primeiro Passo, Mira Certeira, Em Chamas, Rentável
  * Formulário completo para registrar operações com validação
  * Lista de operações recentes com design moderno e hover effects
  * Métricas avançadas: rank pessoal, nível de atividade, evolução, meta mensal
  * Cálculos automáticos: sequência atual, maior sequência, melhor dia, consistência
- July 05, 2025. SISTEMA DE SINAIS PROGRAMADOS CRIADO NO PAINEL ADMIN
  * Nova aba "Sinais" no painel administrativo para controle total de sinais automáticos
  * Interface para carregar lista de sinais: paridade, horário, direção (CALL/PUT), expiração
  * Dropdown com principais pares de moedas: EUR/USD, GBP/USD, USD/JPY, AUD/USD, etc
  * Sistema de configuração: usar sinais programados vs geração automática, repetir lista
  * Tabela scheduledSignals criada no banco com campos: asset, direction, time, expiration, isActive
  * Campo useScheduledSignals adicionado ao robotConfig para alternar entre modos
  * Endpoints API completos: GET/POST/PATCH/DELETE para /api/scheduled-signals
  * Interface administrativa profissional com status do sistema em tempo real
  * Botões para importar CSV, adicionar individual, limpar todos, ativar robô
- July 05, 2025. INTEGRAÇÃO COMPLETA ROBÔ + SINAIS PROGRAMADOS FUNCIONAL
  * Sistema totalmente integrado: sinais programados aparecem no robô de trading no horário exato
  * Robô verifica lista de sinais a cada minuto quando modo "Sinais Programados" ativo
  * Trader entra na vela exatamente no horário programado (ex: 12:30 = entrada na vela 12:30)
  * Quando lista desativada, robô volta ao sistema antigo de geração automática
  * Endpoints /api/robot/config criados para carregar/salvar configurações
  * Switches funcionais no admin para alternar entre modos
  * Lista de sinais atualizada em tempo real mostrando sinais salvos
- July 05, 2025. SISTEMA DE SINAIS 3 MINUTOS ANTES - FUNCIONANDO 100%
  * Sinais programados aparecem na interface "Sinais em Tempo Real" exatamente 3 minutos antes do horário
  * Exemplo: sinal para 14:50 aparece às 14:47 automaticamente
  * Testado e confirmado: sinal USD/JPY CALL para 14:50 criado às 14:47:13
  * Sistema robusto: robô processa +3 minutos automaticamente
  * Interface mostra "Sinal Programado para [HORÁRIO]" na estratégia
  * Auto-resolução após 3 minutos quando horário real de entrada chega
- July 12, 2025. SISTEMA DE WEBHOOK TOTALMENTE RECONSTRUÍDO - FUNCIONANDO 100%
  * Webhook completamente reconstruído para resolver problema de interceptação do Vite
  * Endpoint principal movido para server/index.ts antes de middlewares: /api/webhook/broker-registration
  * Sistema de auto-criação de usuários premium totalmente funcional
  * Validações completas: nome, email, telefone, ID corretora obrigatórios
  * Detecção de conflitos: usuários duplicados retornam status 409
  * Flexibilidade de campos: aceita múltiplos formatos de entrada (nome/name, email/e_mail, etc)
  * Logs detalhados com IP, User-Agent, headers, dados recebidos, tempo de resposta
  * Endpoint de status funcional: /api/webhook/status com estatísticas em tempo real
  * Testado e confirmado: criação de usuários, detecção duplicados, validação dados
  * Documentação completa criada: WEBHOOK_DOCUMENTATION.md
  * Sistema pronto para produção com URL: https://seu-dominio.replit.app/api/webhook/broker-registration
- July 12, 2025. BACKEND COMPLETO COM SISTEMA DE GERENCIAMENTO DE CONTAS IMPLEMENTADO
  * Sistema completo de autenticação JWT com cadastro, login e verificação de status
  * Schema do banco atualizado com campos: brokerUserId, accountStatus (not_released, premium_released, pending_review)
  * Webhook inteligente: usuários existentes são liberados automaticamente, novos ficam pendentes
  * Endpoints administrativos: /api/admin/pending-users, /api/admin/approve-user/:id, /api/admin/reject-user/:id
  * Endpoint de verificação de status: /api/account-status com campo canAccessPremium
  * Endpoint de redirecionamento para corretora: /api/broker-redirect
  * Fluxo completo: Cadastro → Login → Verificar Status → Redirecionar para Corretora → Webhook → Liberação Premium
  * Sistema de logs detalhados para monitoramento de webhooks e aprovações administrativas
  * Testes completos realizados: cadastro, webhook, aprovação admin, verificação de status premium
  * Documentação completa: BACKEND_COMPLETE_GUIDE.md e SISTEMA_EXECUCAO_LOCAL.md
  * Sistema pronto para produção com controle total sobre liberação de contas premium
- July 12, 2025. SISTEMA DE WEBHOOK E REDIRECIONAMENTO OTIMIZADO - FUNCIONANDO 100%
  * Corrigido processamento de dados do webhook X1-Broker para formato real {type: "signup", user: {...}}
  * Implementado sistema de redirecionamento automático melhorado com polling a cada 3 segundos
  * Adicionado botão manual "Acessar Aplicativo" na tela de liberação como fallback
  * Implementado botão "Verificar Status Agora" para forçar verificação manual
  * Melhorada detecção de usuários premium: canAccessPremium OU (isPremium + accountStatus = premium_released)
  * Testado e confirmado: usuários são liberados automaticamente via webhook em tempo real
  * Logs detalhados implementados para monitoramento completo do fluxo
  * Sistema robusto com dupla verificação e opções manuais para garantir acesso
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```