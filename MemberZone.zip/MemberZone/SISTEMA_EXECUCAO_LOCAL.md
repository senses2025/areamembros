# Sistema de Execução Local - Investidor Academy

## Instalação e Configuração

### 1. Requisitos
- Node.js 18+
- PostgreSQL
- Git

### 2. Instalação
```bash
# Clonar repositório
git clone https://github.com/seu-usuario/investidor-academy.git
cd investidor-academy

# Instalar dependências
npm install

# Configurar banco de dados
npm run db:push
```

### 3. Variáveis de Ambiente
Criar arquivo `.env`:
```bash
DATABASE_URL=postgresql://user:password@localhost:5432/investidor_academy
JWT_SECRET=sua-chave-secreta-muito-forte-aqui
NODE_ENV=development
```

### 4. Iniciar Sistema
```bash
# Modo desenvolvimento
npm run dev

# Modo produção
npm run build
npm start
```

## Fluxo de Testes Completo

### 1. Iniciar Servidor
```bash
npm run dev
# Sistema iniciará em: http://localhost:5000
```

### 2. Testar Cadastro de Usuário
```bash
curl -X POST "http://localhost:5000/api/auth/register" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "João Silva",
    "email": "joao@email.com",
    "password": "senha123"
  }'
```

**Resposta Esperada:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "name": "João Silva",
    "email": "joao@email.com",
    "role": "user",
    "isPremium": false
  }
}
```

### 3. Testar Login
```bash
curl -X POST "http://localhost:5000/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "joao@email.com",
    "password": "senha123"
  }'
```

### 4. Verificar Status da Conta
```bash
curl -X GET "http://localhost:5000/api/account-status" \
  -H "Authorization: Bearer SEU_TOKEN_AQUI"
```

**Resposta Esperada:**
```json
{
  "success": true,
  "account": {
    "id": 1,
    "email": "joao@email.com",
    "name": "João Silva",
    "isPremium": false,
    "accountStatus": "not_released",
    "brokerRegistered": false,
    "brokerUserId": null,
    "canAccessPremium": false
  }
}
```

### 5. Simular Webhook da Corretora
```bash
# Webhook para usuário existente (liberação premium)
curl -X POST "http://localhost:5000/api/webhook/broker-registration" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "joao@email.com",
    "id_corretora": "BR12345",
    "name": "João Silva",
    "evento": "cadastro_efetuado"
  }'
```

**Resposta Esperada:**
```json
{
  "success": true,
  "message": "Usuário atualizado para premium com sucesso",
  "action": "updated",
  "user": {
    "id": 1,
    "email": "joao@email.com",
    "name": "João Silva",
    "isPremium": true,
    "accountStatus": "premium_released",
    "brokerUserId": "BR12345"
  }
}
```

### 6. Verificar Acesso Premium
```bash
curl -X GET "http://localhost:5000/api/account-status" \
  -H "Authorization: Bearer SEU_TOKEN_AQUI"
```

**Resposta Esperada:**
```json
{
  "success": true,
  "account": {
    "id": 1,
    "email": "joao@email.com",
    "name": "João Silva",
    "isPremium": true,
    "accountStatus": "premium_released",
    "brokerRegistered": true,
    "brokerUserId": "BR12345",
    "canAccessPremium": true
  }
}
```

## Testes Administrativos

### 1. Login Admin
```bash
curl -X POST "http://localhost:5000/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@trademaster.com",
    "password": "admin123"
  }'
```

### 2. Simular Usuário Novo da Corretora
```bash
curl -X POST "http://localhost:5000/api/webhook/broker-registration" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "maria@email.com",
    "id_corretora": "BR67890",
    "name": "Maria Santos",
    "evento": "cadastro_efetuado"
  }'
```

### 3. Listar Usuários Pendentes
```bash
curl -X GET "http://localhost:5000/api/admin/pending-users" \
  -H "Authorization: Bearer ADMIN_TOKEN_AQUI"
```

### 4. Aprovar Usuário
```bash
curl -X POST "http://localhost:5000/api/admin/approve-user/2" \
  -H "Authorization: Bearer ADMIN_TOKEN_AQUI"
```

### 5. Rejeitar Usuário
```bash
curl -X POST "http://localhost:5000/api/admin/reject-user/2" \
  -H "Authorization: Bearer ADMIN_TOKEN_AQUI"
```

## Estrutura do Banco de Dados

### Tabela Users
```sql
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role VARCHAR(50) DEFAULT 'user',
  is_premium BOOLEAN DEFAULT FALSE,
  broker_registered BOOLEAN DEFAULT FALSE,
  broker_user_id VARCHAR(255),
  account_status VARCHAR(50) DEFAULT 'not_released',
  profile_image_url VARCHAR(255),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### Estados da Conta
- `not_released`: Conta não liberada (padrão)
- `premium_released`: Conta liberada para premium
- `pending_review`: Pendente de análise manual

## Logs do Sistema

### Localização dos Logs
```bash
# Logs em tempo real
tail -f logs/app.log

# Logs de webhook
tail -f logs/webhook.log

# Logs de erro
tail -f logs/error.log
```

### Exemplos de Logs
```
[2025-07-12 17:38:00] [INFO] Usuario created: joao@email.com (ID: 1)
[2025-07-12 17:38:30] [WEBHOOK] Usuario updated to premium: joao@email.com
[2025-07-12 17:39:00] [ADMIN] User approved: maria@email.com (ID: 2)
```

## Endpoints Principais

### Autenticação
- `POST /api/auth/register` - Cadastro de usuário
- `POST /api/auth/login` - Login
- `GET /api/auth/me` - Dados do usuário logado

### Conta
- `GET /api/account-status` - Status da conta
- `GET /api/broker-redirect` - Link para corretora

### Webhook
- `POST /api/webhook/broker-registration` - Recebe dados da corretora
- `GET /api/webhook/status` - Status do webhook

### Admin
- `GET /api/admin/pending-users` - Lista usuários pendentes
- `POST /api/admin/approve-user/:id` - Aprova usuário
- `POST /api/admin/reject-user/:id` - Rejeita usuário

## Monitoramento

### Verificar Sistema
```bash
# Status da aplicação
curl -X GET "http://localhost:5000/health"

# Estatísticas
curl -X GET "http://localhost:5000/api/stats"

# Logs recentes
curl -X GET "http://localhost:5000/api/logs"
```

### Métricas
- Total de usuários
- Usuários premium
- Usuários pendentes
- Taxa de conversão
- Uptime do sistema

## Configuração da Corretora

### URL do Webhook
```
http://localhost:5000/api/webhook/broker-registration
```

### Configuração Recomendada
- **Método**: POST
- **Content-Type**: application/json
- **Timeout**: 10 segundos
- **Retry**: 3 tentativas

### Formato dos Dados
```json
{
  "email": "usuario@email.com",
  "id_corretora": "BR12345",
  "name": "Nome do Usuario",
  "evento": "cadastro_efetuado"
}
```

## Troubleshooting

### Problemas Comuns

#### 1. Erro de Conexão com Banco
```bash
# Verificar se PostgreSQL está rodando
systemctl status postgresql

# Verificar conexão
psql -U postgres -d investidor_academy -c "SELECT 1"
```

#### 2. Erro JWT
```bash
# Verificar variável de ambiente
echo $JWT_SECRET

# Gerar nova chave
openssl rand -base64 32
```

#### 3. Webhook Não Funcionando
```bash
# Verificar logs
tail -f logs/webhook.log

# Testar manualmente
curl -X POST "http://localhost:5000/api/webhook/broker-registration" \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","id_corretora":"TEST123"}'
```

## Deployment

### Produção
```bash
# Build
npm run build

# Iniciar produção
NODE_ENV=production npm start
```

### Docker
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
CMD ["npm", "start"]
```

### Variáveis de Produção
```bash
DATABASE_URL=postgresql://user:pass@db:5432/investidor_academy
JWT_SECRET=sua-chave-secreta-producao
NODE_ENV=production
PORT=5000
```

## Conclusão

Sistema completo implementado com:
- ✅ Autenticação JWT
- ✅ Cadastro e login de usuários
- ✅ Webhook para liberação automática
- ✅ Painel administrativo
- ✅ Controle de acesso premium
- ✅ Logs detalhados
- ✅ Documentação completa
- ✅ Testes funcionais
- ✅ Deploy pronto para produção

O sistema está pronto para uso em produção e pode ser facilmente integrado com qualquer corretora que envie webhooks no formato JSON especificado.