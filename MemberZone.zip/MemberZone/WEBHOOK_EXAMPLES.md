# Webhook da Corretora - Exemplos de Uso

## Visão Geral

Este webhook recebe dados de cadastro de usuários da corretora e os registra automaticamente no sistema como usuários premium.

## Endpoints Disponíveis

### 1. Cadastro de Usuário (Principal)
```
POST /webhook/broker/user-registration
```

### 2. Teste de Conectividade
```
GET/POST /webhook/broker/test
```

### 3. Status do Webhook
```
GET /webhook/broker/status
```

### 4. Endpoints Alternativos
```
POST /webhook/corretora/cadastro
POST /api/webhook/user-registration
```

## Formato dos Dados

### Dados Obrigatórios
```json
{
  "nome": "João Silva",
  "email": "joao@email.com",
  "telefone": "11999999999",
  "id_corretora": "USER123456"
}
```

### Dados Opcionais
```json
{
  "nome": "João Silva",
  "email": "joao@email.com",
  "telefone": "11999999999",
  "id_corretora": "USER123456",
  "data_cadastro": "2025-07-12T17:21:00Z",
  "status": "cadastrado"
}
```

## Exemplos de Teste

### 1. Teste com cURL - Cadastro Novo
```bash
curl -X POST http://localhost:5000/webhook/broker/user-registration \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "Maria Santos",
    "email": "maria@email.com",
    "telefone": "11888888888",
    "id_corretora": "USER789123"
  }'
```

**Resposta esperada (200):**
```json
{
  "success": true,
  "message": "Usuário cadastrado com sucesso",
  "user": {
    "id": 76,
    "email": "maria@email.com",
    "name": "Maria Santos",
    "isPremium": true,
    "created_at": "2025-07-12T17:21:00.000Z"
  }
}
```

### 2. Teste com cURL - Usuário Já Existe
```bash
curl -X POST http://localhost:5000/webhook/broker/user-registration \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "Maria Santos",
    "email": "maria@email.com",
    "telefone": "11888888888",
    "id_corretora": "USER789123"
  }'
```

**Resposta esperada (409):**
```json
{
  "success": false,
  "message": "Usuário já está cadastrado",
  "email": "maria@email.com",
  "existing_user_id": 76
}
```

### 3. Teste com cURL - Dados Inválidos
```bash
curl -X POST http://localhost:5000/webhook/broker/user-registration \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "",
    "email": "email-invalido",
    "telefone": "123"
  }'
```

**Resposta esperada (400):**
```json
{
  "success": false,
  "message": "Dados inválidos",
  "errors": [
    "Nome é obrigatório e deve ter pelo menos 2 caracteres",
    "Email válido é obrigatório",
    "Telefone é obrigatório e deve ter pelo menos 8 caracteres",
    "ID da corretora é obrigatório"
  ]
}
```

### 4. Teste de Conectividade
```bash
curl -X GET http://localhost:5000/webhook/broker/test
```

**Resposta esperada (200):**
```json
{
  "success": true,
  "message": "Webhook está funcionando",
  "timestamp": "2025-07-12T17:21:00.000Z",
  "received_data": {}
}
```

### 5. Verificar Status
```bash
curl -X GET http://localhost:5000/webhook/broker/status
```

**Resposta esperada (200):**
```json
{
  "success": true,
  "message": "Webhook da corretora está ativo",
  "status": "active",
  "statistics": {
    "total_users": 75,
    "premium_users": 20,
    "broker_users": 15
  },
  "endpoints": {
    "registration": "/webhook/broker/user-registration",
    "test": "/webhook/broker/test",
    "status": "/webhook/broker/status"
  },
  "timestamp": "2025-07-12T17:21:00.000Z"
}
```

## Códigos de Status HTTP

| Status | Significado | Quando ocorre |
|--------|-------------|---------------|
| 200    | Sucesso     | Usuário cadastrado com sucesso |
| 400    | Dados inválidos | Dados obrigatórios ausentes ou inválidos |
| 409    | Conflito    | Usuário já existe no sistema |
| 500    | Erro interno | Erro no servidor |

## Validações Realizadas

1. **Nome**: Obrigatório, mínimo 2 caracteres
2. **Email**: Obrigatório, formato válido
3. **Telefone**: Obrigatório, mínimo 8 caracteres
4. **ID da Corretora**: Obrigatório

## Campos Flexíveis

O webhook aceita diferentes nomes para os campos:

- **Nome**: `nome`, `name`, `full_name`, `usuario`
- **Email**: `email`, `e_mail`, `user_email`, `login`
- **Telefone**: `telefone`, `phone`, `celular`, `whatsapp`
- **ID Corretora**: `id_corretora`, `broker_id`, `user_id`, `id`

## Funcionalidades Automáticas

1. **Usuário Premium**: Todos os usuários vindos da corretora são automaticamente premium
2. **Senha Temporária**: Gerada automaticamente (8 caracteres aleatórios)
3. **Verificação de Duplicatas**: Verifica se o email já existe
4. **Logs Detalhados**: Registra todas as operações para auditoria

## Configuração em Produção

Para usar em produção, configure a corretora para enviar dados para:
```
https://seudominio.com/webhook/broker/user-registration
```

Certifique-se de:
- Configurar HTTPS
- Implementar autenticação se necessário
- Monitorar logs para detectar problemas
- Configurar alertas para falhas

## Monitoramento

O webhook registra logs detalhados de todas as operações:
- Dados recebidos
- Validações realizadas
- Usuários criados
- Erros ocorridos

Verifique os logs do servidor para monitoramento em tempo real.