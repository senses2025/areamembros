# Webhook Integration Guide

## URLs dos Webhooks

### 1. Registro de Novos Usuários
```
POST https://[seu-dominio].replit.app/webhook/registration
```

**Payload esperado:**
```json
{
  "name": "João Silva",
  "email": "joao.silva@email.com",
  "whatsapp": "+5511999999999",
  "registrationDate": "2024-06-12T10:30:00Z",
  "source": "website"
}
```

### 2. Notificação de Depósitos
```
POST https://[seu-dominio].replit.app/webhook/deposit
```

**Payload esperado:**
```json
{
  "email": "joao.silva@email.com",
  "depositAmount": "1500.00",
  "depositDate": "2024-06-12T14:30:00Z"
}
```

### 3. Status dos Webhooks
```
GET https://[seu-dominio].replit.app/webhook/status
```

### 4. Debug dos Webhooks (para testes)
```
POST https://[seu-dominio].replit.app/webhook/debug
```
*Use esta URL temporariamente na corretora para capturar exatamente quais dados estão sendo enviados*

## Segurança

### Assinatura dos Webhooks (Opcional)
Para maior segurança, adicione o header `X-Webhook-Signature` com HMAC SHA-256:

```javascript
const crypto = require('crypto');
const signature = crypto
  .createHmac('sha256', 'sua-chave-secreta')
  .update(JSON.stringify(payload))
  .digest('hex');
```

## Configuração na Corretora

### Para MT4/MT5:
1. Use Expert Advisor (EA) para enviar requisições HTTP
2. Configure os endpoints acima
3. Envie dados quando:
   - Novo cliente se registra
   - Cliente faz primeiro depósito

### Para plataformas web:
1. Configure webhooks nos eventos:
   - `user_registered`
   - `deposit_completed`
2. Use os endpoints fornecidos

## Exemplo de Teste

### Teste de Registro:
```bash
curl -X POST https://[seu-dominio].replit.app/webhook/registration \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Teste Usuario",
    "email": "teste@email.com",
    "whatsapp": "+5511999999999"
  }'
```

### Teste de Depósito:
```bash
curl -X POST https://[seu-dominio].replit.app/webhook/deposit \
  -H "Content-Type: application/json" \
  -d '{
    "email": "teste@email.com",
    "depositAmount": "1000.00"
  }'
```

## Respostas

### Sucesso (201/200):
```json
{
  "message": "Affiliate registered successfully",
  "affiliate": { /* dados do afiliado */ }
}
```

### Erro (400):
```json
{
  "message": "Invalid request data",
  "errors": [/* detalhes dos erros */]
}
```

### Usuário já existe (409):
```json
{
  "message": "Affiliate already exists",
  "affiliateId": 123
}
```