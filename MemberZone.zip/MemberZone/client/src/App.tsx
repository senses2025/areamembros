import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { Layout } from "@/components/Layout";
import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";
import { getAuthToken, setAuthHeader } from "@/lib/authUtils";

// Pages
import Home from "@/pages/Home";
import Classes from "@/pages/Classes";
import Live from "@/pages/Live";
import Management from "@/pages/Management";
import TradingRobot from "@/pages/TradingRobot";
import Admin from "@/pages/Admin";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import WebhookLogin from "@/pages/WebhookLogin";
import AdminLogin from "@/pages/AdminLogin";
import BrokerRegistration from "@/pages/BrokerRegistration";
import PendingApproval from "@/pages/PendingApproval";
import NotFound from "@/pages/not-found";

// Update the queryClient to include auth headers
const originalFetch = window.fetch;
window.fetch = async (url, options = {}) => {
  const headers = {
    ...options.headers,
    ...setAuthHeader(),
  };
  
  return originalFetch(url, {
    ...options,
    headers,
  });
};

function AuthenticatedRoutes({ user }: { user: any }) {
  if (user && !user.isPremium && user.role !== 'admin') {
    // Non-premium users see pending approval screen
    return (
      <Switch>
        <Route path="/" component={PendingApproval} />
        <Route component={PendingApproval} />
      </Switch>
    );
  }

  // Protected routes for premium users and admins
  return (
    <Switch>
      <Route path="/">
        <Layout>
          <Home />
        </Layout>
      </Route>
      <Route path="/classes">
        <Layout>
          <Classes />
        </Layout>
      </Route>
      <Route path="/live">
        <Layout>
          <Live />
        </Layout>
      </Route>
      <Route path="/management">
        <Layout>
          <Management />
        </Layout>
      </Route>
      <Route path="/robot">
        <Layout>
          <TradingRobot />
        </Layout>
      </Route>
      <Route path="/admin">
        <Layout>
          <Admin />
        </Layout>
      </Route>
      {/* Redirect auth routes to home if already authenticated */}
      <Route path="/login">
        <Layout>
          <Home />
        </Layout>
      </Route>
      <Route path="/register">
        <Layout>
          <Home />
        </Layout>
      </Route>
      <Route component={() => (
        <Layout>
          <NotFound />
        </Layout>
      )} />
    </Switch>
  );
}

function UnauthenticatedRoutes() {
  return (
    <Switch>
      <Route path="/register" component={Register} />
      <Route path="/login" component={Login} />
      <Route path="/webhook-login" component={WebhookLogin} />
      <Route path="/admin-login" component={AdminLogin} />
      <Route path="/" component={Login} />
      <Route component={Login} />
    </Switch>
  );
}

function Router() {
  const { user, isAuthenticated, isLoading } = useAuth();

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-primary rounded-lg flex items-center justify-center mx-auto mb-4 animate-pulse">
            <div className="w-8 h-8 bg-primary-foreground rounded"></div>
          </div>
          <p className="text-foreground text-lg">Carregando...</p>
        </div>
      </div>
    );
  }

  // Always render the same component structure to avoid hook order issues
  return isAuthenticated ? (
    <AuthenticatedRoutes user={user} />
  ) : (
    <UnauthenticatedRoutes />
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
