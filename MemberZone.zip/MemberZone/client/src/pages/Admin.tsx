import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { insertVideoSchema, insertLiveStreamSchema } from "@shared/schema";
import { z } from "zod";
import {
  Users,
  Video,
  Radio,
  Crown,
  Edit,
  Trash2,
  BarChart3,
  Bot,
  Palette,
  Upload,
  Calendar,
  PieChart,
  TrendingUp,
  Activity,
  DollarSign,
  Target,
  Eye,
  Play,
  Star,
  Shield,
  Zap,
  Download,
  HardDrive,
  Award,
  Check,
  Share,
  Timer,
  Plus,
  Save,
  Settings
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RechartsPieChart, Pie, Cell, LineChart, Line, AreaChart, Area } from 'recharts';

export default function Admin() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // States
  const [activeTab, setActiveTab] = useState("dashboard");
  const [isEditingDashboard, setIsEditingDashboard] = useState(false);
  const [dashboardData, setDashboardData] = useState({
    card1: {
      title: "Operações Hoje",
      value: "0",
      subtitle: "0 WINs / 0 LOSSes"
    },
    card2: {
      title: "Taxa de Acerto", 
      value: "0%",
      subtitle: "Hoje"
    },
    card3: {
      title: "Resultado Hoje",
      value: "R$ 0,00",
      subtitle: "Lucro/Prejuízo"
    },
    card4: {
      title: "Próxima Live",
      value: "19:30",
      subtitle: "Estratégias Avançadas"
    }
  });

  // States para sinais programados
  const [signalForm, setSignalForm] = useState({
    asset: '',
    time: '',
    direction: '',
    expiration: '1'
  });
  const [useScheduledSignals, setUseScheduledSignals] = useState(false);
  const [repeatList, setRepeatList] = useState(false);

  // Load dashboard configuration
  const { data: dashboardConfig } = useQuery({
    queryKey: ["/api/dashboard-config"],
    staleTime: 0, // Always fetch fresh data
  });

  // Load dashboard config into state when data changes
  useEffect(() => {
    if (dashboardConfig && dashboardConfig.card1) {
      setDashboardData(dashboardConfig as typeof dashboardData);
    }
  }, [dashboardConfig]);



  // Functions para lidar com eventos dos formulários
  const handleAddSignal = () => {
    if (!signalForm.asset || !signalForm.time || !signalForm.direction) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos obrigatórios.",
        variant: "destructive",
      });
      return;
    }
    addScheduledSignal.mutate(signalForm);
  };

  const handleClearAllSignals = () => {
    clearAllSignals.mutate();
  };



  // Mutation to save dashboard configuration
  const saveDashboardConfig = useMutation({
    mutationFn: async (config: typeof dashboardData) => {
      const response = await fetch("/api/dashboard-config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(config),
      });
      if (!response.ok) throw new Error("Failed to save dashboard config");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Configurações Salvas",
        description: "As configurações do dashboard foram atualizadas com sucesso!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard-config"] });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao salvar as configurações do dashboard.",
        variant: "destructive",
      });
    },
  });

  // Mutation para adicionar sinal programado
  const addScheduledSignal = useMutation({
    mutationFn: async (signal: typeof signalForm) => {
      const response = await fetch("/api/scheduled-signals", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem("token")}`
        },
        body: JSON.stringify(signal),
      });
      if (!response.ok) throw new Error("Failed to add scheduled signal");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Sinal Adicionado",
        description: "O sinal foi adicionado à lista com sucesso!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/scheduled-signals"] });
      setSignalForm({ asset: '', time: '', direction: '', expiration: '1' });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao adicionar o sinal.",
        variant: "destructive",
      });
    },
  });

  // Mutation para limpar todos os sinais
  const clearAllSignals = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/scheduled-signals", {
        method: "DELETE",
        headers: { 
          "Authorization": `Bearer ${localStorage.getItem("token")}`
        },
      });
      if (!response.ok) throw new Error("Failed to clear signals");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Sinais Limpos",
        description: "Todos os sinais foram removidos da lista.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/scheduled-signals"] });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao limpar os sinais.",
        variant: "destructive",
      });
    },
  });

  // Mutation para atualizar configuração do robô
  const updateRobotConfig = useMutation({
    mutationFn: async (config: { useScheduledSignals: boolean; repeatList: boolean }) => {
      const response = await fetch("/api/robot/config", {
        method: "PATCH",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem("token")}`
        },
        body: JSON.stringify(config),
      });
      if (!response.ok) throw new Error("Failed to update robot config");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Configuração Atualizada",
        description: "As configurações do robô foram atualizadas!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/robot/config"] });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao atualizar a configuração do robô.",
        variant: "destructive",
      });
    },
  });

  // Check admin access
  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-6">
            <p className="text-white">Acesso negado. Apenas administradores podem acessar esta página.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Data fetching
  const { data: users = [] } = useQuery({
    queryKey: ["/api/users"],
    enabled: user?.role === "admin",
  });

  // Query para carregar sinais programados
  const { data: scheduledSignals = [] } = useQuery({
    queryKey: ["/api/scheduled-signals"],
    enabled: user?.role === "admin",
  });

  // Query para carregar configuração do robô
  const { data: robotConfig } = useQuery({
    queryKey: ["/api/robot/config"],
    enabled: user?.role === "admin",
  });

  // Load robot config into state when data changes
  useEffect(() => {
    if (robotConfig) {
      setUseScheduledSignals(robotConfig.useScheduledSignals || false);
      setRepeatList(robotConfig.repeatList || false);
    }
  }, [robotConfig]);

  const { data: videos = [] } = useQuery({
    queryKey: ["/api/videos"],
    enabled: user?.role === "admin",
  });

  const { data: liveStreams = [] } = useQuery({
    queryKey: ["/api/live-streams"],
    enabled: user?.role === "admin",
  });

  const { data: platformStats } = useQuery({
    queryKey: ["/api/platform-stats"],
    enabled: user?.role === "admin",
  });

  const { data: tradingStats } = useQuery({
    queryKey: ["/api/trading-stats"],
    enabled: user?.role === "admin",
  });

  const { data: tradingLogs = [] } = useQuery({
    queryKey: ["/api/trading-logs"],
    enabled: user?.role === "admin",
  });

  // Safe array access
  const usersArray = Array.isArray(users) ? users : [];
  const videosArray = Array.isArray(videos) ? videos : [];
  const liveStreamsArray = Array.isArray(liveStreams) ? liveStreams : [];

  // Chart data
  const userGrowthData = [
    { month: 'Jan', users: 45 },
    { month: 'Fev', users: 52 },
    { month: 'Mar', users: 61 },
    { month: 'Abr', users: 68 },
    { month: 'Mai', users: 70 },
    { month: 'Jun', users: 70 }
  ];

  const premiumUsers = usersArray.filter((u: any) => u.isPremium).length;
  const totalUsers = usersArray.length;
  const freeUsers = totalUsers - premiumUsers;

  const COLORS = ['#10B981', '#6B7280'];

  // Form setup
  const videoForm = useForm({
    resolver: zodResolver(insertVideoSchema),
    defaultValues: {
      title: "",
      description: "",
      videoUrl: "",
      thumbnailUrl: "",
      category: "",
      level: "básico",
      instructor: "Investidor Academy",
      tags: "",
      language: "pt-BR",
      isPremium: false,
      isFeatured: false,
    },
  });

  const liveStreamForm = useForm({
    resolver: zodResolver(insertLiveStreamSchema),
    defaultValues: {
      title: "",
      description: "",
      streamUrl: "",
      platform: "youtube",
      isLive: false,
      isPremium: false,
    },
  });

  // Mutations
  const createVideoMutation = useMutation({
    mutationFn: async (data: any) => {
      const authToken = localStorage.getItem('authToken');
      const response = await fetch("/api/videos", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${authToken}`
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to create video');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      videoForm.reset();
      toast({ 
        title: "✅ Aula criada com sucesso!",
        description: "O conteúdo foi adicionado à plataforma."
      });
    },
    onError: (error: Error) => {
      toast({ 
        title: "❌ Erro ao criar aula",
        description: error.message,
        variant: "destructive"
      });
    },
  });

  const createLiveStreamMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch("/api/live-streams", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to create live stream');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/live-streams"] });
      liveStreamForm.reset();
      toast({ title: "Live criada com sucesso!" });
    },
  });

  const deleteLiveStreamMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/live-streams/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error('Failed to delete live stream');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/live-streams"] });
      toast({ title: "Live deletada com sucesso!" });
    },
  });

  const toggleLiveStatusMutation = useMutation({
    mutationFn: async ({ id, isLive }: { id: number; isLive: boolean }) => {
      const response = await fetch(`/api/live-streams/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isLive }),
      });
      if (!response.ok) throw new Error('Failed to update live status');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/live-streams"] });
      toast({ title: "Status da live atualizado!" });
    },
  });

  const toggleUserPremiumMutation = useMutation({
    mutationFn: async ({ userId, isPremium }: { userId: number; isPremium: boolean }) => {
      const authToken = localStorage.getItem('authToken');
      const response = await fetch(`/api/users/${userId}/premium`, {
        method: "PATCH",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${authToken}`
        },
        body: JSON.stringify({ isPremium }),
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to update user premium status');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({ 
        title: "✅ Status premium atualizado!",
        description: "O status do usuário foi alterado com sucesso."
      });
    },
    onError: (error: Error) => {
      toast({ 
        title: "❌ Erro ao atualizar status",
        description: error.message,
        variant: "destructive"
      });
    },
  });

  const updateVideoMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const authToken = localStorage.getItem('authToken');
      const response = await fetch(`/api/videos/${id}`, {
        method: "PATCH",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${authToken}`
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to update video');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      toast({ title: "Aula atualizada com sucesso!" });
    },
  });

  const deleteVideoMutation = useMutation({
    mutationFn: async (id: number) => {
      const authToken = localStorage.getItem('authToken');
      const response = await fetch(`/api/videos/${id}`, {
        method: "DELETE",
        headers: { 
          "Authorization": `Bearer ${authToken}`
        },
      });
      if (!response.ok) throw new Error('Failed to delete video');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      toast({ title: "Aula deletada com sucesso!" });
    },
  });

  // Form handlers
  const onVideoSubmit = (data: any) => createVideoMutation.mutate(data);
  const onLiveStreamSubmit = (data: any) => createLiveStreamMutation.mutate(data);
  const deleteLiveStream = (id: number) => deleteLiveStreamMutation.mutate(id);
  const toggleLiveStatus = (id: number, isLive: boolean) => 
    toggleLiveStatusMutation.mutate({ id, isLive });
  const toggleUserPremium = (userId: number, isPremium: boolean) =>
    toggleUserPremiumMutation.mutate({ userId, isPremium });

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <Card className="bg-card border-border shadow-2xl">
        <CardHeader className="border-b border-border bg-gradient-to-r from-card to-muted/30">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-3xl font-bold text-foreground flex items-center">
                <div className="p-3 bg-primary rounded-xl mr-4 shadow-lg">
                  <BarChart3 className="w-8 h-8 text-primary-foreground" />
                </div>
                Investidor Academy Pro
                <Badge className="ml-4 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground px-3 py-1">
                  Admin Dashboard
                </Badge>
              </CardTitle>
              <p className="text-muted-foreground mt-2 text-lg">Controle total da plataforma com analytics em tempo real</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Último acesso</p>
                <p className="text-foreground font-medium">{new Date().toLocaleString('pt-BR')}</p>
              </div>
              <div className="w-3 h-3 bg-primary rounded-full animate-pulse"></div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
            <TabsList className="grid w-full grid-cols-8 bg-gradient-to-r from-muted to-muted/80 p-2 rounded-xl shadow-lg border border-border">
              <TabsTrigger 
                value="dashboard" 
                className="text-muted-foreground data-[state=active]:bg-navy-blue data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-300 hover:text-foreground rounded-lg"
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Dashboard</span>
              </TabsTrigger>
              <TabsTrigger 
                value="users" 
                className="text-muted-foreground data-[state=active]:bg-navy-blue data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-300 hover:text-foreground rounded-lg"
              >
                <Users className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Usuários</span>
              </TabsTrigger>
              <TabsTrigger 
                value="content" 
                className="text-muted-foreground data-[state=active]:bg-navy-blue data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-300 hover:text-foreground rounded-lg"
              >
                <Play className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Conteúdo</span>
              </TabsTrigger>
              <TabsTrigger 
                value="aulas" 
                className="text-muted-foreground data-[state=active]:bg-navy-blue data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-300 hover:text-foreground rounded-lg"
              >
                <Video className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Aulas</span>
              </TabsTrigger>
              <TabsTrigger 
                value="lives" 
                className="text-muted-foreground data-[state=active]:bg-navy-blue data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-300 hover:text-foreground rounded-lg"
              >
                <Radio className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Lives</span>
              </TabsTrigger>
              <TabsTrigger 
                value="signals" 
                className="text-muted-foreground data-[state=active]:bg-navy-blue data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-300 hover:text-foreground rounded-lg"
              >
                <TrendingUp className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Sinais</span>
              </TabsTrigger>

              <TabsTrigger 
                value="analytics" 
                className="text-muted-foreground data-[state=active]:bg-navy-blue data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-300 hover:text-foreground rounded-lg"
              >
                <TrendingUp className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Analytics</span>
              </TabsTrigger>
              <TabsTrigger 
                value="settings" 
                className="text-gray-300 data-[state=active]:bg-gradient-to-r data-[state=active]:from-gray-600 data-[state=active]:to-gray-700 data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-300 hover:text-white rounded-lg"
              >
                <Settings className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Config</span>
              </TabsTrigger>
            </TabsList>

            {/* Dashboard Tab */}
            <TabsContent value="dashboard" className="space-y-8">
              {/* Header with Edit Button */}
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-white">Dashboard Executivo</h3>
                <Button 
                  className="bg-blue-600 hover:bg-blue-700"
                  onClick={() => setIsEditingDashboard(!isEditingDashboard)}
                >
                  <Edit className="w-4 h-4 mr-2" />
                  {isEditingDashboard ? 'Salvar' : 'Editar Cards'}
                </Button>
              </div>

              {/* Executive KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
                <Card className="bg-gradient-to-br from-card to-muted/20 border-border shadow-2xl backdrop-blur-sm">
                  <CardContent className="p-4 sm:p-6">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        {isEditingDashboard ? (
                          <Input
                            value={dashboardData.card1.title}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card1: { ...prev.card1, title: e.target.value }
                            }))}
                            className="bg-input border-border text-muted-foreground text-xs font-medium uppercase tracking-wide"
                          />
                        ) : (
                          <p className="text-muted-foreground text-xs sm:text-sm font-medium uppercase tracking-wide">{dashboardData.card1.title}</p>
                        )}
                        {isEditingDashboard ? (
                          <Input
                            value={dashboardData.card1.value}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card1: { ...prev.card1, value: e.target.value }
                            }))}
                            className="bg-input border-border text-foreground text-2xl font-bold"
                          />
                        ) : (
                          <p className="text-2xl sm:text-4xl font-bold text-foreground">{dashboardData.card1.value}</p>
                        )}
                        <div className="flex items-center space-x-2">
                          <TrendingUp className="w-3 h-3 text-primary" />
                          {isEditingDashboard ? (
                            <Input
                              value={dashboardData.card1.subtitle}
                              onChange={(e) => setDashboardData(prev => ({
                                ...prev,
                                card1: { ...prev.card1, subtitle: e.target.value }
                              }))}
                              className="bg-input border-border text-muted-foreground text-xs"
                            />
                          ) : (
                            <span className="text-muted-foreground text-xs font-medium">{dashboardData.card1.subtitle}</span>
                          )}
                        </div>
                      </div>
                      <div className="bg-muted/30 p-3 sm:p-4 rounded-2xl border border-border">
                        <Users className="w-8 h-8 sm:w-10 sm:h-10 text-primary" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-card to-muted/20 border-border shadow-2xl backdrop-blur-sm">
                  <CardContent className="p-4 sm:p-6">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        {isEditingDashboard ? (
                          <Input
                            value={dashboardData.card2.title}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card2: { ...prev.card2, title: e.target.value }
                            }))}
                            className="bg-input border-border text-muted-foreground text-xs font-medium uppercase tracking-wide"
                          />
                        ) : (
                          <p className="text-muted-foreground text-xs sm:text-sm font-medium uppercase tracking-wide">{dashboardData.card2.title}</p>
                        )}
                        {isEditingDashboard ? (
                          <Input
                            value={dashboardData.card2.value}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card2: { ...prev.card2, value: e.target.value }
                            }))}
                            className="bg-input border-border text-foreground text-2xl font-bold"
                          />
                        ) : (
                          <p className="text-2xl sm:text-4xl font-bold text-foreground">{dashboardData.card2.value}</p>
                        )}
                        <div className="flex items-center space-x-2">
                          <Crown className="w-3 h-3 text-primary" />
                          {isEditingDashboard ? (
                            <Input
                              value={dashboardData.card2.subtitle}
                              onChange={(e) => setDashboardData(prev => ({
                                ...prev,
                                card2: { ...prev.card2, subtitle: e.target.value }
                              }))}
                              className="bg-input border-border text-muted-foreground text-xs"
                            />
                          ) : (
                            <span className="text-muted-foreground text-xs font-medium">{dashboardData.card2.subtitle}</span>
                          )}
                        </div>
                      </div>
                      <div className="bg-muted/30 p-3 sm:p-4 rounded-2xl border border-border">
                        <Crown className="w-8 h-8 sm:w-10 sm:h-10 text-primary" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-card to-muted/20 border-border shadow-2xl backdrop-blur-sm">
                  <CardContent className="p-4 sm:p-6">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        {isEditingDashboard ? (
                          <Input
                            value={dashboardData.card3.title}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card3: { ...prev.card3, title: e.target.value }
                            }))}
                            className="bg-input border-border text-muted-foreground text-xs font-medium uppercase tracking-wide"
                          />
                        ) : (
                          <p className="text-muted-foreground text-xs sm:text-sm font-medium uppercase tracking-wide">{dashboardData.card3.title}</p>
                        )}
                        {isEditingDashboard ? (
                          <Input
                            value={dashboardData.card3.value}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card3: { ...prev.card3, value: e.target.value }
                            }))}
                            className="bg-input border-border text-foreground text-2xl font-bold"
                          />
                        ) : (
                          <p className="text-2xl sm:text-4xl font-bold text-foreground">{dashboardData.card3.value}</p>
                        )}
                        <div className="flex items-center space-x-2">
                          <DollarSign className="w-3 h-3 text-primary" />
                          {isEditingDashboard ? (
                            <Input
                              value={dashboardData.card3.subtitle}
                              onChange={(e) => setDashboardData(prev => ({
                                ...prev,
                                card3: { ...prev.card3, subtitle: e.target.value }
                              }))}
                              className="bg-input border-border text-muted-foreground text-xs"
                            />
                          ) : (
                            <span className="text-muted-foreground text-xs font-medium">{dashboardData.card3.subtitle}</span>
                          )}
                        </div>
                      </div>
                      <div className="bg-muted/30 p-3 sm:p-4 rounded-2xl border border-border">
                        <DollarSign className="w-8 h-8 sm:w-10 sm:h-10 text-primary" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-card to-muted/20 border-border shadow-2xl backdrop-blur-sm">
                  <CardContent className="p-4 sm:p-6">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        {isEditingDashboard ? (
                          <Input
                            value={dashboardData.card4.title}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card4: { ...prev.card4, title: e.target.value }
                            }))}
                            className="bg-input border-border text-muted-foreground text-xs font-medium uppercase tracking-wide"
                          />
                        ) : (
                          <p className="text-muted-foreground text-xs sm:text-sm font-medium uppercase tracking-wide">{dashboardData.card4.title}</p>
                        )}
                        {isEditingDashboard ? (
                          <Input
                            value={dashboardData.card4.value}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card4: { ...prev.card4, value: e.target.value }
                            }))}
                            className="bg-input border-border text-foreground text-2xl font-bold"
                          />
                        ) : (
                          <p className="text-2xl sm:text-4xl font-bold text-foreground">{dashboardData.card4.value}</p>
                        )}
                        <div className="flex items-center space-x-2">
                          <Activity className="w-3 h-3 text-primary" />
                          {isEditingDashboard ? (
                            <Input
                              value={dashboardData.card4.subtitle}
                              onChange={(e) => setDashboardData(prev => ({
                                ...prev,
                                card4: { ...prev.card4, subtitle: e.target.value }
                              }))}
                              className="bg-input border-border text-muted-foreground text-xs"
                            />
                          ) : (
                            <span className="text-muted-foreground text-xs font-medium">{dashboardData.card4.subtitle}</span>
                          )}
                        </div>
                      </div>
                      <div className="bg-muted/30 p-3 sm:p-4 rounded-2xl border border-border">
                        <Activity className="w-8 h-8 sm:w-10 sm:h-10 text-primary" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Advanced Analytics Dashboard */}
              <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 sm:gap-8">
                {/* Main Revenue Chart */}
                <Card className="xl:col-span-2 bg-gray-800/95 border-gray-700/50 shadow-2xl backdrop-blur-sm">
                  <CardHeader className="border-b border-gray-700/50 pb-4">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg sm:text-xl font-bold text-white flex items-center">
                        <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6 mr-2 sm:mr-3 text-blue-400" />
                        <span className="hidden sm:inline">Performance de Revenue (6 meses)</span>
                        <span className="sm:hidden">Revenue (6m)</span>
                      </CardTitle>
                      <div className="flex items-center space-x-2">
                        <Badge className="bg-green-600/20 text-green-400 border-green-600/30">
                          +{Math.round(((premiumUsers * 197) / 10000) * 100)}% ROI
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-4 sm:p-6">
                    <div className="h-64 sm:h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={[
                          { month: 'Jan', revenue: 8500, users: 43, premium: 18 },
                          { month: 'Fev', revenue: 12400, users: 52, premium: 25 },
                          { month: 'Mar', revenue: 15800, users: 61, premium: 32 },
                          { month: 'Abr', revenue: 18200, users: 68, premium: 38 },
                          { month: 'Mai', revenue: 22100, users: 70, premium: 45 },
                          { month: 'Jun', revenue: premiumUsers * 197, users: totalUsers, premium: premiumUsers }
                        ]}>
                          <defs>
                            <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#10B981" stopOpacity={0.8}/>
                              <stop offset="95%" stopColor="#10B981" stopOpacity={0.1}/>
                            </linearGradient>
                            <linearGradient id="usersGradient" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.6}/>
                              <stop offset="95%" stopColor="#3B82F6" stopOpacity={0.1}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                          <XAxis dataKey="month" stroke="#9CA3AF" fontSize={12} />
                          <YAxis stroke="#9CA3AF" fontSize={12} />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: '#1F2937', 
                              border: '1px solid #374151',
                              borderRadius: '12px',
                              color: '#fff',
                              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)'
                            }} 
                            formatter={(value, name) => [
                              name === 'revenue' ? `R$ ${value.toLocaleString('pt-BR')}` : value,
                              name === 'revenue' ? 'Revenue' : name === 'users' ? 'Usuários' : 'Premium'
                            ]}
                          />
                          <Area type="monotone" dataKey="revenue" stroke="#10B981" fillOpacity={1} fill="url(#revenueGradient)" strokeWidth={3} />
                          <Area type="monotone" dataKey="users" stroke="#3B82F6" fillOpacity={1} fill="url(#usersGradient)" strokeWidth={2} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="grid grid-cols-3 gap-4 mt-6 pt-4 border-t border-gray-700/50">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-green-400">R$ {(premiumUsers * 197).toLocaleString('pt-BR')}</p>
                        <p className="text-sm text-gray-400">Revenue Atual</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-blue-400">{totalUsers}</p>
                        <p className="text-sm text-gray-400">Total Usuários</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-purple-400">{premiumUsers}</p>
                        <p className="text-sm text-gray-400">Premium Ativos</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Conversion Funnel */}
                <Card className="bg-gray-800/95 border-gray-700/50 shadow-2xl backdrop-blur-sm">
                  <CardHeader className="border-b border-gray-700/50 pb-4">
                    <CardTitle className="text-lg font-bold text-white flex items-center">
                      <Target className="w-5 h-5 mr-2 text-purple-400" />
                      Funil de Conversão
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-6">
                      {[
                        { stage: 'Visitantes', value: Math.round(totalUsers * 2.3), color: 'bg-gray-600', percentage: 100 },
                        { stage: 'Registros', value: totalUsers, color: 'bg-blue-600', percentage: 43 },
                        { stage: 'Engajados', value: Math.round(totalUsers * 0.8), color: 'bg-yellow-600', percentage: 35 },
                        { stage: 'Premium', value: premiumUsers, color: 'bg-green-600', percentage: totalUsers > 0 ? Math.round((premiumUsers / totalUsers) * 100) : 0 }
                      ].map((stage, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-white font-medium">{stage.stage}</span>
                            <span className="text-gray-300 text-sm">{stage.value}</span>
                          </div>
                          <div className="w-full bg-gray-700 rounded-full h-3">
                            <div 
                              className={`h-3 rounded-full ${stage.color} transition-all duration-700 ease-out`}
                              style={{ width: `${stage.percentage}%` }}
                            />
                          </div>
                          <div className="flex justify-between text-xs">
                            <span className="text-gray-400">{stage.percentage}% do total</span>
                            {index > 0 && (
                              <span className="text-green-400">
                                +{Math.round(((stage.value / totalUsers) * 100) - ((stage.value / (totalUsers * 2.3)) * 100))}% conversão
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="mt-6 p-4 bg-green-900/20 rounded-lg border border-green-700/30">
                      <div className="flex items-center space-x-2 mb-2">
                        <Target className="w-4 h-4 text-green-400" />
                        <span className="text-green-300 font-medium text-sm">Meta Mensal</span>
                      </div>
                      <p className="text-2xl font-bold text-green-400">{Math.round((premiumUsers / 100) * 100)}%</p>
                      <p className="text-xs text-green-300">Meta: 100 premium</p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Charts Section */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* User Growth Chart */}
                <Card className="bg-gray-800 border-gray-700 shadow-xl">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <TrendingUp className="w-5 h-5 mr-2 text-blue-400" />
                      Crescimento de Usuários (6 meses)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={userGrowthData}>
                          <defs>
                            <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.8}/>
                              <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                          <XAxis dataKey="month" stroke="#9CA3AF" />
                          <YAxis stroke="#9CA3AF" />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: '#1F2937', 
                              border: '1px solid #374151',
                              borderRadius: '8px',
                              color: '#fff'
                            }} 
                          />
                          <Area type="monotone" dataKey="users" stroke="#3B82F6" fillOpacity={1} fill="url(#colorUsers)" strokeWidth={3} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                {/* Premium Distribution Chart */}
                <Card className="bg-gray-800 border-gray-700 shadow-xl">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <PieChart className="w-5 h-5 mr-2 text-green-400" />
                      Distribuição Premium vs Gratuito
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsPieChart>
                          <Pie
                            data={[
                              { name: 'Premium', value: premiumUsers },
                              { name: 'Gratuitos', value: freeUsers }
                            ]}
                            cx="50%" 
                            cy="50%" 
                            outerRadius={80} 
                            dataKey="value"
                          >
                            <Cell fill="#10B981" />
                            <Cell fill="#6B7280" />
                          </Pie>
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: '#1F2937', 
                              border: '1px solid #374151',
                              borderRadius: '8px'
                            }}
                          />
                        </RechartsPieChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="flex justify-center space-x-6 mt-4">
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                        <span className="text-sm text-gray-300">Premium ({premiumUsers})</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-gray-500 rounded-full mr-2"></div>
                        <span className="text-sm text-gray-300">Gratuitos ({freeUsers})</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Real-time Trading & Performance Analytics */}
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                {/* Advanced Performance Metrics */}
                <Card className="bg-gradient-to-br from-gray-900/95 to-gray-800/95 border-gray-600/50 shadow-2xl backdrop-blur-sm">
                  <CardHeader className="border-b border-gray-600/50 pb-4">
                    <CardTitle className="text-xl font-bold text-white flex items-center">
                      <Activity className="w-6 h-6 mr-3 text-emerald-400" />
                      Performance do Sistema
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-6">
                      {/* System Status Grid */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-emerald-900/20 p-4 rounded-xl border border-emerald-600/30">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-emerald-300 font-medium text-sm">Server</span>
                            <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                          </div>
                          <p className="text-2xl font-bold text-emerald-400">99.9%</p>
                          <p className="text-xs text-emerald-300">Uptime</p>
                        </div>
                        <div className="bg-blue-900/20 p-4 rounded-xl border border-blue-600/30">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-blue-300 font-medium text-sm">Database</span>
                            <HardDrive className="w-4 h-4 text-blue-400" />
                          </div>
                          <p className="text-2xl font-bold text-blue-400">12ms</p>
                          <p className="text-xs text-blue-300">Latência</p>
                        </div>
                      </div>

                      {/* Performance Metrics */}
                      <div className="space-y-4">
                        {[
                          { label: 'CPU Usage', value: 23, color: 'bg-gradient-to-r from-blue-500 to-cyan-500', textColor: 'text-blue-400' },
                          { label: 'Memory', value: 45, color: 'bg-gradient-to-r from-yellow-500 to-orange-500', textColor: 'text-yellow-400' },
                          { label: 'Storage', value: 67, color: 'bg-gradient-to-r from-green-500 to-emerald-500', textColor: 'text-green-400' },
                          { label: 'Network', value: 34, color: 'bg-gradient-to-r from-purple-500 to-pink-500', textColor: 'text-purple-400' }
                        ].map((metric, index) => (
                          <div key={index} className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-white font-medium text-sm">{metric.label}</span>
                              <span className={`font-bold text-sm ${metric.textColor}`}>{metric.value}%</span>
                            </div>
                            <div className="w-full bg-gray-700 rounded-full h-3">
                              <div 
                                className={`h-3 rounded-full ${metric.color} transition-all duration-1000 ease-out shadow-lg`}
                                style={{ width: `${metric.value}%` }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Live Activity Stats */}
                      <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-600/50">
                        <div className="text-center">
                          <div className="flex items-center justify-center space-x-2 mb-2">
                            <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                            <span className="text-sm text-gray-300">Online Agora</span>
                          </div>
                          <p className="text-2xl font-bold text-white">{Math.round(totalUsers * 0.15)}</p>
                        </div>
                        <div className="text-center">
                          <div className="flex items-center justify-center space-x-2 mb-2">
                            <Activity className="w-3 h-3 text-blue-400" />
                            <span className="text-sm text-gray-300">Req/min</span>
                          </div>
                          <p className="text-2xl font-bold text-white">247</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Real-time Trading Dashboard */}
                <Card className="bg-gradient-to-br from-gray-900/95 to-gray-800/95 border-gray-600/50 shadow-2xl backdrop-blur-sm">
                  <CardHeader className="border-b border-gray-600/50 pb-4">
                    <CardTitle className="text-xl font-bold text-white flex items-center">
                      <TrendingUp className="w-6 h-6 mr-3 text-emerald-400" />
                      Trading Analytics
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="h-72">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={[
                          { time: '09:00', wins: 8, losses: 4, profit: 580 },
                          { time: '10:00', wins: 11, losses: 4, profit: 920 },
                          { time: '11:00', wins: 13, losses: 5, profit: 1240 },
                          { time: '12:00', wins: 16, losses: 5, profit: 1680 },
                          { time: '13:00', wins: 19, losses: 5, profit: 2100 },
                          { time: '14:00', wins: 21, losses: 6, profit: 2380 },
                          { time: '15:00', wins: 23, losses: 7, profit: 2590 },
                          { time: '16:00', wins: 25, losses: 8, profit: 2740 },
                          { time: '17:00', wins: 28, losses: 8, profit: 2980 },
                          { time: '18:00', wins: 30, losses: 9, profit: 3180 }
                        ]}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                          <XAxis dataKey="time" stroke="#9CA3AF" fontSize={11} />
                          <YAxis stroke="#9CA3AF" fontSize={11} />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: '#1F2937', 
                              border: '1px solid #374151',
                              borderRadius: '12px',
                              color: '#fff',
                              boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)'
                            }}
                            formatter={(value, name) => [
                              name === 'profit' ? `R$ ${value}` : value,
                              name === 'wins' ? 'Wins' : name === 'losses' ? 'Losses' : 'Profit'
                            ]}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="wins" 
                            stroke="#10B981" 
                            strokeWidth={3}
                            name="wins"
                            dot={{ fill: '#10B981', strokeWidth: 2, r: 5 }}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="losses" 
                            stroke="#EF4444" 
                            strokeWidth={3}
                            name="losses"
                            dot={{ fill: '#EF4444', strokeWidth: 2, r: 5 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4 mt-6 pt-4 border-t border-gray-600/50">
                      <div className="text-center">
                        <div className="flex items-center justify-center space-x-1 mb-1">
                          <TrendingUp className="w-4 h-4 text-emerald-400" />
                          <span className="text-xs text-gray-300 font-medium">Win Rate</span>
                        </div>
                        <p className="text-xl font-bold text-emerald-400">76.9%</p>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center justify-center space-x-1 mb-1">
                          <Target className="w-4 h-4 text-blue-400" />
                          <span className="text-xs text-gray-300 font-medium">Sinais Hoje</span>
                        </div>
                        <p className="text-xl font-bold text-blue-400">39</p>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center justify-center space-x-1 mb-1">
                          <DollarSign className="w-4 h-4 text-purple-400" />
                          <span className="text-xs text-gray-300 font-medium">Profit Total</span>
                        </div>
                        <p className="text-xl font-bold text-purple-400">R$ 3,180</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Executive Content Analytics */}
              <Card className="bg-gradient-to-br from-gray-900/95 to-gray-800/95 border-gray-600/50 shadow-2xl backdrop-blur-sm">
                <CardHeader className="border-b border-gray-600/50 pb-4">
                  <CardTitle className="text-2xl font-bold text-white flex items-center">
                    <Play className="w-7 h-7 mr-3 text-red-400" />
                    Analytics de Conteúdo Executivo
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-8">
                  <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
                    {/* Top Performing Content */}
                    <div className="xl:col-span-2 space-y-6">
                      <h3 className="text-xl font-bold text-white mb-6 flex items-center">
                        <Award className="w-5 h-5 mr-2 text-yellow-400" />
                        Top Performance de Conteúdo
                      </h3>
                      <div className="space-y-4">
                        {[
                          { title: 'Análise Técnica Avançada', views: 1247, engagement: 89, category: 'Educação', trend: '+12%' },
                          { title: 'Estratégias de Day Trade', views: 1156, engagement: 92, category: 'Trading', trend: '+8%' },
                          { title: 'Gestão de Risco Profissional', views: 1089, engagement: 85, category: 'Fundamentos', trend: '+15%' },
                          { title: 'Psicologia do Trader Vencedor', views: 987, engagement: 88, category: 'Mindset', trend: '+5%' },
                          { title: 'Indicadores Técnicos Avançados', views: 876, engagement: 83, category: 'Técnico', trend: '+10%' }
                        ].map((content, index) => (
                          <div key={index} className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-800/50 to-gray-700/30 rounded-xl border border-gray-600/30 hover:border-gray-500/50 transition-all duration-300">
                            <div className="flex items-center space-x-4">
                              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center shadow-lg">
                                <span className="text-white font-bold">#{index + 1}</span>
                              </div>
                              <div>
                                <p className="text-white font-semibold">{content.title}</p>
                                <p className="text-gray-400 text-sm">{content.category}</p>
                              </div>
                            </div>
                            <div className="text-right space-y-1">
                              <div className="flex items-center space-x-3">
                                <div className="text-emerald-400 font-bold">{content.views} views</div>
                                <div className="text-blue-400 text-sm">{content.engagement}% eng.</div>
                                <div className="text-purple-400 text-sm font-medium">{content.trend}</div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Category Distribution */}
                    <div className="space-y-6">
                      <h3 className="text-xl font-bold text-white mb-6 flex items-center">
                        <PieChart className="w-5 h-5 mr-2 text-blue-400" />
                        Distribuição por Categoria
                      </h3>
                      <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                          <RechartsPieChart>
                            <Pie
                              data={[
                                { name: 'Trading', value: 35, fill: '#10B981' },
                                { name: 'Educação', value: 28, fill: '#3B82F6' },
                                { name: 'Análise', value: 22, fill: '#8B5CF6' },
                                { name: 'Mindset', value: 15, fill: '#F59E0B' }
                              ]}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              label={({ name, percent }) => `${name}\n${(percent * 100).toFixed(0)}%`}
                              outerRadius={100}
                              fill="#8884d8"
                              dataKey="value"
                            >
                            </Pie>
                            <Tooltip 
                              contentStyle={{ 
                                backgroundColor: '#1F2937', 
                                border: '1px solid #374151',
                                borderRadius: '12px',
                                color: '#fff'
                              }} 
                            />
                          </RechartsPieChart>
                        </ResponsiveContainer>
                      </div>
                      
                      {/* Engagement Metrics */}
                      <div className="space-y-3">
                        <h4 className="text-lg font-semibold text-white">Métricas de Engajamento</h4>
                        {[
                          { metric: 'Tempo Médio', value: '24min', icon: Timer, color: 'text-blue-400' },
                          { metric: 'Taxa Conclusão', value: '87%', icon: Check, color: 'text-emerald-400' },
                          { metric: 'Avaliação Média', value: '4.8★', icon: Star, color: 'text-yellow-400' },
                          { metric: 'Compartilhamentos', value: '156', icon: Share, color: 'text-purple-400' }
                        ].map((stat, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
                            <div className="flex items-center space-x-2">
                              <stat.icon className={`w-4 h-4 ${stat.color}`} />
                              <span className="text-gray-300 text-sm">{stat.metric}</span>
                            </div>
                            <span className={`font-bold ${stat.color}`}>{stat.value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Activity and KPIs */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Real-time Activity */}
                <Card className="bg-gray-800 border-gray-700 shadow-xl">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center justify-between">
                      <div className="flex items-center">
                        <Activity className="w-5 h-5 mr-2 text-blue-400" />
                        Atividade em Tempo Real
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                        <span className="text-xs text-green-400">ONLINE</span>
                      </div>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3 p-3 bg-green-900/20 rounded-lg border border-green-700">
                        <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                        <div className="flex-1">
                          <p className="text-white text-sm font-medium">{premiumUsers} usuários premium ativos</p>
                          <p className="text-gray-400 text-xs">Via webhook X1-Broker</p>
                        </div>
                        <Crown className="w-4 h-4 text-yellow-400" />
                      </div>
                      <div className="flex items-center space-x-3 p-3 bg-blue-900/20 rounded-lg border border-blue-700">
                        <div className="w-3 h-3 bg-blue-400 rounded-full animate-pulse"></div>
                        <div className="flex-1">
                          <p className="text-white text-sm font-medium">{liveStreamsArray.filter((s: any) => s.isLive).length} lives transmitindo</p>
                          <p className="text-gray-400 text-xs">Sistema de streaming ativo</p>
                        </div>
                        <Radio className="w-4 h-4 text-red-400" />
                      </div>
                      <div className="flex items-center space-x-3 p-3 bg-purple-900/20 rounded-lg border border-purple-700">
                        <div className="w-3 h-3 bg-purple-400 rounded-full"></div>
                        <div className="flex-1">
                          <p className="text-white text-sm font-medium">{videosArray.length} aulas disponíveis</p>
                          <p className="text-gray-400 text-xs">Biblioteca de conteúdo</p>
                        </div>
                        <Play className="w-4 h-4 text-purple-400" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* System Status */}
                <Card className="bg-gray-800 border-gray-700 shadow-xl">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Shield className="w-5 h-5 mr-2 text-green-400" />
                      Status do Sistema
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-3 bg-green-900/20 rounded-lg border border-green-700">
                        <div className="flex items-center space-x-3">
                          <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                          <span className="text-white text-sm">Servidor Principal</span>
                        </div>
                        <span className="text-green-400 text-sm font-bold">99.9%</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-green-900/20 rounded-lg border border-green-700">
                        <div className="flex items-center space-x-3">
                          <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                          <span className="text-white text-sm">Base de Dados</span>
                        </div>
                        <span className="text-green-400 text-sm font-bold">100%</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-green-900/20 rounded-lg border border-green-700">
                        <div className="flex items-center space-x-3">
                          <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                          <span className="text-white text-sm">Webhook X1-Broker</span>
                        </div>
                        <span className="text-green-400 text-sm font-bold">98.5%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Signals Tab */}
            <TabsContent value="signals" className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-bold text-white flex items-center">
                    <TrendingUp className="w-6 h-6 mr-3 text-indigo-400" />
                    Sinais Programados
                  </h3>
                  <p className="text-gray-400 text-sm mt-1">Configure lista de sinais para o robô enviar automaticamente</p>
                </div>
                <div className="flex items-center space-x-4">
                  <Badge className="bg-indigo-600 text-white px-3 py-1">
                    Sistema Automatizado
                  </Badge>
                </div>
              </div>

              {/* Upload/Input Section */}
              <Card className="bg-gradient-to-br from-gray-800 to-gray-900 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Plus className="w-5 h-5 mr-2 text-indigo-400" />
                    Carregar Lista de Sinais
                  </CardTitle>
                  <p className="text-gray-400">Adicione sinais com: paridade, horário, direção (CALL/PUT) e expiração</p>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                    <div>
                      <label className="text-gray-300 text-sm block mb-2">Paridade</label>
                      <Select value={signalForm.asset} onValueChange={(value) => setSignalForm(prev => ({ ...prev, asset: value }))}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue placeholder="Selecionar" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="EUR/USD">EUR/USD</SelectItem>
                          <SelectItem value="GBP/USD">GBP/USD</SelectItem>
                          <SelectItem value="USD/JPY">USD/JPY</SelectItem>
                          <SelectItem value="AUD/USD">AUD/USD</SelectItem>
                          <SelectItem value="USD/CAD">USD/CAD</SelectItem>
                          <SelectItem value="USD/CHF">USD/CHF</SelectItem>
                          <SelectItem value="NZD/USD">NZD/USD</SelectItem>
                          <SelectItem value="EUR/GBP">EUR/GBP</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label className="text-gray-300 text-sm block mb-2">Horário</label>
                      <Input
                        type="time"
                        value={signalForm.time}
                        onChange={(e) => setSignalForm(prev => ({ ...prev, time: e.target.value }))}
                        className="bg-gray-700 border-gray-600 text-white"
                        placeholder="14:30"
                      />
                    </div>
                    
                    <div>
                      <label className="text-gray-300 text-sm block mb-2">Direção</label>
                      <Select value={signalForm.direction} onValueChange={(value) => setSignalForm(prev => ({ ...prev, direction: value }))}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue placeholder="Selecionar" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="CALL">
                            <span className="text-green-400">CALL ↗</span>
                          </SelectItem>
                          <SelectItem value="PUT">
                            <span className="text-red-400">PUT ↘</span>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label className="text-gray-300 text-sm block mb-2">Expiração (min)</label>
                      <Select value={signalForm.expiration} onValueChange={(value) => setSignalForm(prev => ({ ...prev, expiration: value }))}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue placeholder="1 min" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 minuto</SelectItem>
                          <SelectItem value="5">5 minutos</SelectItem>
                          <SelectItem value="15">15 minutos</SelectItem>
                          <SelectItem value="30">30 minutos</SelectItem>
                          <SelectItem value="60">1 hora</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="flex space-x-4">
                    <Button 
                      className="bg-indigo-600 hover:bg-indigo-700 flex-1"
                      onClick={handleAddSignal}
                      disabled={addScheduledSignal.isPending}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      {addScheduledSignal.isPending ? "Adicionando..." : "Adicionar Sinal"}
                    </Button>
                    <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700">
                      <Download className="w-4 h-4 mr-2" />
                      Importar CSV
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Signals List */}
              <Card className="bg-gradient-to-br from-gray-800 to-gray-900 border-gray-700">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center">
                      <TrendingUp className="w-5 h-5 mr-2 text-indigo-400" />
                      Lista de Sinais ({scheduledSignals.length})
                    </CardTitle>
                    <div className="flex space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
                        onClick={handleClearAllSignals}
                        disabled={clearAllSignals.isPending}
                      >
                        {clearAllSignals.isPending ? "Limpando..." : "Limpar Todos"}
                      </Button>
                      <Button size="sm" className="bg-green-600 hover:bg-green-700">
                        Ativar Robô
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {scheduledSignals.length === 0 ? (
                    <div className="text-center py-12">
                      <div className="w-20 h-20 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                        <TrendingUp className="w-10 h-10 text-gray-400" />
                      </div>
                      <p className="text-gray-400 text-xl mb-2">Nenhum sinal programado</p>
                      <p className="text-gray-500">Adicione sinais para o robô enviar automaticamente nos horários definidos</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {scheduledSignals.map((signal, index) => (
                        <div key={signal.id} className="bg-gray-700 p-4 rounded-lg flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                              {index + 1}
                            </div>
                            <div>
                              <div className="text-white font-medium">{signal.asset}</div>
                              <div className="text-gray-400 text-sm">{signal.time} • {signal.expiration} min</div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3">
                            <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                              signal.direction === 'CALL' 
                                ? 'bg-green-600 text-white' 
                                : 'bg-red-600 text-white'
                            }`}>
                              {signal.direction} {signal.direction === 'CALL' ? '↗' : '↘'}
                            </div>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
                            >
                              Remover
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Settings */}
              <Card className="bg-gradient-to-br from-gray-800 to-gray-900 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Settings className="w-5 h-5 mr-2 text-orange-400" />
                    Configurações do Sistema
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-white font-medium">Usar Sinais Programados</p>
                          <p className="text-gray-400 text-sm">Robô enviará apenas os sinais da lista ao invés de gerar automaticamente</p>
                        </div>
                        <Switch 
                          checked={useScheduledSignals}
                          onCheckedChange={(checked) => {
                            setUseScheduledSignals(checked);
                            updateRobotConfig.mutate({ useScheduledSignals: checked, repeatList });
                          }}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-white font-medium">Repetir Lista</p>
                          <p className="text-gray-400 text-sm">Reiniciar automaticamente a lista quando terminar</p>
                        </div>
                        <Switch 
                          checked={repeatList}
                          onCheckedChange={(checked) => {
                            setRepeatList(checked);
                            updateRobotConfig.mutate({ useScheduledSignals, repeatList: checked });
                          }}
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="bg-gray-700 p-4 rounded-lg">
                        <h4 className="text-white font-medium mb-2">Status do Sistema</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Modo:</span>
                            <span className="text-yellow-400">
                              {useScheduledSignals ? "Sinais Programados" : "Geração Automática"}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Sinais Programados:</span>
                            <span className="text-gray-300">{scheduledSignals.length}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Próximo Sinal:</span>
                            <span className="text-gray-300">
                              {scheduledSignals.length > 0 ? scheduledSignals[0].time : "--:--"}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Users Tab */}
            <TabsContent value="users" className="space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-2xl font-bold text-white flex items-center">
                    <Users className="w-6 h-6 mr-3 text-blue-400" />
                    Gerenciamento de Usuários
                  </h3>
                  <p className="text-gray-400 text-sm mt-1">Controle completo sobre contas e status premium</p>
                </div>
                <div className="flex items-center space-x-4">
                  <Input
                    placeholder="🔍 Buscar por nome ou email..."
                    className="w-64 bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                  />
                  <Badge className="bg-blue-600 text-white px-3 py-1">
                    {totalUsers} Total
                  </Badge>
                </div>
              </div>

              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-gradient-to-r from-green-900/50 to-green-800/50 border-green-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-green-200 text-sm font-medium">Usuários Premium</p>
                        <p className="text-2xl font-bold text-white">{premiumUsers}</p>
                      </div>
                      <Crown className="w-8 h-8 text-green-400" />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gradient-to-r from-gray-900/50 to-gray-800/50 border-gray-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-200 text-sm font-medium">Usuários Gratuitos</p>
                        <p className="text-2xl font-bold text-white">{freeUsers}</p>
                      </div>
                      <Users className="w-8 h-8 text-gray-400" />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gradient-to-r from-blue-900/50 to-blue-800/50 border-blue-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-blue-200 text-sm font-medium">Taxa Conversão</p>
                        <p className="text-2xl font-bold text-white">{totalUsers > 0 ? ((premiumUsers / totalUsers) * 100).toFixed(1) : 0}%</p>
                      </div>
                      <TrendingUp className="w-8 h-8 text-blue-400" />
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Users Table */}
              <Card className="bg-gray-800 border-gray-700 shadow-xl">
                <CardHeader className="pb-4">
                  <CardTitle className="text-white flex items-center justify-between">
                    <span>Lista de Usuários</span>
                    <Badge variant="outline" className="text-gray-300">
                      Últimos {usersArray.length} registros
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-gray-700 hover:bg-gray-800/50">
                          <TableHead className="text-gray-300 font-semibold">ID</TableHead>
                          <TableHead className="text-gray-300 font-semibold">Nome</TableHead>
                          <TableHead className="text-gray-300 font-semibold">Email</TableHead>
                          <TableHead className="text-gray-300 font-semibold">Status Premium</TableHead>
                          <TableHead className="text-gray-300 font-semibold">Registro</TableHead>
                          <TableHead className="text-gray-300 font-semibold text-center">Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {usersArray.map((user: any) => (
                          <TableRow key={user.id} className="border-gray-700 hover:bg-gray-800/30 transition-colors">
                            <TableCell className="text-gray-400 font-mono text-sm">
                              #{user.id}
                            </TableCell>
                            <TableCell className="text-white font-medium">
                              <div className="flex items-center space-x-2">
                                <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                                  <span className="text-white text-xs font-bold">
                                    {user.name.charAt(0).toUpperCase()}
                                  </span>
                                </div>
                                <span>{user.name}</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-gray-300 font-mono text-sm">
                              {user.email}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center space-x-3">
                                <Badge className={user.isPremium ? 
                                  "bg-gradient-to-r from-green-600 to-green-700 text-white shadow-lg" : 
                                  "bg-gradient-to-r from-gray-600 to-gray-700 text-white"
                                }>
                                  {user.isPremium ? (
                                    <>
                                      <Crown className="w-3 h-3 mr-1" />
                                      Premium
                                    </>
                                  ) : (
                                    <>
                                      <Users className="w-3 h-3 mr-1" />
                                      Gratuito
                                    </>
                                  )}
                                </Badge>
                                
                                {/* Toggle Premium Switch */}
                                <div className="flex items-center space-x-2">
                                  <Switch
                                    checked={user.isPremium}
                                    onCheckedChange={(checked) => toggleUserPremium(user.id, checked)}
                                    disabled={toggleUserPremiumMutation.isPending}
                                    className="data-[state=checked]:bg-green-600"
                                  />
                                  <span className="text-xs text-gray-400">
                                    {user.isPremium ? 'Premium' : 'Ativar'}
                                  </span>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell className="text-gray-400 text-sm">
                              <div className="flex flex-col">
                                <span>{new Date(user.createdAt).toLocaleDateString('pt-BR')}</span>
                                <span className="text-xs text-gray-500">
                                  {new Date(user.createdAt).toLocaleTimeString('pt-BR', { 
                                    hour: '2-digit', 
                                    minute: '2-digit' 
                                  })}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell className="text-center">
                              <Button
                                size="sm"
                                variant="outline"
                                className="h-8 px-3 text-xs border-blue-600 text-blue-400 hover:bg-blue-600 hover:text-white"
                                onClick={() => {/* Future: Edit user functionality */}}
                              >
                                <Edit className="w-3 h-3 mr-1" />
                                Editar
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  
                  {usersArray.length === 0 && (
                    <div className="text-center py-12 text-gray-400">
                      <Users className="w-16 h-16 mx-auto mb-4 opacity-30" />
                      <p className="text-lg mb-2">Nenhum usuário encontrado</p>
                      <p className="text-sm">Os usuários aparecerão aqui conforme se registram na plataforma.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Content Tab */}
            <TabsContent value="content" className="space-y-6">
              <h3 className="text-xl font-semibold text-white">Gerenciar Conteúdo</h3>
              
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Adicionar Nova Aula</CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...videoForm}>
                    <form onSubmit={videoForm.handleSubmit(onVideoSubmit)} className="space-y-6">
                      {/* Informações Básicas */}
                      <div className="space-y-4">
                        <h4 className="text-lg font-semibold text-white border-b border-gray-600 pb-2">📚 Informações Básicas</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={videoForm.control}
                            name="title"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-white">Título da Aula</FormLabel>
                                <FormControl>
                                  <Input {...field} placeholder="Ex: Análise Técnica Avançada" className="bg-gray-700 border-gray-600 text-white" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={videoForm.control}
                            name="instructor"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-white">Instrutor</FormLabel>
                                <FormControl>
                                  <Input {...field} placeholder="Ex: Prof. João Silva" className="bg-gray-700 border-gray-600 text-white" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={videoForm.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">Descrição Detalhada</FormLabel>
                              <FormControl>
                                <Textarea 
                                  {...field} 
                                  placeholder="Descreva o conteúdo da aula, objetivos de aprendizado e o que o aluno irá aprender..."
                                  className="bg-gray-700 border-gray-600 text-white min-h-[100px]" 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      {/* Categorização e Nível */}
                      <div className="space-y-4">
                        <h4 className="text-lg font-semibold text-white border-b border-gray-600 pb-2">🎯 Categorização</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <FormField
                            control={videoForm.control}
                            name="category"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-white">Categoria</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                                      <SelectValue placeholder="Selecione uma categoria" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent className="bg-gray-700 border-gray-600">
                                    <SelectItem value="Educação">📚 Educação</SelectItem>
                                    <SelectItem value="Trading">📈 Trading</SelectItem>
                                    <SelectItem value="Análise">🔍 Análise Técnica</SelectItem>
                                    <SelectItem value="Mindset">🧠 Mindset</SelectItem>
                                    <SelectItem value="Fundamentos">⚖️ Fundamentos</SelectItem>
                                    <SelectItem value="Estratégias">🎯 Estratégias</SelectItem>
                                    <SelectItem value="Gestão">💰 Gestão de Risco</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={videoForm.control}
                            name="level"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-white">Nível de Dificuldade</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                                      <SelectValue placeholder="Selecione o nível" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent className="bg-gray-700 border-gray-600">
                                    <SelectItem value="básico">🟢 Básico</SelectItem>
                                    <SelectItem value="intermediário">🟡 Intermediário</SelectItem>
                                    <SelectItem value="avançado">🔴 Avançado</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={videoForm.control}
                            name="language"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-white">Idioma</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                                      <SelectValue placeholder="Selecione o idioma" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent className="bg-gray-700 border-gray-600">
                                    <SelectItem value="pt-BR">🇧🇷 Português (Brasil)</SelectItem>
                                    <SelectItem value="en-US">🇺🇸 Inglês</SelectItem>
                                    <SelectItem value="es-ES">🇪🇸 Espanhol</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={videoForm.control}
                          name="tags"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">Tags (separadas por vírgula)</FormLabel>
                              <FormControl>
                                <Input 
                                  {...field} 
                                  placeholder="Ex: day trade, swing trade, análise gráfica, candlestick, suporte e resistência"
                                  className="bg-gray-700 border-gray-600 text-white" 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      {/* Conteúdo de Mídia */}
                      <div className="space-y-4">
                        <h4 className="text-lg font-semibold text-white border-b border-gray-600 pb-2">🎥 Conteúdo de Mídia</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={videoForm.control}
                            name="videoUrl"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-white">URL do Vídeo</FormLabel>
                                <FormControl>
                                  <Input 
                                    {...field} 
                                    placeholder="https://youtube.com/watch?v=... ou Vimeo, etc."
                                    className="bg-gray-700 border-gray-600 text-white" 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={videoForm.control}
                            name="thumbnailUrl"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-white">URL da Thumbnail</FormLabel>
                                <FormControl>
                                  <Input 
                                    {...field} 
                                    placeholder="https://example.com/thumbnail.jpg"
                                    className="bg-gray-700 border-gray-600 text-white" 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      {/* Configurações Avançadas */}
                      <div className="space-y-4">
                        <h4 className="text-lg font-semibold text-white border-b border-gray-600 pb-2">⚙️ Configurações Avançadas</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-4">
                            <FormField
                              control={videoForm.control}
                              name="isPremium"
                              render={({ field }) => (
                                <FormItem className="flex items-center justify-between p-4 bg-yellow-900/20 rounded-lg border border-yellow-600/30">
                                  <div className="space-y-1">
                                    <FormLabel className="text-white font-medium">Conteúdo Premium</FormLabel>
                                    <p className="text-sm text-gray-300">Disponível apenas para usuários premium</p>
                                  </div>
                                  <FormControl>
                                    <Switch checked={field.value} onCheckedChange={field.onChange} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />

                            <FormField
                              control={videoForm.control}
                              name="isFeatured"
                              render={({ field }) => (
                                <FormItem className="flex items-center justify-between p-4 bg-purple-900/20 rounded-lg border border-purple-600/30">
                                  <div className="space-y-1">
                                    <FormLabel className="text-white font-medium">Aula em Destaque</FormLabel>
                                    <p className="text-sm text-gray-300">Aparecerá na página inicial</p>
                                  </div>
                                  <FormControl>
                                    <Switch checked={field.value} onCheckedChange={field.onChange} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>

                          <div className="space-y-4">
                            <div className="p-4 bg-blue-900/20 rounded-lg border border-blue-600/30">
                              <h5 className="text-white font-medium mb-2 flex items-center">
                                <Eye className="w-4 h-4 mr-2" />
                                Estatísticas de Visualização
                              </h5>
                              <p className="text-sm text-gray-300">Após criada, a aula terá:</p>
                              <ul className="text-xs text-gray-400 mt-2 space-y-1">
                                <li>• Contador de visualizações automático</li>
                                <li>• Sistema de progresso por usuário</li>
                                <li>• Analytics de engajamento</li>
                                <li>• Avaliações e comentários</li>
                              </ul>
                            </div>

                            <div className="p-4 bg-green-900/20 rounded-lg border border-green-600/30">
                              <h5 className="text-white font-medium mb-2 flex items-center">
                                <Star className="w-4 h-4 mr-2" />
                                Sistema de Qualidade
                              </h5>
                              <p className="text-sm text-gray-300">Recursos automáticos:</p>
                              <ul className="text-xs text-gray-400 mt-2 space-y-1">
                                <li>• Avaliação por estrelas (1-5)</li>
                                <li>• Detecção automática de duração</li>
                                <li>• Ordenação inteligente</li>
                                <li>• Recomendações personalizadas</li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>

                      <Button 
                        type="submit" 
                        disabled={createVideoMutation.isPending}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        {createVideoMutation.isPending ? "Criando..." : "Adicionar Aula"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Aulas Tab */}
            <TabsContent value="aulas" className="space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-2xl font-bold text-white flex items-center">
                    <Video className="w-6 h-6 mr-3 text-indigo-400" />
                    Gerenciar Aulas
                  </h3>
                  <p className="text-gray-400 text-sm mt-1">Edite e gerencie todas as aulas da plataforma</p>
                </div>
                <div className="flex items-center space-x-4">
                  <Badge className="bg-indigo-600 text-white px-3 py-1">
                    {videosArray.length} Aulas
                  </Badge>
                </div>
              </div>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Todas as Aulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {videosArray.length === 0 ? (
                      <div className="text-center py-8 text-gray-400">
                        <Video className="w-16 h-16 mx-auto mb-4 opacity-30" />
                        <p>Nenhuma aula encontrada</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 gap-4">
                        {videosArray.map((video: any) => (
                          <Card key={video.id} className="bg-gray-700 border-gray-600">
                            <CardContent className="p-4">
                              <div className="flex items-start justify-between">
                                <div className="flex-1">
                                  <div className="flex items-center space-x-3 mb-2">
                                    <div className="w-10 h-10 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg flex items-center justify-center">
                                      <Video className="w-5 h-5 text-white" />
                                    </div>
                                    <div>
                                      <h4 className="text-white font-semibold">{video.title}</h4>
                                      <p className="text-gray-400 text-sm">{video.category}</p>
                                    </div>
                                  </div>
                                  <div className="flex items-center space-x-4 text-sm text-gray-400">
                                    <span>{video.level || 'Básico'}</span>
                                    <span>•</span>
                                    <span>{video.instructor || 'Instrutor'}</span>
                                    <span>•</span>
                                    <span>{video.isPremium ? 'Premium' : 'Gratuito'}</span>
                                    <span>•</span>
                                    <span>{video.viewCount || 0} visualizações</span>
                                  </div>
                                  <p className="text-gray-300 text-sm mt-2">{video.description}</p>
                                </div>
                                <div className="flex items-center space-x-2 ml-4">
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="bg-blue-600 hover:bg-blue-700 text-white border-blue-600"
                                    onClick={() => {
                                      // TODO: Implementar edição
                                      toast({ title: "Edição será implementada em breve" });
                                    }}
                                  >
                                    <Edit className="w-4 h-4 mr-1" />
                                    Editar
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="bg-red-600 hover:bg-red-700 text-white border-red-600"
                                    onClick={() => {
                                      if (confirm('Tem certeza que deseja deletar esta aula?')) {
                                        deleteVideoMutation.mutate(video.id);
                                      }
                                    }}
                                    disabled={deleteVideoMutation.isPending}
                                  >
                                    <Trash2 className="w-4 h-4 mr-1" />
                                    Deletar
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Lives Tab */}
            <TabsContent value="lives" className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold text-white">Gerenciar Lives</h3>
                <Badge className="bg-red-600 text-white">
                  🔴 {liveStreamsArray.filter((s: any) => s.isLive).length} Ao Vivo
                </Badge>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Create Live Form */}
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Radio className="w-5 h-5 mr-2 text-red-400" />
                      Criar Nova Live
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Form {...liveStreamForm}>
                      <form onSubmit={liveStreamForm.handleSubmit(onLiveStreamSubmit)} className="space-y-4">
                        <FormField
                          control={liveStreamForm.control}
                          name="title"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">Título</FormLabel>
                              <FormControl>
                                <Input {...field} className="bg-gray-700 border-gray-600 text-white" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={liveStreamForm.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">Descrição</FormLabel>
                              <FormControl>
                                <Textarea {...field} className="bg-gray-700 border-gray-600 text-white" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={liveStreamForm.control}
                          name="platform"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">Plataforma</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                                    <SelectValue />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="youtube">YouTube Live</SelectItem>
                                  <SelectItem value="meet">Google Meet</SelectItem>
                                  <SelectItem value="jitsi">Jitsi Meet</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={liveStreamForm.control}
                          name="streamUrl"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">URL/Sala</FormLabel>
                              <FormControl>
                                <Input {...field} className="bg-gray-700 border-gray-600 text-white" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={liveStreamForm.control}
                            name="isLive"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2">
                                <FormControl>
                                  <Switch checked={field.value} onCheckedChange={field.onChange} />
                                </FormControl>
                                <FormLabel className="text-white">🔴 Ao Vivo</FormLabel>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={liveStreamForm.control}
                            name="isPremium"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2">
                                <FormControl>
                                  <Switch checked={field.value} onCheckedChange={field.onChange} />
                                </FormControl>
                                <FormLabel className="text-white">Premium</FormLabel>
                              </FormItem>
                            )}
                          />
                        </div>

                        <Button
                          type="submit"
                          disabled={createLiveStreamMutation.isPending}
                          className="w-full bg-red-600 hover:bg-red-700 text-white"
                        >
                          {createLiveStreamMutation.isPending ? "Criando..." : "🚀 Criar Live"}
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>

                {/* Lives List */}
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Eye className="w-5 h-5 mr-2 text-blue-400" />
                      Lives Existentes
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4 max-h-96 overflow-y-auto">
                      {liveStreamsArray.length > 0 ? (
                        liveStreamsArray.map((stream: any) => (
                          <div key={stream.id} className="bg-gray-700/50 p-4 rounded-lg border border-gray-600">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <div className="flex items-center space-x-3 mb-2">
                                  <h4 className="text-white font-medium">{stream.title}</h4>
                                  <Badge 
                                    className={stream.isLive ? "bg-red-600 text-white animate-pulse" : "bg-gray-600"}
                                  >
                                    {stream.isLive ? "🔴 AO VIVO" : "📅 AGENDADA"}
                                  </Badge>
                                </div>
                                <p className="text-gray-400 text-sm mb-2">{stream.description}</p>
                                <div className="flex items-center space-x-2">
                                  <Badge variant="outline" className="text-xs">
                                    {stream.platform === 'youtube' ? '📺 YouTube' : 
                                     stream.platform === 'meet' ? '💻 Meet' : 
                                     '🎥 Jitsi'}
                                  </Badge>
                                  {stream.isPremium && (
                                    <Badge variant="outline" className="text-xs text-yellow-400">
                                      👑 PREMIUM
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              <div className="flex flex-col space-y-2 ml-4">
                                <Button
                                  size="sm"
                                  variant={stream.isLive ? "destructive" : "default"}
                                  onClick={() => toggleLiveStatus(stream.id, !stream.isLive)}
                                  className="text-xs"
                                  disabled={toggleLiveStatusMutation.isPending}
                                >
                                  {stream.isLive ? "⏹️ PARAR" : "▶️ ATIVAR"}
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => deleteLiveStream(stream.id)}
                                  className="text-xs"
                                  disabled={deleteLiveStreamMutation.isPending}
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-12 text-gray-400">
                          <Radio className="w-16 h-16 mx-auto mb-4 opacity-30" />
                          <p>Nenhuma live criada ainda</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Analytics Tab */}
            <TabsContent value="analytics" className="space-y-6">
              <h3 className="text-xl font-semibold text-white">Analytics Avançado</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  { title: "Estratégias de Day Trade", views: "1.2k", rating: 4.8, category: "Trading" },
                  { title: "Análise Técnica", views: "980", rating: 4.9, category: "Análise" },
                  { title: "Psicologia do Trader", views: "856", rating: 4.7, category: "Psicologia" },
                  { title: "Gestão de Risco", views: "743", rating: 4.6, category: "Gestão" },
                  { title: "Robô de Trading", views: "634", rating: 4.5, category: "Automação" },
                  { title: "Fibonacci", views: "512", rating: 4.8, category: "Análise" }
                ].map((content, index) => (
                  <Card key={index} className="bg-gray-700/50 border-gray-600">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
                          <span className="text-white font-bold text-sm">{index + 1}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Star className="w-4 h-4 text-yellow-400 fill-current" />
                          <span className="text-white text-sm font-bold">{content.rating}</span>
                        </div>
                      </div>
                      <h4 className="text-white font-medium mb-2 text-sm">{content.title}</h4>
                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Views:</span>
                          <span className="text-white">{content.views}</span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {content.category}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>


            {/* Settings Tab */}
            <TabsContent value="settings" className="space-y-6">
              <h3 className="text-xl font-semibold text-white">Configurações do Sistema</h3>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Configurações da Plataforma</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="text-white text-sm">Nome da Plataforma</label>
                      <Input defaultValue="Investidor Academy Pro" className="bg-gray-700 border-gray-600 text-white mt-1" />
                    </div>
                    <div>
                      <label className="text-white text-sm">URL do Site</label>
                      <Input defaultValue="https://investidoracademy.com" className="bg-gray-700 border-gray-600 text-white mt-1" />
                    </div>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700">Salvar Configurações</Button>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Zap className="w-5 h-5 mr-2 text-yellow-400" />
                      Webhook X1-Broker
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="text-white text-sm">Endpoint URL</label>
                      <Input 
                        defaultValue="https://investidoracademy.replit.app/webhook/registration" 
                        className="bg-gray-700 border-gray-600 text-white mt-1" 
                        readOnly 
                      />
                    </div>
                    <div className="flex items-center justify-between p-3 bg-green-900/20 rounded-lg border border-green-700">
                      <span className="text-green-400 text-sm">Status: Conectado</span>
                      <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                    </div>
                    <Button className="w-full bg-yellow-600 hover:bg-yellow-700">Testar Webhook</Button>
                  </CardContent>
                </Card>
              </div>

              {/* Dashboard Configuration */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Settings className="w-5 h-5 mr-2 text-blue-400" />
                    Configurações da Aba Início
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Card 1 - Operações Hoje */}
                    <div className="space-y-3">
                      <h4 className="text-white font-medium">Card 1 - Operações Hoje</h4>
                      <div className="space-y-2">
                        <div>
                          <label className="text-gray-400 text-sm">Título</label>
                          <Input
                            value={dashboardData.card1.title}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card1: { ...prev.card1, title: e.target.value }
                            }))}
                            className="bg-gray-700 border-gray-600 text-white mt-1"
                          />
                        </div>
                        <div>
                          <label className="text-gray-400 text-sm">Valor</label>
                          <Input
                            value={dashboardData.card1.value}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card1: { ...prev.card1, value: e.target.value }
                            }))}
                            className="bg-gray-700 border-gray-600 text-white mt-1"
                          />
                        </div>
                        <div>
                          <label className="text-gray-400 text-sm">Subtítulo</label>
                          <Input
                            value={dashboardData.card1.subtitle}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card1: { ...prev.card1, subtitle: e.target.value }
                            }))}
                            className="bg-gray-700 border-gray-600 text-white mt-1"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Card 2 - Taxa de Acerto */}
                    <div className="space-y-3">
                      <h4 className="text-white font-medium">Card 2 - Taxa de Acerto</h4>
                      <div className="space-y-2">
                        <div>
                          <label className="text-gray-400 text-sm">Título</label>
                          <Input
                            value={dashboardData.card2.title}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card2: { ...prev.card2, title: e.target.value }
                            }))}
                            className="bg-gray-700 border-gray-600 text-white mt-1"
                          />
                        </div>
                        <div>
                          <label className="text-gray-400 text-sm">Valor</label>
                          <Input
                            value={dashboardData.card2.value}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card2: { ...prev.card2, value: e.target.value }
                            }))}
                            className="bg-gray-700 border-gray-600 text-white mt-1"
                          />
                        </div>
                        <div>
                          <label className="text-gray-400 text-sm">Subtítulo</label>
                          <Input
                            value={dashboardData.card2.subtitle}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card2: { ...prev.card2, subtitle: e.target.value }
                            }))}
                            className="bg-gray-700 border-gray-600 text-white mt-1"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Card 3 - Resultado Hoje */}
                    <div className="space-y-3">
                      <h4 className="text-white font-medium">Card 3 - Resultado Hoje</h4>
                      <div className="space-y-2">
                        <div>
                          <label className="text-gray-400 text-sm">Título</label>
                          <Input
                            value={dashboardData.card3.title}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card3: { ...prev.card3, title: e.target.value }
                            }))}
                            className="bg-gray-700 border-gray-600 text-white mt-1"
                          />
                        </div>
                        <div>
                          <label className="text-gray-400 text-sm">Valor</label>
                          <Input
                            value={dashboardData.card3.value}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card3: { ...prev.card3, value: e.target.value }
                            }))}
                            className="bg-gray-700 border-gray-600 text-white mt-1"
                          />
                        </div>
                        <div>
                          <label className="text-gray-400 text-sm">Subtítulo</label>
                          <Input
                            value={dashboardData.card3.subtitle}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card3: { ...prev.card3, subtitle: e.target.value }
                            }))}
                            className="bg-gray-700 border-gray-600 text-white mt-1"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Card 4 - Próxima Live */}
                    <div className="space-y-3">
                      <h4 className="text-white font-medium">Card 4 - Próxima Live</h4>
                      <div className="space-y-2">
                        <div>
                          <label className="text-gray-400 text-sm">Título</label>
                          <Input
                            value={dashboardData.card4.title}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card4: { ...prev.card4, title: e.target.value }
                            }))}
                            className="bg-gray-700 border-gray-600 text-white mt-1"
                          />
                        </div>
                        <div>
                          <label className="text-gray-400 text-sm">Valor</label>
                          <Input
                            value={dashboardData.card4.value}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card4: { ...prev.card4, value: e.target.value }
                            }))}
                            className="bg-gray-700 border-gray-600 text-white mt-1"
                          />
                        </div>
                        <div>
                          <label className="text-gray-400 text-sm">Subtítulo</label>
                          <Input
                            value={dashboardData.card4.subtitle}
                            onChange={(e) => setDashboardData(prev => ({
                              ...prev,
                              card4: { ...prev.card4, subtitle: e.target.value }
                            }))}
                            className="bg-gray-700 border-gray-600 text-white mt-1"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center pt-4 border-t border-gray-700">
                    <div className="text-sm text-gray-400">
                      As alterações são aplicadas em tempo real no dashboard
                    </div>
                    <Button 
                      className="bg-green-600 hover:bg-green-700"
                      onClick={() => saveDashboardConfig.mutate(dashboardData)}
                      disabled={saveDashboardConfig.isPending}
                    >
                      <Save className="w-4 h-4 mr-2" />
                      {saveDashboardConfig.isPending ? "Salvando..." : "Salvar Configurações"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}