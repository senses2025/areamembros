import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { ArrowUp, ArrowDown, Target, DollarSign, TrendingUp, BarChart3, Activity, Trophy, User, Award, Zap, Star } from "lucide-react";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell, BarChart, Bar } from 'recharts';
import { format, subDays, isToday } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useState } from "react";

const tradingLogSchema = z.object({
  type: z.enum(["WIN", "LOSS"]),
  amount: z.string().min(1, "Valor é obrigatório"),
  asset: z.string().min(1, "Ativo é obrigatório"),
  time: z.string().min(1, "Horário é obrigatório"),
  notes: z.string().optional(),
});

export default function Management() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("overview");

  const { data: dailyStats } = useQuery({
    queryKey: ["/api/trading-stats/daily"],
  });

  const { data: tradingLogs } = useQuery({
    queryKey: ["/api/trading-logs"],
  });

  const form = useForm<z.infer<typeof tradingLogSchema>>({
    resolver: zodResolver(tradingLogSchema),
    defaultValues: {
      type: "WIN",
      amount: "",
      asset: "",
      time: "",
      notes: "",
    },
  });

  const createLogMutation = useMutation({
    mutationFn: async (data: z.infer<typeof tradingLogSchema>) => {
      const logData = {
        ...data,
        amount: parseFloat(data.amount),
        time: new Date(`${new Date().toDateString()} ${data.time}`),
      };
      const response = await apiRequest("POST", "/api/trading-logs", logData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Operação registrada",
        description: "Sua operação foi registrada com sucesso.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/trading-logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/trading-stats/daily"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: z.infer<typeof tradingLogSchema>) => {
    createLogMutation.mutate(data);
  };

  // Processar dados para gráficos
  const processedTradingLogs = Array.isArray(tradingLogs) ? tradingLogs : [];
  
  // Dados para gráfico de performance dos últimos 7 dias
  const performanceData = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(new Date(), 6 - i);
    const dayLogs = processedTradingLogs.filter((log: any) => {
      const logDate = new Date(log.time);
      return logDate.toDateString() === date.toDateString();
    });
    
    const wins = dayLogs.filter((log: any) => log.type === 'WIN').length;
    const losses = dayLogs.filter((log: any) => log.type === 'LOSS').length;
    const total = wins + losses;
    const winRate = total > 0 ? Math.round((wins / total) * 100) : 0;
    const profit = dayLogs.reduce((sum: number, log: any) => {
      return sum + (log.type === 'WIN' ? parseFloat(log.amount) : -parseFloat(log.amount));
    }, 0);

    return {
      date: format(date, 'dd/MM', { locale: ptBR }),
      wins,
      losses,
      total,
      winRate,
      profit: parseFloat(profit.toFixed(2))
    };
  });

  // Dados para gráfico de pizza dos ativos
  const assetStats = processedTradingLogs.reduce((acc: any, log: any) => {
    const asset = log.asset || 'Desconhecido';
    if (!acc[asset]) {
      acc[asset] = { name: asset, value: 0, wins: 0, losses: 0 };
    }
    acc[asset].value += 1;
    if (log.type === 'WIN') acc[asset].wins += 1;
    else acc[asset].losses += 1;
    return acc;
  }, {});

  const pieData = Object.values(assetStats);
  const COLORS = ['#10B981', '#3B82F6', '#8B5CF6', '#F59E0B', '#EF4444', '#06B6D4'];

  // Estatísticas avançadas
  const totalOperations = processedTradingLogs.length;
  const totalWins = processedTradingLogs.filter((log: any) => log.type === 'WIN').length;
  const totalLosses = processedTradingLogs.filter((log: any) => log.type === 'LOSS').length;
  const overallWinRate = totalOperations > 0 ? Math.round((totalWins / totalOperations) * 100) : 0;
  const totalProfit = processedTradingLogs.reduce((sum: number, log: any) => {
    return sum + (log.type === 'WIN' ? parseFloat(log.amount) : -parseFloat(log.amount));
  }, 0);

  const bestDay = performanceData.reduce((best, day) => 
    day.profit > best.profit ? day : best, performanceData[0] || { profit: 0, date: 'N/A' });

  function calculateCurrentStreak(logs: any[]) {
    if (logs.length === 0) return 0;
    const sortedLogs = [...logs].sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime());
    let streak = 0;
    const firstType = sortedLogs[0]?.type;
    
    for (const log of sortedLogs) {
      if (log.type === firstType) {
        streak++;
      } else {
        break;
      }
    }
    return streak;
  }

  function calculateMaxStreak(logs: any[]) {
    if (logs.length === 0) return 0;
    const sortedLogs = [...logs].sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());
    let maxStreak = 0;
    let currentStreak = 0;
    let lastType = null;
    
    for (const log of sortedLogs) {
      if (log.type === lastType) {
        currentStreak++;
      } else {
        maxStreak = Math.max(maxStreak, currentStreak);
        currentStreak = 1;
        lastType = log.type;
      }
    }
    return Math.max(maxStreak, currentStreak);
  }

  const currentStreak = calculateCurrentStreak(processedTradingLogs);
  const maxStreak = calculateMaxStreak(processedTradingLogs);

  return (
    <div className="space-y-6">
      {/* Header Professional */}
      <div className="bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 rounded-2xl p-6 border border-gray-700">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Painel de Controle</h1>
            <p className="text-gray-300">Gerencie suas operações e acompanhe sua performance</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="bg-green-500/20 p-3 rounded-full">
              <User className="w-6 h-6 text-green-400" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Trader Ativo</p>
              <p className="text-lg font-semibold text-white">{totalOperations} operações</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-muted border border-border">
          <TabsTrigger value="overview" className="data-[state=active]:bg-navy-blue data-[state=active]:text-white">
            <BarChart3 className="w-4 h-4 mr-2" />
            Visão Geral
          </TabsTrigger>
          <TabsTrigger value="analytics" className="data-[state=active]:bg-navy-blue data-[state=active]:text-white">
            <Activity className="w-4 h-4 mr-2" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="operations" className="data-[state=active]:bg-navy-blue data-[state=active]:text-white">
            <TrendingUp className="w-4 h-4 mr-2" />
            Operações
          </TabsTrigger>
          <TabsTrigger value="performance" className="data-[state=active]:bg-navy-blue data-[state=active]:text-white">
            <Trophy className="w-4 h-4 mr-2" />
            Performance
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Enhanced Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-br from-primary/10 to-primary/20 border-primary/30">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-primary">Total de WINs</CardTitle>
                <ArrowUp className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-foreground">{totalWins}</div>
                <p className="text-xs text-primary">+{totalOperations > 0 ? ((totalWins / totalOperations) * 100).toFixed(1) : '0'}% das operações</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-900/20 to-blue-950/30 border-blue-800/30">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-blue-700 dark:text-blue-400">Total de LOSSes</CardTitle>
                <ArrowDown className="h-4 w-4 text-blue-700 dark:text-blue-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-foreground">{totalLosses}</div>
                <p className="text-xs text-blue-700 dark:text-blue-400">{totalOperations > 0 ? ((totalLosses / totalOperations) * 100).toFixed(1) : '0'}% das operações</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/20 border-blue-500/30">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-blue-400">Taxa de Acerto</CardTitle>
                <Target className="h-4 w-4 text-blue-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{overallWinRate}%</div>
                <Progress value={overallWinRate} className="mt-2" />
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/20 border-purple-500/30">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-purple-400">Resultado Total</CardTitle>
                <DollarSign className="h-4 w-4 text-purple-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">R$ {totalProfit.toFixed(2)}</div>
                <p className="text-xs text-purple-400">
                  {totalProfit >= 0 ? '+' : ''}{totalOperations > 0 ? (totalProfit / totalOperations).toFixed(2) : '0.00'} por operação
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Performance Chart */}
          <Card className="bg-netflix-gray border-gray-700">
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-white flex items-center">
                <TrendingUp className="w-5 h-5 mr-2 text-blue-400" />
                Evolução dos Resultados (7 dias)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="date" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#1F2937', 
                        border: '1px solid #374151',
                        borderRadius: '8px',
                        color: '#fff'
                      }} 
                    />
                    <Area 
                      type="monotone" 
                      dataKey="profit" 
                      stroke="#3B82F6" 
                      fill="url(#colorProfit)" 
                      strokeWidth={2}
                    />
                    <defs>
                      <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats Row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-gradient-to-r from-indigo-500/10 to-indigo-600/20 border-indigo-500/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-indigo-400">Melhor Dia</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-lg font-bold text-white">R$ {bestDay?.profit?.toFixed(2) || '0.00'}</div>
                <p className="text-xs text-indigo-400">{bestDay?.date || 'N/A'}</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-yellow-500/10 to-yellow-600/20 border-yellow-500/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-yellow-400">Sequência Atual</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-lg font-bold text-white">{currentStreak}</div>
                <p className="text-xs text-yellow-400">operações seguidas</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-pink-500/10 to-pink-600/20 border-pink-500/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-pink-400">Maior Sequência</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-lg font-bold text-white">{maxStreak}</div>
                <p className="text-xs text-pink-400">record pessoal</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Assets Distribution */}
            <Card className="bg-netflix-gray border-gray-700">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <Activity className="w-5 h-5 mr-2 text-purple-400" />
                  Distribuição por Ativos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }: any) => `${name} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {pieData.map((entry: any, index: number) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1F2937', 
                          border: '1px solid #374151',
                          borderRadius: '8px',
                          color: '#fff'
                        }} 
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Win/Loss Comparison */}
            <Card className="bg-netflix-gray border-gray-700">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-white flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2 text-green-400" />
                  Comparativo WIN/LOSS (7 dias)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={performanceData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="date" stroke="#9CA3AF" />
                      <YAxis stroke="#9CA3AF" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1F2937', 
                          border: '1px solid #374151',
                          borderRadius: '8px',
                          color: '#fff'
                        }} 
                      />
                      <Bar dataKey="wins" fill="#10B981" name="WINs" />
                      <Bar dataKey="losses" fill="#EF4444" name="LOSSes" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Operations Tab */}
        <TabsContent value="operations" className="space-y-6">
          {/* Add New Operation */}
          <Card className="bg-netflix-gray border-gray-700">
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-white flex items-center">
                <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
                Registrar Nova Operação
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                    <FormField
                      control={form.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Tipo</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="WIN">WIN</SelectItem>
                              <SelectItem value="LOSS">LOSS</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="amount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Valor (R$)</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              type="number"
                              step="0.01"
                              placeholder="0.00"
                              className="bg-gray-700 border-gray-600 text-white"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="asset"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Ativo</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              placeholder="Ex: EUR/USD"
                              className="bg-gray-700 border-gray-600 text-white"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="time"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Horário</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              type="time"
                              className="bg-gray-700 border-gray-600 text-white"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <div className="flex items-end">
                      <Button
                        type="submit"
                        disabled={createLogMutation.isPending}
                        className="w-full bg-netflix-red hover:bg-netflix-red/90 text-white"
                      >
                        {createLogMutation.isPending ? "Registrando..." : "Registrar"}
                      </Button>
                    </div>
                  </div>

                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Observações</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            placeholder="Notas sobre a operação..."
                            className="bg-gray-700 border-gray-600 text-white"
                            rows={3}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </form>
              </Form>
            </CardContent>
          </Card>

          {/* Recent Operations */}
          <Card className="bg-netflix-gray border-gray-700">
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-white">Operações Recentes</CardTitle>
            </CardHeader>
            <CardContent>
              {processedTradingLogs && processedTradingLogs.length > 0 ? (
                <div className="space-y-2">
                  {processedTradingLogs.slice(0, 10).map((log: any) => (
                    <div key={log.id} className="flex items-center justify-between p-4 bg-gray-800 rounded-lg border border-gray-700 hover:bg-gray-750 transition-colors">
                      <div className="flex items-center space-x-4">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          log.type === 'WIN' ? 'bg-green-500/20 border border-green-500/30' : 'bg-red-500/20 border border-red-500/30'
                        }`}>
                          {log.type === 'WIN' ? 
                            <ArrowUp className="w-5 h-5 text-green-400" /> : 
                            <ArrowDown className="w-5 h-5 text-red-400" />
                          }
                        </div>
                        <div>
                          <p className="text-white font-medium text-lg">
                            {log.type} - {log.asset}
                          </p>
                          <p className="text-gray-400 text-sm">
                            R$ {parseFloat(log.amount).toFixed(2)}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-gray-400 text-sm">
                          {new Date(log.time).toLocaleTimeString("pt-BR", {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                        <p className="text-gray-500 text-xs">
                          {new Date(log.time).toLocaleDateString("pt-BR")}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="w-20 h-20 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                    <BarChart3 className="w-10 h-10 text-gray-400" />
                  </div>
                  <p className="text-gray-400 text-xl mb-2">Nenhuma operação registrada</p>
                  <p className="text-gray-500">Registre suas primeiras operações para começar a acompanhar sua performance</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Performance Tab */}
        <TabsContent value="performance" className="space-y-6">
          {/* Performance Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-br from-violet-500/10 to-violet-600/20 border-violet-500/30">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-violet-400">Rank Pessoal</CardTitle>
                <Award className="h-4 w-4 text-violet-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {overallWinRate >= 80 ? 'Expert' : overallWinRate >= 60 ? 'Avançado' : overallWinRate >= 40 ? 'Intermediário' : 'Iniciante'}
                </div>
                <p className="text-xs text-violet-400">baseado na taxa de acerto</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-teal-500/10 to-teal-600/20 border-teal-500/30">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-teal-400">Nível de Atividade</CardTitle>
                <Zap className="h-4 w-4 text-teal-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {totalOperations >= 100 ? 'Alto' : totalOperations >= 50 ? 'Médio' : 'Baixo'}
                </div>
                <p className="text-xs text-teal-400">{totalOperations} operações totais</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-orange-500/10 to-orange-600/20 border-orange-500/30">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-orange-400">Evolução</CardTitle>
                <TrendingUp className="h-4 w-4 text-orange-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {totalProfit >= 0 ? '+' : ''}{totalProfit.toFixed(0)}%
                </div>
                <p className="text-xs text-orange-400">retorno total</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-pink-500/10 to-pink-600/20 border-pink-500/30">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-pink-400">Meta Mensal</CardTitle>
                <Star className="h-4 w-4 text-pink-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {Math.round((totalOperations / 30) * 100)}%
                </div>
                <Progress value={Math.min((totalOperations / 30) * 100, 100)} className="mt-2" />
              </CardContent>
            </Card>
          </div>

          {/* Achievement Badges */}
          <Card className="bg-netflix-gray border-gray-700">
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-white">Conquistas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className={`p-4 rounded-lg border text-center ${totalOperations >= 10 ? 'bg-green-500/20 border-green-500/30' : 'bg-gray-800 border-gray-700'}`}>
                  <Trophy className={`w-8 h-8 mx-auto mb-2 ${totalOperations >= 10 ? 'text-green-400' : 'text-gray-400'}`} />
                  <p className={`text-sm font-medium ${totalOperations >= 10 ? 'text-green-400' : 'text-gray-400'}`}>
                    Primeiro Passo
                  </p>
                  <p className="text-xs text-gray-500">10 operações</p>
                </div>

                <div className={`p-4 rounded-lg border text-center ${overallWinRate >= 60 ? 'bg-blue-500/20 border-blue-500/30' : 'bg-gray-800 border-gray-700'}`}>
                  <Target className={`w-8 h-8 mx-auto mb-2 ${overallWinRate >= 60 ? 'text-blue-400' : 'text-gray-400'}`} />
                  <p className={`text-sm font-medium ${overallWinRate >= 60 ? 'text-blue-400' : 'text-gray-400'}`}>
                    Mira Certeira
                  </p>
                  <p className="text-xs text-gray-500">60% de acerto</p>
                </div>

                <div className={`p-4 rounded-lg border text-center ${currentStreak >= 5 ? 'bg-purple-500/20 border-purple-500/30' : 'bg-gray-800 border-gray-700'}`}>
                  <Zap className={`w-8 h-8 mx-auto mb-2 ${currentStreak >= 5 ? 'text-purple-400' : 'text-gray-400'}`} />
                  <p className={`text-sm font-medium ${currentStreak >= 5 ? 'text-purple-400' : 'text-gray-400'}`}>
                    Em Chamas
                  </p>
                  <p className="text-xs text-gray-500">5 seguidas</p>
                </div>

                <div className={`p-4 rounded-lg border text-center ${totalProfit >= 100 ? 'bg-yellow-500/20 border-yellow-500/30' : 'bg-gray-800 border-gray-700'}`}>
                  <DollarSign className={`w-8 h-8 mx-auto mb-2 ${totalProfit >= 100 ? 'text-yellow-400' : 'text-gray-400'}`} />
                  <p className={`text-sm font-medium ${totalProfit >= 100 ? 'text-yellow-400' : 'text-gray-400'}`}>
                    Rentável
                  </p>
                  <p className="text-xs text-gray-500">R$ 100 lucro</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}