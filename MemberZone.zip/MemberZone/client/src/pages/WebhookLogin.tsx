import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

export default function WebhookLogin() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [email, setEmail] = useState("");

  const webhookLoginMutation = useMutation({
    mutationFn: async (email: string) => {
      const response = await fetch('/api/auth/webhook-login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message);
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      localStorage.setItem('token', data.token);
      toast({
        title: "Login realizado com sucesso!",
        description: "Bem-vindo à plataforma premium!",
      });
      setLocation("/");
    },
    onError: (error: any) => {
      toast({
        title: "Erro no login",
        description: error.message || "Usuário não encontrado ou não é premium",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      toast({
        title: "Email obrigatório",
        description: "Digite seu email para continuar",
        variant: "destructive",
      });
      return;
    }
    webhookLoginMutation.mutate(email);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-card border-border">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl text-foreground">Acesso Premium</CardTitle>
          <CardDescription className="text-muted-foreground">
            Entre com o email usado no cadastro da corretora
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-foreground">
                Email
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="seu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-input border-border text-foreground placeholder:text-muted-foreground"
                required
              />
            </div>
            
            <Button
              type="submit"
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
              disabled={webhookLoginMutation.isPending}
            >
              {webhookLoginMutation.isPending ? "Verificando..." : "Entrar"}
            </Button>
          </form>

          <Alert className="mt-4 bg-muted/20 border-border">
            <AlertDescription className="text-muted-foreground text-sm">
              Este acesso é para usuários que se cadastraram através da corretora X1-Broker.
              Seu email deve estar registrado e verificado para acessar o conteúdo premium.
            </AlertDescription>
          </Alert>

          <div className="mt-4 text-center">
            <button
              onClick={() => setLocation("/login")}
              className="text-gray-400 hover:text-white text-sm underline"
            >
              Voltar para login normal
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}