import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Play, Star, Clock, Lock, X, Maximize } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useState } from "react";

export default function Classes() {
  const { user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedVideo, setSelectedVideo] = useState<any>(null);
  const [showPlayer, setShowPlayer] = useState(false);
  
  const { data: videos, isLoading } = useQuery({
    queryKey: ["/api/videos"],
  });

  const categories = [
    { id: "all", label: "Todas" },
    { id: "basic", label: "Básico" },
    { id: "intermediate", label: "Intermediário" },
    { id: "advanced", label: "Avançado" },
  ];

  const videosArray = Array.isArray(videos) ? videos : [];
  const filteredVideos = videosArray.filter((video: any) => 
    selectedCategory === "all" || video.level === selectedCategory
  );

  const handleVideoClick = (video: any) => {
    const canAccess = !video.isPremium || user?.isPremium || user?.role === "admin";
    if (canAccess) {
      setSelectedVideo(video);
      setShowPlayer(true);
    }
  };

  const getYouTubeEmbedUrl = (url: string) => {
    const videoId = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/);
    return videoId ? `https://www.youtube.com/embed/${videoId[1]}?autoplay=1&rel=0` : url;
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "basic": return "bg-success-green";
      case "intermediate": return "bg-info-blue";
      case "advanced": return "bg-netflix-red";
      default: return "bg-gray-600";
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <Card key={i} className="bg-card border-border animate-pulse">
              <div className="aspect-video bg-muted rounded-t-lg" />
              <CardContent className="p-4">
                <div className="h-4 bg-muted rounded mb-2" />
                <div className="h-3 bg-muted rounded mb-3" />
                <div className="flex justify-between">
                  <div className="h-3 bg-muted rounded w-16" />
                  <div className="h-3 bg-muted rounded w-12" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-bold text-foreground mb-4">Biblioteca de Aulas</h2>
        <div className="flex flex-wrap gap-2 sm:gap-4 mb-6">
          {categories.map((category) => (
            <Button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              variant={selectedCategory === category.id ? "default" : "outline"}
              size="sm"
              className={
                selectedCategory === category.id
                  ? "bg-navy-blue text-white hover:bg-navy-blue/90 text-xs sm:text-sm"
                  : "bg-muted text-muted-foreground border-border hover:bg-muted hover:text-foreground text-xs sm:text-sm"
              }
            >
              {category.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Video Grid */}
      {filteredVideos.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-6">
          {filteredVideos.map((video: any) => {
            const canAccess = !video.isPremium || user?.isPremium || user?.role === "admin";
            
            return (
              <Card 
                key={video.id} 
                className="bg-card border-border overflow-hidden hover:scale-105 transition-transform cursor-pointer group"
                onClick={() => handleVideoClick(video)}
              >
                <div className="relative aspect-video">
                  <img 
                    src={video.thumbnailUrl || `https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=400&h=225&fit=crop&auto=format`}
                    alt={video.title}
                    className="w-full h-full object-cover"
                  />
                  {!canAccess && (
                    <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center">
                      <Lock className="w-8 h-8 text-white" />
                    </div>
                  )}
                  {canAccess && (
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Play className="w-12 h-12 text-white" />
                    </div>
                  )}
                  {video.duration && (
                    <div className="absolute top-2 right-2 bg-netflix-red text-white px-2 py-1 rounded text-xs">
                      {formatDuration(video.duration)}
                    </div>
                  )}
                  {video.isPremium && (
                    <div className="absolute top-2 left-2 bg-success-green text-white px-2 py-1 rounded text-xs">
                      PRO
                    </div>
                  )}
                </div>
                <CardContent className="p-3 sm:p-4">
                  <h3 className="font-semibold text-sm sm:text-lg mb-2 text-foreground line-clamp-2">
                    {video.title}
                  </h3>
                  <p className="text-muted-foreground text-xs sm:text-sm mb-3 line-clamp-2">
                    {video.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <Badge className={`${getCategoryColor(video.level)} text-white text-xs`}>
                      {video.level === "basic" ? "Básico" : 
                       video.level === "intermediate" ? "Intermediário" : "Avançado"}
                    </Badge>
                    {video.rating && (
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span className="text-sm text-white">{video.rating}</span>
                      </div>
                    )}
                  </div>
                  {!canAccess && (
                    <div className="mt-3 text-center">
                      <p className="text-xs text-gray-400">Upgrade para Premium</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-16">
          <div className="w-24 h-24 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6">
            <Play className="w-12 h-12 text-gray-400" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">Nenhuma aula encontrada</h3>
          <p className="text-gray-400">
            {selectedCategory === "all" 
              ? "Não há aulas disponíveis no momento."
              : `Não há aulas na categoria "${categories.find(c => c.id === selectedCategory)?.label}".`
            }
          </p>
        </div>
      )}

      {/* Video Player Modal */}
      <Dialog open={showPlayer} onOpenChange={setShowPlayer}>
        <DialogContent className="max-w-4xl w-[95%] sm:w-full mx-auto bg-netflix-gray border-gray-700 max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white text-lg sm:text-xl pr-8">
              {selectedVideo?.title}
            </DialogTitle>
            <Button 
              variant="ghost" 
              size="sm" 
              className="absolute top-2 right-2 text-white hover:bg-gray-700 z-10"
              onClick={() => setShowPlayer(false)}
            >
              <X className="w-4 h-4" />
            </Button>
          </DialogHeader>
          
          {selectedVideo && (
            <div className="space-y-3 sm:space-y-4">
              {/* Video Player */}
              <div className="aspect-video bg-black rounded-lg overflow-hidden">
                <iframe
                  src={getYouTubeEmbedUrl(selectedVideo.videoUrl)}
                  className="w-full h-full"
                  allowFullScreen
                  title={selectedVideo.title}
                />
              </div>
              
              {/* Video Info */}
              <div className="space-y-2 sm:space-y-3">
                <div className="flex items-center flex-wrap gap-2">
                  <Badge className={`${getCategoryColor(selectedVideo.level)} text-white text-xs`}>
                    {selectedVideo.level === "basic" ? "Básico" : 
                     selectedVideo.level === "intermediate" ? "Intermediário" : "Avançado"}
                  </Badge>
                  {selectedVideo.isPremium && (
                    <Badge className="bg-success-green text-white text-xs">
                      PRO
                    </Badge>
                  )}
                  {selectedVideo.isFeatured && (
                    <Badge className="bg-netflix-red text-white text-xs">
                      <Star className="w-3 h-3 mr-1" />
                      Destaque
                    </Badge>
                  )}
                </div>
                
                <p className="text-gray-300 text-xs sm:text-sm">
                  {selectedVideo.description}
                </p>
                
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs sm:text-sm text-gray-400">
                  <span>Instrutor: {selectedVideo.instructor}</span>
                  <span>Categoria: {selectedVideo.category}</span>
                </div>
                
                {selectedVideo.tags && (
                  <div className="flex flex-wrap gap-1">
                    {selectedVideo.tags.split(',').map((tag: string, index: number) => (
                      <span key={index} className="bg-gray-700 text-gray-300 px-2 py-1 rounded-full text-xs">
                        {tag.trim()}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
