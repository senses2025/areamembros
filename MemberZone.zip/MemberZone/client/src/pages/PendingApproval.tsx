import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock, ExternalLink, CheckCircle, AlertCircle } from "lucide-react";
import { useLocation } from "wouter";

export default function PendingApproval() {
  const [, setLocation] = useLocation();
  const [pollingEnabled, setPollingEnabled] = useState(true);

  // Verificar status da conta a cada 3 segundos
  const { data: accountStatus, refetch } = useQuery({
    queryKey: ["/api/account-status"],
    refetchInterval: pollingEnabled ? 3000 : false, // Poll a cada 3 segundos
    enabled: pollingEnabled,
  });

  useEffect(() => {
    // Se o usuário foi liberado, redirecionar para home
    if (accountStatus?.account?.canAccessPremium || 
        (accountStatus?.account?.isPremium && accountStatus?.account?.accountStatus === 'premium_released')) {
      setPollingEnabled(false);
      console.log('✅ Usuário liberado, redirecionando...', accountStatus?.account);
      setTimeout(() => {
        setLocation("/");
      }, 1500);
    }
  }, [accountStatus, setLocation]);

  const handleSendSupport = () => {
    const user = accountStatus?.account;
    const message = `Olá! Preciso de ajuda com a liberação da minha conta premium.

📧 Email: ${user?.email}
👤 Nome: ${user?.name}
🏦 Status: ${user?.accountStatus}

Já me cadastrei na X1-Broker e estou aguardando a liberação do acesso premium no Investidor Academy Pro.

Obrigado!`;

    const whatsappUrl = `https://wa.me/5511999999999?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleOpenBroker = () => {
    window.open("https://x1-broker.com/account/signup", '_blank');
  };

  if (accountStatus?.account?.canAccessPremium || 
      (accountStatus?.account?.isPremium && accountStatus?.account?.accountStatus === 'premium_released')) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-gray-800 border-gray-700 shadow-2xl">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto animate-pulse" />
            </div>
            <CardTitle className="text-2xl text-white">
              Conta Liberada!
            </CardTitle>
            <CardDescription className="text-gray-400">
              Redirecionando para o aplicativo...
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <Button
              onClick={() => setLocation("/")}
              className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Acessar Aplicativo
            </Button>
            <p className="text-xs text-gray-500 mt-3">
              Ou aguarde o redirecionamento automático...
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-gray-800 border-gray-700 shadow-2xl">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            <Clock className="w-16 h-16 text-yellow-500 mx-auto animate-spin" />
          </div>
          <CardTitle className="text-2xl text-white">
            Aguardando Liberação
          </CardTitle>
          <CardDescription className="text-gray-400">
            Complete seu registro na X1-Broker para ter acesso liberado
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Status da Conta */}
          <div className="bg-gray-700 rounded-lg p-4">
            <div className="flex items-center gap-3 mb-3">
              <AlertCircle className="w-5 h-5 text-yellow-500" />
              <span className="text-white font-medium">Status da Conta</span>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Email:</span>
                <span className="text-white">{accountStatus?.account?.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Status:</span>
                <span className="text-yellow-500">
                  {accountStatus?.account?.accountStatus === 'not_released' ? 'Aguardando Cadastro' : 
                   accountStatus?.account?.accountStatus === 'pending_review' ? 'Aguardando Análise' : 
                   'Não Liberado'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Corretora:</span>
                <span className="text-white">
                  {accountStatus?.account?.brokerRegistered ? 'Cadastrado' : 'Não Cadastrado'}
                </span>
              </div>
            </div>
          </div>

          {/* Instruções */}
          <div className="bg-gray-700 rounded-lg p-4">
            <h3 className="text-white font-medium mb-3">📋 Como Funciona</h3>
            <div className="space-y-2 text-sm text-gray-300">
              <div className="flex gap-2">
                <span className="text-blue-400">1.</span>
                <span>Cadastre-se na X1-Broker</span>
              </div>
              <div className="flex gap-2">
                <span className="text-blue-400">2.</span>
                <span>Aguarde a liberação automática</span>
              </div>
              <div className="flex gap-2">
                <span className="text-blue-400">3.</span>
                <span>Acesso será liberado automaticamente</span>
              </div>
              <div className="flex gap-2">
                <span className="text-blue-400">4.</span>
                <span>Se demorar, entre em contato</span>
              </div>
            </div>
          </div>

          {/* Botões */}
          <div className="space-y-3">
            <Button
              onClick={handleOpenBroker}
              className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Cadastrar na X1-Broker
            </Button>
            
            <Button
              onClick={handleSendSupport}
              variant="outline"
              className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              💬 Entrar em Contato - Suporte
            </Button>
          </div>

          {/* Verificação Automática */}
          <div className="text-center">
            <p className="text-xs text-gray-500">
              Verificando automaticamente a cada 3 segundos...
            </p>
            <div className="mt-2 flex justify-center">
              <div className="animate-pulse flex space-x-1">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}