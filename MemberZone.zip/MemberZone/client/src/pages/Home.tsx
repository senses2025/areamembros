import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, Target, DollarSign, Video, ArrowUp, ArrowDown, Play } from "lucide-react";

export default function Home() {
  const { data: dailyStats } = useQuery({
    queryKey: ["/api/trading-stats/daily"],
  });

  const { data: userProgress } = useQuery({
    queryKey: ["/api/user/progress"],
  });

  const { data: dashboardConfig } = useQuery({
    queryKey: ["/api/dashboard-config"],
  });

  // Use dashboard config or fallback to default
  const config = dashboardConfig || {
    card1: { title: "Operações Hoje", value: "0", subtitle: "0 WINs / 0 LOSSes" },
    card2: { title: "Taxa de Acerto", value: "0%", subtitle: "Hoje" },
    card3: { title: "Resultado Hoje", value: "R$ 0,00", subtitle: "Lucro/Prejuízo" },
    card4: { title: "Próxima Live", value: "19:30", subtitle: "Estratégias Avançadas" }
  };

  return (
    <div className="space-y-4 sm:space-y-8">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm sm:text-lg font-semibold text-card-foreground">{config.card1.title}</CardTitle>
            <TrendingUp className="h-4 w-4 sm:h-5 sm:w-5 text-success-green" />
          </CardHeader>
          <CardContent className="pb-3 sm:pb-6">
            <div className="text-xl sm:text-3xl font-bold text-success-green">
              {config.card1.value}
            </div>
            <p className="text-xs sm:text-sm text-muted-foreground">
              {config.card1.subtitle}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm sm:text-lg font-semibold text-card-foreground">{config.card2.title}</CardTitle>
            <Target className="h-4 w-4 sm:h-5 sm:w-5 text-info-blue" />
          </CardHeader>
          <CardContent className="pb-3 sm:pb-6">
            <div className="text-xl sm:text-3xl font-bold text-info-blue">
              {config.card2.value}
            </div>
            <p className="text-xs sm:text-sm text-muted-foreground">{config.card2.subtitle}</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm sm:text-lg font-semibold text-card-foreground">{config.card3.title}</CardTitle>
            <DollarSign className="h-4 w-4 sm:h-5 sm:w-5 text-success-green" />
          </CardHeader>
          <CardContent className="pb-3 sm:pb-6">
            <div className="text-xl sm:text-3xl font-bold text-success-green">
              {config.card3.value}
            </div>
            <p className="text-xs sm:text-sm text-muted-foreground">{config.card3.subtitle}</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm sm:text-lg font-semibold text-card-foreground">{config.card4.title}</CardTitle>
            <Video className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
          </CardHeader>
          <CardContent className="pb-3 sm:pb-6">
            <div className="text-lg sm:text-xl font-bold text-primary">{config.card4.value}</div>
            <p className="text-xs sm:text-sm text-muted-foreground">{config.card4.subtitle}</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activities */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-card-foreground">Atividades Recentes</CardTitle>
        </CardHeader>
        <CardContent>
          {Array.isArray(userProgress) && userProgress.length > 0 ? (
            <div className="space-y-4">
              {userProgress.slice(0, 5).map((progress: any) => (
                <div key={progress.id} className="flex items-center space-x-4 p-4 bg-muted rounded-lg">
                  <div className="w-10 h-10 bg-info-blue rounded-full flex items-center justify-center">
                    <Play className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-foreground">Progresso em vídeo</p>
                    <p className="text-sm text-muted-foreground">
                      {progress.completed ? "Concluído" : `${progress.progress}% assistido`}
                    </p>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {new Date(progress.lastWatched!).toLocaleDateString()}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <Play className="w-8 h-8 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground text-lg">Nenhuma atividade recente</p>
              <p className="text-muted-foreground text-sm">Comece assistindo algumas aulas para ver seu progresso aqui</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
