import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/hooks/useAuth";
import { ArrowUp, ArrowDown, Crown, Bot, TrendingUp, Activity, Clock, CheckCircle, Play, Square, Settings, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/queryClient";

// Component for animated countdown bar
const ExpirationBar = ({ createdAt }: { createdAt: string }) => {
  const [progress, setProgress] = useState(100);
  
  useEffect(() => {
    const startTime = new Date(createdAt).getTime();
    const duration = 60000; // 1 minute in milliseconds
    
    const interval = setInterval(() => {
      const now = Date.now();
      const elapsed = now - startTime;
      const remaining = Math.max(0, duration - elapsed);
      const progressPercent = (remaining / duration) * 100;
      
      setProgress(progressPercent);
      
      if (remaining <= 0) {
        clearInterval(interval);
      }
    }, 1000);
    
    return () => clearInterval(interval);
  }, [createdAt]);
  
  const remainingSeconds = Math.ceil((progress / 100) * 60);
  const minutes = Math.floor(remainingSeconds / 60);
  const seconds = remainingSeconds % 60;
  
  return (
    <div className="mt-4">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium text-foreground">Expiração</span>
        <span className="text-sm font-bold text-foreground">
          {minutes}:{seconds.toString().padStart(2, '0')}
        </span>
      </div>
      <div className="w-full bg-muted rounded-full h-2">
        <div 
          className="bg-primary h-2 rounded-full transition-all duration-1000"
          style={{ width: `${progress}%` }}
        ></div>
      </div>
      <div className="flex justify-between text-xs text-muted-foreground mt-1">
        <span>0:00</span>
        <span>1:00</span>
      </div>
    </div>
  );
};

export default function TradingRobot() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [configOpen, setConfigOpen] = useState(false);

  const { data: signals, isLoading } = useQuery({
    queryKey: ["/api/trading-signals"],
    refetchInterval: 5000, // Refetch every 5 seconds for real-time updates
  });

  const { data: robotStatus, isLoading: statusLoading } = useQuery({
    queryKey: ["/api/robot/status"],
    refetchInterval: 3000, // Check robot status every 3 seconds
  });

  // Robot control mutations
  const startRobotMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/robot/start", { 
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      if (!response.ok) throw new Error("Failed to start robot");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Robô Iniciado",
        description: "O robô de sinais foi iniciado com sucesso!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/robot/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/trading-signals"] });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao iniciar o robô de sinais.",
        variant: "destructive",
      });
    },
  });

  const stopRobotMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/robot/stop", { 
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      if (!response.ok) throw new Error("Failed to stop robot");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Robô Parado",
        description: "O robô de sinais foi parado com sucesso!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/robot/status"] });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao parar o robô de sinais.",
        variant: "destructive",
      });
    },
  });

  const updateConfigMutation = useMutation({
    mutationFn: async (config: any) => {
      const response = await fetch("/api/robot/config", { 
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(config)
      });
      if (!response.ok) throw new Error("Failed to update config");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Configuração Atualizada",
        description: "As configurações do robô foram salvas!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/robot/status"] });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao atualizar configurações.",
        variant: "destructive",
      });
    },
  });

  // Check premium access
  useEffect(() => {
    if (user && !user.isPremium && user.role !== "admin") {
      toast({
        title: "Acesso Premium Necessário",
        description: "Você precisa ser Premium para acessar o robô de sinais.",
        variant: "destructive",
      });
    }
  }, [user, toast]);

  if (!user?.isPremium && user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Card className="bg-netflix-gray border-gray-700 max-w-md">
          <CardContent className="p-8 text-center">
            <div className="w-20 h-20 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6">
              <Crown className="w-10 h-10 text-success-green" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Recurso Premium</h3>
            <p className="text-gray-400 mb-6">
              O Robô de Sinais é exclusivo para usuários Premium. 
              Cadastre-se na corretora e faça seu depósito para liberar o acesso.
            </p>
            <Button className="w-full bg-success-green hover:bg-success-green/90 text-white">
              Upgrade para Premium
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const signalsArray = Array.isArray(signals) ? signals : [];
  const activeSignals = signalsArray.filter((signal: any) => signal.isActive && !signal.result);
  const completedSignals = signalsArray.filter((signal: any) => signal.result);

  const robotConfig = (robotStatus as any)?.config;
  const robotInfo = (robotStatus as any)?.robot;
  const isRobotRunning = robotInfo?.isRunning || false;

  const todayStats = {
    totalSignals: signalsArray.length,
    winRate: completedSignals.length > 0 
      ? Math.round((completedSignals.filter((s: any) => s.result === 'WIN').length / completedSignals.length) * 100)
      : 0,
    lastSignal: signalsArray[0] ? new Date(signalsArray[0].createdAt) : null,
    signalsGenerated: robotInfo?.signalsGenerated || 0,
  };

  return (
    <div className="space-y-6 sm:space-y-8">
      {/* Premium Badge */}
      <div className="bg-primary/20 border border-primary rounded-lg p-3 sm:p-4">
        <div className="flex items-center space-x-2">
          <Crown className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
          <span className="text-primary font-medium text-sm sm:text-base">Recurso Premium Ativo</span>
        </div>
      </div>

      {/* Robot Controls */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 sm:gap-6">
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-xl font-semibold text-foreground">Controle do Robô</CardTitle>
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${isRobotRunning ? 'bg-primary' : 'bg-muted'}`} />
              <span className="text-sm text-muted-foreground">
                {isRobotRunning ? 'Ativo' : 'Parado'}
              </span>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-col space-y-4">
              <Button 
                onClick={() => startRobotMutation.mutate()}
                disabled={isRobotRunning || startRobotMutation.isPending}
                className="bg-primary hover:bg-primary/90 text-primary-foreground disabled:opacity-50"
              >
                <Play className="w-4 h-4 mr-2" />
                {startRobotMutation.isPending ? 'Iniciando...' : 'Iniciar Robô'}
              </Button>
              
              <Button 
                onClick={() => stopRobotMutation.mutate()}
                disabled={!isRobotRunning || stopRobotMutation.isPending}
                variant="destructive"
                className="disabled:opacity-50"
              >
                <Square className="w-4 h-4 mr-2" />
                {stopRobotMutation.isPending ? 'Parando...' : 'Parar Robô'}
              </Button>
            </div>

            <div className="pt-4 border-t border-gray-600">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-white">Configurações Rápidas</span>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setConfigOpen(!configOpen)}
                  className="text-gray-400 hover:text-white"
                >
                  <Settings className="w-4 h-4" />
                </Button>
              </div>
              
              {configOpen && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm text-gray-300 mb-2">
                      Força Mínima: {robotConfig?.minStrength || 70}%
                    </label>
                    <Slider
                      value={[robotConfig?.minStrength || 70]}
                      onValueChange={(value) => 
                        updateConfigMutation.mutate({ 
                          ...robotConfig, 
                          minStrength: value[0] 
                        })
                      }
                      min={50}
                      max={95}
                      step={5}
                      className="w-full"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm text-muted-foreground mb-2">
                      Max Sinais/Hora: {robotConfig?.maxSignalsPerHour || 10}
                    </label>
                    <Slider
                      value={[robotConfig?.maxSignalsPerHour || 10]}
                      onValueChange={(value) => 
                        updateConfigMutation.mutate({ 
                          ...robotConfig, 
                          maxSignalsPerHour: value[0] 
                        })
                      }
                      min={1}
                      max={20}
                      step={1}
                      className="w-full"
                    />
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-foreground">Status em Tempo Real</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Sinais Gerados</span>
              <span className="text-lg font-bold text-primary">{todayStats.signalsGenerated}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Taxa de Acerto</span>
              <span className="text-lg font-bold text-primary">{todayStats.winRate}%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Sinais Ativos</span>
              <span className="text-lg font-bold text-primary">{activeSignals.length}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Último Sinal</span>
              <span className="text-lg font-bold text-muted-foreground">
                {todayStats.lastSignal 
                  ? `${Math.floor((Date.now() - todayStats.lastSignal.getTime()) / 60000)} min`
                  : "Aguardando..."
                }
              </span>
            </div>
            
            {isRobotRunning && (
              <div className="mt-4 p-3 bg-success-green/20 border border-success-green rounded-lg">
                <div className="flex items-center space-x-2">
                  <Zap className="w-4 h-4 text-success-green" />
                  <span className="text-sm text-success-green font-medium">
                    Robô ativo - Gerando sinais automaticamente
                  </span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Live Signals */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-foreground">Sinais em Tempo Real</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="bg-muted rounded-lg p-4 animate-pulse">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-muted-foreground/20 rounded-full" />
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-muted-foreground/20 rounded w-1/4" />
                      <div className="h-3 bg-muted-foreground/20 rounded w-1/2" />
                    </div>
                    <div className="h-8 bg-muted-foreground/20 rounded w-20" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {/* Active Signals */}
              {activeSignals.map((signal: any) => (
                <div key={signal.id} className="bg-muted rounded-lg p-3 sm:p-4">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-3 sm:mb-4">
                    <div className="flex items-center space-x-3 sm:space-x-4 mb-2 sm:mb-0">
                      <div>
                        <h4 className="font-semibold text-base sm:text-lg text-foreground">
                          {signal.asset}
                        </h4>
                        <p className="text-xs sm:text-sm text-muted-foreground">
                          {signal.strategy}
                        </p>
                      </div>
                    </div>
                    <div className="text-left sm:text-right">
                      <div className={`px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg font-bold text-white inline-block ${
                        signal.signal === 'CALL' ? 'bg-green-600' : 'bg-red-600'
                      }`}>
                        {signal.signal}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        {signal.strength}% força
                      </p>
                    </div>
                  </div>
                  
                  <ExpirationBar createdAt={signal.createdAt} />
                </div>
              ))}

              {/* Completed Signals */}
              {completedSignals.slice(0, 3).map((signal: any) => (
                <div key={signal.id} className="bg-gray-800 rounded-lg p-4 flex items-center justify-between opacity-75">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                      signal.result === 'WIN' ? 'bg-success-green' : 'bg-loss-red'
                    }`}>
                      <CheckCircle className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-lg text-white">
                        {signal.signal} {signal.asset}
                      </h4>
                      <p className="text-sm text-gray-400">
                        Estratégia: {signal.strategy}
                      </p>
                      <p className="text-sm text-gray-400">
                        Resultado: {signal.result}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-400">
                      {new Date(signal.createdAt).toLocaleTimeString("pt-BR", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                    <Badge className={`mt-2 ${
                      signal.result === 'WIN' ? 'bg-success-green' : 'bg-loss-red'
                    } text-white`}>
                      {signal.result}
                    </Badge>
                  </div>
                </div>
              ))}

              {signalsArray.length === 0 && (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Bot className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-400 text-lg">Nenhum sinal disponível</p>
                  <p className="text-gray-500 text-sm">O robô está analisando o mercado para gerar novos sinais</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
