import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { Lock, ExternalLink, CheckCircle, Clock } from "lucide-react";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";

export default function BrokerRegistration() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [isPolling, setIsPolling] = useState(false);
  const [hasClickedRegister, setHasClickedRegister] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  // Manual approval - no automatic polling needed

  const handleBrokerRegistration = () => {
    // Open broker registration with user's email pre-filled
    const brokerUrl = `https://x1-broker.com/account/signup?email=${encodeURIComponent(user?.email || '')}`;
    window.open(brokerUrl, "_blank");
    
    // Mark that user clicked to register
    setHasClickedRegister(true);
  };

  const handleLogout = () => {
    logout();
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="max-w-sm sm:max-w-lg lg:max-w-2xl w-full space-y-4 sm:space-y-6">
        {/* Header */}
        <div className="text-center space-y-3 sm:space-y-4">
          <div className="mx-auto w-16 h-16 sm:w-20 sm:h-20 bg-primary rounded-full flex items-center justify-center">
            <Lock className="h-8 w-8 sm:h-10 sm:w-10 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">
              Bem-vindo ao Investidor Academy Pro
            </h1>
            <p className="text-muted-foreground text-base sm:text-lg px-4">
              Olá {user?.name}! Para acessar todo o conteúdo premium, você precisa se registrar em nossa plataforma de trading parceira.
            </p>
          </div>
        </div>

        {/* Main Card */}
        <Card className="bg-card border-border">
          <CardHeader className="text-center">
            <CardTitle className="text-card-foreground text-2xl">
              Desbloqueie o Acesso Premium
            </CardTitle>
            <CardDescription className="text-muted-foreground text-base">
              Complete seu cadastro na X1-Broker para ter acesso total à plataforma
              <br /><br />
              <div className="bg-warning/20 border border-warning/30 rounded-lg p-3 mt-4">
                <div className="flex items-center space-x-2">
                  <span className="text-warning text-sm font-semibold">⚠️ IMPORTANTE:</span>
                </div>
                <p className="text-warning/90 text-sm mt-1">
                  Use o email <strong className="text-warning">{user?.email}</strong> para garantir ativação automática. Após o cadastro, volte a esta tela onde será liberado o acesso.
                </p>
              </div>
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Features List */}
            <div className="space-y-4">
              <h3 className="text-card-foreground font-semibold text-lg mb-4">O que você terá acesso:</h3>
              <div className="grid gap-3">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
                  <span className="text-muted-foreground">Aulas exclusivas de trading</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
                  <span className="text-muted-foreground">Transmissões ao vivo com especialistas</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
                  <span className="text-muted-foreground">Robô de trading automatizado</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
                  <span className="text-muted-foreground">Sinais de trading em tempo real</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
                  <span className="text-muted-foreground">Suporte personalizado</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
                  <span className="text-muted-foreground">Dashboard de acompanhamento de resultados</span>
                </div>
              </div>
            </div>

            {/* Success Status Display */}
            {showSuccess && (
              <div className="bg-primary/20 border border-primary rounded-lg p-4 text-center">
                <CheckCircle className="h-8 w-8 text-primary mx-auto mb-3" />
                <h4 className="text-primary font-bold text-xl mb-2">🎉 Cadastro Concluído!</h4>
                <p className="text-foreground text-lg mb-3">
                  Seu acesso premium foi ativado com sucesso!
                </p>
                <p className="text-muted-foreground text-sm mb-4">
                  Agora você tem acesso a todo o conteúdo premium da plataforma.
                </p>
                <Button
                  onClick={() => setLocation('/')}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground text-lg py-3"
                  size="lg"
                >
                  <CheckCircle className="h-5 w-5 mr-2" />
                  Entrar no App
                </Button>
              </div>
            )}

            {/* Awaiting Manual Approval */}
            {hasClickedRegister && !showSuccess && (
              <div className="bg-muted/20 border border-muted-foreground/30 rounded-lg p-4 text-center">
                <Clock className="h-6 w-6 text-muted-foreground mx-auto mb-2 animate-pulse" />
                <h4 className="text-foreground font-semibold mb-2">Falta pouco</h4>
                <p className="text-muted-foreground text-sm mb-4">
                  Complete seu registro na X1-Broker na aba que foi aberta.
                </p>
                
                {/* Instructions */}
                <div className="bg-warning/20 border border-warning/30 rounded-lg p-3 mb-4">
                  <p className="text-warning text-sm">
                    📸 Após criar sua conta, envie o email e print da conta para liberação.
                  </p>
                </div>
                
                {/* Support Button */}
                <Button
                  onClick={() => {
                    const message = `🎯 LIBERAÇÃO DE ACESSO - Investidor Academy Pro

📧 Email: ${user?.email}
👤 Nome: ${user?.name}

✅ Completei meu cadastro na X1-Broker!

📸 Segue em anexo o email e print da conta criada para liberação do acesso premium.

Aguardo a ativação. Obrigado!`;
                    
                    const telegramUrl = `https://t.me/YOUR_TELEGRAM_USERNAME?text=${encodeURIComponent(message)}`;
                    window.open(telegramUrl, '_blank');
                  }}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  📧 Enviar Email e Print da Conta para Suporte
                </Button>
              </div>
            )}

            {/* Action Buttons */}
            <div className="space-y-3">
              <Button
                onClick={handleBrokerRegistration}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground text-lg py-6"
                size="lg"
              >
                <ExternalLink className="h-5 w-5 mr-2" />
                Registrar na X1-Broker
              </Button>
              
              <p className="text-center text-sm text-muted-foreground">
                {hasClickedRegister 
                  ? "Complete seu registro na nova aba que foi aberta"
                  : "Após completar o registro, seu acesso será liberado automaticamente"
                }
              </p>
            </div>

            {/* Help Text */}
            <div className="bg-muted/10 rounded-lg p-4 border border-border">
              <h4 className="text-card-foreground font-semibold mb-2">Como funciona:</h4>
              <ol className="text-muted-foreground text-sm space-y-1 list-decimal list-inside">
                <li>Clique no botão "Registrar na X1-Broker"</li>
                <li>Complete seu cadastro na plataforma</li>
                <li>Volte a esta tela para verificar se o acesso foi liberado</li>
                <li>Se necessário, envie email e print da conta para suporte</li>
                <li>Aguarde a liberação (normalmente automática ou em poucos minutos)</li>
              </ol>
            </div>

            {/* Logout Option */}
            <div className="text-center pt-4 border-t border-border">
              <Button
                variant="ghost"
                onClick={handleLogout}
                className="text-muted-foreground hover:text-foreground"
              >
                Sair da conta
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center">
          <p className="text-xs text-muted-foreground">
            © 2024 Investidor Academy. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </div>
  );
}