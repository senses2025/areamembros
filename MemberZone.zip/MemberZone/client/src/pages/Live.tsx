import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Play, Users, Calendar, Clock } from "lucide-react";
import { useState, useEffect, useRef } from "react";

// Function to extract YouTube video ID from URL
const extractYouTubeId = (url: string): string => {
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
  const match = url.match(regExp);
  return match && match[2].length === 11 ? match[2] : '';
};

export default function Live() {
  const [iframeError, setIframeError] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  
  const { data: currentStream } = useQuery({
    queryKey: ["/api/live-streams/current"],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  const { data: allStreams } = useQuery({
    queryKey: ["/api/live-streams"],
  });

  const previousStreams = Array.isArray(allStreams) ? allStreams.filter((stream: any) => !stream.isLive) : [];

  // Ativar automaticamente o fallback para Google Meet (Google bloqueia iframe)
  useEffect(() => {
    if ((currentStream as any)?.platform === 'meet') {
      setIframeError(true);
    }
  }, [currentStream]);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    });
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="space-y-4 sm:space-y-8">
      {/* Current Live Stream */}
      {currentStream ? (
        <Card className="bg-card border-border overflow-hidden">
          <CardHeader className="pb-3 sm:pb-4 lg:pb-6 px-3 sm:px-6">
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <CardTitle className="text-sm sm:text-base lg:text-lg font-semibold text-foreground leading-tight">
                    {(currentStream as any)?.title}
                  </CardTitle>
                </div>
                <Badge className="bg-primary text-primary-foreground text-xs px-2 py-1 whitespace-nowrap flex-shrink-0">
                  🔴 AO VIVO
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <p className="text-muted-foreground text-xs sm:text-sm">
                  {formatDate((currentStream as any)?.scheduledAt)} às {formatTime((currentStream as any)?.scheduledAt)}
                </p>
                <div className="flex items-center space-x-1 text-muted-foreground">
                  <Users className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span className="text-xs sm:text-sm whitespace-nowrap">{(currentStream as any)?.viewerCount || 0} assistindo</span>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="px-3 sm:px-6">
            {/* Live Stream Player */}
            <div className="bg-black rounded-lg aspect-video mb-4 sm:mb-6">
              {(currentStream as any)?.streamUrl ? (
                (currentStream as any)?.platform === 'youtube' || (currentStream as any)?.streamUrl.includes('youtube.com') || (currentStream as any)?.streamUrl.includes('youtu.be') ? (
                  // YouTube Embed
                  <iframe
                    src={`https://www.youtube.com/embed/${extractYouTubeId((currentStream as any)?.streamUrl)}?autoplay=1&mute=1`}
                    className="w-full h-full rounded-lg"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                ) : (currentStream as any)?.platform === 'jitsi' ? (
                  // Jitsi Meet - Integrado
                  <div className="w-full h-full relative bg-gray-900 rounded-lg overflow-hidden">
                    <iframe
                      src={`https://meet.jit.si/${(currentStream as any)?.streamUrl?.split('/').pop() || 'InvestidorAcademy'}`}
                      className="w-full h-full"
                      allow="camera; microphone; display-capture"
                      allowFullScreen
                    />
                    <div className="absolute top-4 right-4 bg-black/70 text-white px-3 py-1 rounded text-sm">
                      🔴 Ao Vivo - Jitsi Meet
                    </div>
                  </div>
                ) : (currentStream as any)?.platform === 'meet' || (currentStream as any)?.streamUrl?.includes('meet.google.com') ? (
                  // Google Meet Interface
                  <div className="w-full h-full relative bg-gradient-to-br from-blue-600 to-blue-800">
                    {!iframeError ? (
                      <>
                        <iframe
                          ref={iframeRef}
                          src={(currentStream as any)?.streamUrl}
                          className="w-full h-full rounded-lg border-0"
                          allow="camera; microphone; display-capture; autoplay"
                          allowFullScreen
                          title="Google Meet"
                          onError={() => setIframeError(true)}
                          sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
                        />
                        <div className="absolute top-4 right-4 bg-black/70 text-white px-3 py-1 rounded text-sm">
                          🔴 Ao Vivo no Google Meet
                        </div>
                      </>
                    ) : (
                      // Interface principal do Google Meet
                      <div className="w-full h-full flex flex-col items-center justify-center text-center p-4 space-y-4">
                        <div className="bg-white/20 backdrop-blur-sm rounded-full p-3 sm:p-4 shadow-xl">
                          <Users className="w-8 h-8 sm:w-12 sm:h-12 text-white" />
                        </div>
                        
                        <div className="space-y-2">
                          <h2 className="text-lg sm:text-xl font-bold text-white">
                            🔴 Live Ao Vivo
                          </h2>
                          <h3 className="text-sm sm:text-base font-semibold text-blue-100 px-2">
                            {(currentStream as any)?.title}
                          </h3>
                        </div>
                        
                        <p className="text-blue-100 max-w-xs text-xs sm:text-sm leading-relaxed px-2">
                          {(currentStream as any)?.description || "A transmissão está acontecendo agora no Google Meet!"}
                        </p>
                        
                        <div className="space-y-2 w-full max-w-xs px-2">
                          <a
                            href={(currentStream as any)?.streamUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block w-full bg-white text-blue-600 px-4 py-3 rounded-lg font-bold text-sm hover:bg-blue-50 transition-colors shadow-lg"
                          >
                            🚀 ENTRAR NA LIVE
                          </a>
                          
                          <div className="text-blue-200 text-xs">
                            👆 Clique para abrir o Google Meet
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  // Generic Link
                  <div className="w-full h-full flex items-center justify-center">
                    <div className="text-center">
                      <Play className="w-16 h-16 text-netflix-red mx-auto mb-4" />
                      <p className="text-lg font-medium text-white">Transmissão ao Vivo</p>
                      <a
                        href={(currentStream as any)?.streamUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-netflix-red hover:text-netflix-red/80 underline"
                      >
                        Clique para assistir
                      </a>
                    </div>
                  </div>
                )
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <div className="text-center">
                    <Play className="w-16 h-16 text-netflix-red mx-auto mb-4" />
                    <p className="text-lg font-medium text-white">Aguardando transmissão</p>
                    <p className="text-sm text-gray-400">A live começará em breve</p>
                  </div>
                </div>
              )}
            </div>

            {/* Stream Info */}
            <div className="mt-4 sm:mt-6 space-y-3 sm:space-y-4">
              <div>
                <h4 className="font-semibold text-white mb-2 text-sm sm:text-base">📝 Sobre esta Live</h4>
                <p className="text-gray-400 text-xs sm:text-sm leading-relaxed break-words">
                  {(currentStream as any)?.description || "Descrição da live não disponível"}
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary" className="bg-gray-700 text-gray-300 text-xs px-2 py-1">
                  📈 Trading
                </Badge>
                <Badge variant="secondary" className="bg-gray-700 text-gray-300 text-xs px-2 py-1">
                  🎯 Estratégias
                </Badge>
                <Badge variant="secondary" className="bg-gray-700 text-gray-300 text-xs px-2 py-1">
                  📊 Análise Técnica
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="bg-netflix-gray border-gray-700">
          <CardContent className="p-4 sm:p-8 text-center">
            <div className="w-16 h-16 sm:w-24 sm:h-24 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6">
              <Play className="w-8 h-8 sm:w-12 sm:h-12 text-gray-400" />
            </div>
            <h3 className="text-lg sm:text-xl font-semibold text-white mb-2">Nenhuma live ativa</h3>
            <p className="text-gray-400 text-sm sm:text-base">Não há transmissões ao vivo no momento. Confira as lives anteriores abaixo.</p>
          </CardContent>
        </Card>
      )}

      {/* Previous Lives */}
      <Card className="bg-netflix-gray border-gray-700">
        <CardHeader className="pb-3 sm:pb-6">
          <CardTitle className="text-lg sm:text-xl font-semibold text-white">📺 Lives Anteriores</CardTitle>
        </CardHeader>
        <CardContent>
          {previousStreams.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
              {previousStreams.map((stream: any) => (
                <Card 
                  key={stream.id} 
                  className="bg-gray-800 border-gray-700 cursor-pointer hover:bg-gray-700 transition-colors"
                >
                  <CardContent className="p-3 sm:p-4">
                    <h4 className="font-medium text-white mb-2 text-sm sm:text-base leading-tight">
                      {stream.title}
                    </h4>
                    <div className="flex items-center space-x-2 text-gray-400 text-xs sm:text-sm mb-2">
                      <Calendar className="w-3 h-3 sm:w-4 sm:h-4" />
                      <span>{formatDate(stream.scheduledAt)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-1 text-gray-500 text-xs">
                        <Clock className="w-3 h-3" />
                        <span>Gravação disponível</span>
                      </div>
                      <Play className="w-4 h-4 sm:w-5 sm:h-5 text-netflix-red" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-6 sm:py-8">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4">
                <Calendar className="w-6 h-6 sm:w-8 sm:h-8 text-gray-400" />
              </div>
              <p className="text-gray-400 text-base sm:text-lg">Nenhuma live anterior</p>
              <p className="text-gray-500 text-xs sm:text-sm mt-1">As gravações das lives aparecerão aqui</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
