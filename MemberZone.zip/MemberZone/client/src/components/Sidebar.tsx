import { useAuth } from "@/hooks/useAuth";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  Home, 
  Play, 
  Radio, 
  BarChart3, 
  Bot, 
  Settings,
  LogOut,
  Crown
} from "lucide-react";

const navigationItems = [
  { href: "/", icon: Home, label: "Início" },
  { href: "/classes", icon: Play, label: "Aulas" },
  { href: "/live", icon: Radio, label: "Live ao Vivo" },
  { href: "/management", icon: BarChart3, label: "Gerenciamento" },
  { href: "/robot", icon: Bot, label: "Robô de Sinais", premium: true },
  { href: "/admin", icon: Settings, label: "Painel Admin", admin: true },
];

interface SidebarProps {
  isOpen?: boolean;
  onClose?: () => void;
}

export function Sidebar({ isOpen = true, onClose }: SidebarProps) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();

  const handleNavigation = (href: string, item: any) => {
    if (item.admin && user?.role !== "admin") {
      return; // Don't navigate, just show it's disabled
    }
    setLocation(href);
    // Close mobile sidebar after navigation
    if (onClose) {
      onClose();
    }
  };

  return (
    <nav className={`fixed left-0 top-0 w-64 h-full bg-card border-r border-border z-50 flex flex-col transition-all duration-300 ${
      isOpen ? 'translate-x-0' : '-translate-x-full'
    } lg:translate-x-0`}>
      {/* Logo */}
      <div className="p-6">
        <div className="flex items-center space-x-3 mb-8">
          <div className="w-10 h-10 bg-navy-blue rounded-lg flex items-center justify-center">
            <BarChart3 className="text-white text-lg" />
          </div>
          <div>
            <h1 className="text-lg xl:text-xl font-bold text-foreground">Investidor Academy</h1>
            <p className="text-xs xl:text-sm text-muted-foreground">Pro Platform</p>
          </div>
        </div>
        
        {/* Navigation */}
        <ul className="space-y-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            const isDisabled = (item.premium && !user?.isPremium && user?.role !== "admin") || 
                             (item.admin && user?.role !== "admin");
            
            return (
              <li key={item.href}>
                <button
                  onClick={() => handleNavigation(item.href, item)}
                  disabled={isDisabled}
                  className={cn(
                    "w-full flex items-center space-x-3 p-3 rounded-lg transition-colors text-left",
                    {
                      "bg-navy-blue text-white": isActive,
                      "text-muted-foreground hover:bg-muted hover:text-foreground": !isActive && !isDisabled,
                      "text-muted-foreground/50 cursor-not-allowed": isDisabled,
                    }
                  )}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                  {item.premium && (
                    <span className="ml-auto bg-success-green text-xs px-2 py-1 rounded-full">
                      PRO
                    </span>
                  )}
                </button>
              </li>
            );
          })}
        </ul>
      </div>
      
      {/* User Info */}
      <div className="mt-auto p-6 border-t border-border">
        <div className="flex items-center space-x-3 mb-4">
          <Avatar className="w-10 h-10">
            <AvatarFallback className="bg-muted text-foreground">
              {user?.name?.charAt(0)?.toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground truncate">{user?.name}</p>
            <div className="flex items-center space-x-1">
              {user?.isPremium && <Crown className="w-3 h-3 text-success-green" />}
              <p className="text-xs text-success-green">
                {user?.isPremium ? "Premium" : "Grátis"}
              </p>
            </div>
          </div>
        </div>
        <Button 
          onClick={logout}
          variant="outline" 
          className="w-full border-border hover:bg-muted"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Sair
        </Button>
      </div>
    </nav>
  );
}
