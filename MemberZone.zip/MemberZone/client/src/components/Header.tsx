import { useTheme } from "./ThemeProvider";
import { Button } from "@/components/ui/button";
import { Bell, Sun, Moon, Menu } from "lucide-react";

interface HeaderProps {
  title?: string;
  onMenuClick?: () => void;
  showMenuButton?: boolean;
}

export function Header({ title = "Dashboard", onMenuClick, showMenuButton = false }: HeaderProps) {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="bg-card border-b border-border p-3 sm:p-6 transition-colors">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          {showMenuButton && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onMenuClick}
              className="text-muted-foreground hover:text-foreground hover:bg-muted md:hidden"
            >
              <Menu className="w-5 h-5" />
            </Button>
          )}
          <h2 className="text-lg sm:text-2xl font-bold text-foreground truncate">{title}</h2>
        </div>
        <div className="flex items-center space-x-2 sm:space-x-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            className="text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
            title={theme === "dark" ? "Mudar para modo claro" : "Mudar para modo escuro"}
          >
            {theme === "dark" ? <Sun className="w-4 h-4 sm:w-5 sm:h-5" /> : <Moon className="w-4 h-4 sm:w-5 sm:h-5" />}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-muted-foreground hover:text-foreground hover:bg-muted relative"
          >
            <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="absolute -top-1 -right-1 bg-primary text-xs rounded-full w-4 h-4 sm:w-5 sm:h-5 flex items-center justify-center text-primary-foreground text-[10px] sm:text-xs">
              3
            </span>
          </Button>
        </div>
      </div>
    </header>
  );
}
