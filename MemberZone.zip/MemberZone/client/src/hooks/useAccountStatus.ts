import { useQuery } from "@tanstack/react-query";

export interface AccountStatus {
  id: number;
  email: string;
  name: string;
  isPremium: boolean;
  accountStatus: 'not_released' | 'premium_released' | 'pending_review';
  brokerRegistered: boolean;
  brokerUserId: string | null;
  canAccessPremium: boolean;
}

export function useAccountStatus() {
  return useQuery<{ success: boolean; account: AccountStatus }>({
    queryKey: ["/api/account-status"],
    staleTime: 1000 * 60 * 5, // 5 minutos
  });
}